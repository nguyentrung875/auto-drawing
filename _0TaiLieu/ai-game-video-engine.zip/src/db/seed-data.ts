/**
 * Mock Product DB — 50 SKU (FR-2, A-04).
 * Tuple order: [name, brand, category, priceVnd, emoji, ageDays]
 * ageDays drives the `stale_price` flag (> 7 days, UJ-3 edge case).
 */
type Sku = [string, string, string, number, string, number];

const SKUS: Sku[] = [
  ["Nước giặt hương hoa 3.5kg", "Sunlite", "Gia dụng", 189000, "🧺", 2],
  ["Robot hút bụi lau nhà thông minh", "Xiaomi", "Gadget", 2490000, "🤖", 1],
  ["Nồi chiên không dầu 5.5L", "Kalite", "Gia dụng", 1290000, "🍟", 4],
  ["Máy xay sinh tố đa năng 1200W", "Panasonic", "Gia dụng", 940000, "🥤", 11],
  ["Tai nghe không dây Pro ANC", "Anker", "Gadget", 1180000, "🎧", 3],
  ["Ống hút inox 6 cây + cọ", "EcoLife", "Đời sống", 39000, "🥤", 8],
  ["Bàn chải đánh răng điện", "Oral-B", "Làm đẹp", 749000, "🪥", 5],
  ["Serum vitamin C 10% 30ml", "Cocoon", "Làm đẹp", 265000, "💧", 6],
  ["Kem chống nắng physical SPF50", "Sunplay", "Làm đẹp", 149000, "☀️", 13],
  ["Máy rửa mặt silica mini", "Foreo", "Làm đẹp", 1890000, "🧼", 2],
  ["Đèn học chống cận 12W", "Halcon", "Gia dụng", 289000, "💡", 9],
  ["Quạt điều hòa mini để bàn", "Midea", "Gia dụng", 720000, "🌀", 7],
  ["Nồi cơm điện tử 1.8L", "Sharp", "Gia dụng", 1150000, "🍚", 12],
  ["Bộ dao bếp inox 6 món", "Zwilling", "Gia dụng", 990000, "🔪", 4],
  ["Máy ép chậm nguyên chất", "Hurom", "Gia dụng", 3290000, "🥕", 3],
  ["Ghế massage toàn thân", "Kangaroo", "Gia dụng", 12900000, "💆", 10],
  ["Máy lọc không khí HEPA", "Xiaomi", "Gia dụng", 2150000, "🌬️", 6],
  ["Cân điện tử thông minh", "Omron", "Sức khỏe", 480000, "⚖️", 14],
  ["Máy đo huyết áp bắp tay", "Omron", "Sức khỏe", 890000, "🩺", 5],
  ["Đồng hồ thông minh Sports 2", "Amazfit", "Gadget", 1650000, "⌚", 2],
  ["Sạc dự phòng 20000mAh", "Anker", "Gadget", 599000, "🔋", 1],
  ["Chuột không dây Silent", "Logitech", "Gadget", 349000, "🖱️", 8],
  ["Bàn phím cơ 65% hot-swap", "Akko", "Gadget", 1190000, "⌨️", 4],
  ["Màn hình cong 27 inch 165Hz", "LG", "Gadget", 4890000, "🖥️", 9],
  ["Webcam 2K auto-focus", "Logitech", "Gadget", 1390000, "📷", 7],
  ["Micro thu âm USB condenser", "Rode", "Gadget", 1990000, "🎙️", 3],
  ["Loa bluetooth chống nước 30W", "JBL", "Gadget", 1090000, "🔊", 6],
  ["Camera hành trình 2K + GPS", "70mai", "Gadget", 1480000, "🚗", 12],
  ["Máy ảnh mirrorless kit 18-55", "Sony", "Gadget", 18900000, "📸", 15],
  ["Đèn flash đeo đầu 1200lm", "Browndog", "Đời sống", 219000, "🔦", 5],
  ["Vali kéo bánh đôi 24 inch", "Legend", "Đời sống", 1250000, "🧳", 10],
  ["Túi giữ nhiệt giữ nóng 8h", "Lock&Lock", "Đời sống", 179000, "🍱", 2],
  ["Bình giữ nhiệt 1L inox", "Zojirushi", "Đời sống", 690000, "🍶", 6],
  ["Máy cạo râu 3 lưỡi", "Philips", "Làm đẹp", 1050000, "🪒", 4],
  ["Máy sấy tóc ion âm 1800W", "Dyson", "Làm đẹp", 5990000, "💨", 11],
  ["Nước hoa unisex 50ml", "Zara", "Làm đẹp", 890000, "🌸", 8],
  ["Kính râm polarized UV400", "Rayban", "Thời trang", 1750000, "🕶️", 3],
  ["Giày chạy bộ đệm khí", "Nike", "Thời trang", 2290000, "👟", 5],
  ["Túi canvas chống sốc 15 inch", "Herschel", "Thời trang", 899000, "🎒", 7],
  ["Đồng hồ cơ dây da 40mm", "Casio", "Thời trang", 2450000, "⌚", 9],
  ["Áo khoác gió siêu nhẹ", "Uniqlo", "Thời trang", 599000, "🧥", 2],
  ["Cà phê rang mộc 500g", "Trung Nguyên", "Thực phẩm", 165000, "☕", 1],
  ["Hạt điều rang muối 500g", "Sunflower", "Thực phẩm", 145000, "🥜", 6],
  ["Tảo biển snack 10 gói", "Cocoon", "Thực phẩm", 42000, "🌊", 3],
  ["Yến sào chưng đường 6 hũ", "Khánh Hòa", "Thực phẩm", 375000, "🥣", 13],
  ["Trà hoa cúc túi lọc 100 gói", "Twinings", "Thực phẩm", 96000, "🌼", 8],
  ["Gạo ST25 túi 5kg", "Tám Xá", "Thực phẩm", 215000, "🌾", 4],
  ["Thùng mì ăn liền 30 gói", "Omachi", "Thực phẩm", 199000, "🍜", 5],
  ["Vitamin tổng hợp 100 viên", "Blackmores", "Sức khỏe", 385000, "💊", 10],
  ["Máy massage cổ gáy 4 node", "Mikado", "Sức khỏe", 690000, "🫸", 12],
];

export interface SeedProduct {
  productId: string;
  name: string;
  image: string;
  price: number;
  currency: "VND";
  source: "mock";
  updatedAt: string;
  category: string;
  brand: string;
  affiliateLink: string;
  emoji: string;
}

function slugify(value: string): string {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/đ/g, "d")
    .replace(/Đ/g, "D")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

export const SEED_PRODUCTS: SeedProduct[] = SKUS.map(
  ([name, brand, category, price, emoji, ageDays], index) => {
    const productId = `p${String(index + 1).padStart(3, "0")}`;
    const slug = slugify(`${brand}-${name}`);
    return {
      productId,
      name,
      image: `/api/products/${productId}/image`,
      price,
      currency: "VND" as const,
      source: "mock" as const,
      updatedAt: new Date(
        Date.now() - ageDays * 24 * 60 * 60 * 1000,
      ).toISOString(),
      category,
      brand,
      affiliateLink: `https://tiktok.com/shop/${slug}?aff=${productId}`,
      emoji,
    };
  },
);

export const STALE_PRICE_DAYS = 7;
