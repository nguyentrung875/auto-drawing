import {
  integer,
  jsonb,
  pgTable,
  text,
  timestamp,
} from "drizzle-orm/pg-core";
import type {
  BatchReport,
  GameJson,
  JobTimings,
  ValidationError,
} from "@/engine/types";

/** ProductProvider persistence (AD-5) — one row per SKU. */
export const products = pgTable("products", {
  productId: text("product_id").primaryKey(),
  name: text("name").notNull(),
  image: text("image").notNull(),
  price: integer("price").notNull(),
  currency: text("currency").notNull().default("VND"),
  source: text("source").notNull().default("mock"),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  category: text("category").notNull(),
  brand: text("brand").notNull(),
  affiliateLink: text("affiliate_link").notNull(),
  emoji: text("emoji").notNull().default("📦"),
});

/** games/ bounded context — Universal Game JSON is the aggregate root. */
export const games = pgTable("games", {
  gameId: text("game_id").primaryKey(),
  batchId: text("batch_id"),
  mechanic: text("mechanic").notNull(),
  interaction: text("interaction").notNull(),
  seed: integer("seed").notNull(),
  resultVariant: text("result_variant").notNull(),
  status: text("status").notNull(),
  totalDurationMs: integer("total_duration_ms").notNull(),
  distinctProducts: integer("distinct_products").notNull().default(0),
  gameJson: jsonb("game_json").$type<GameJson>().notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

/** queue/ bounded context (AD-9) — file-queue semantics, DB-backed. */
export const jobs = pgTable("jobs", {
  jobId: text("job_id").primaryKey(),
  gameId: text("game_id").notNull(),
  batchId: text("batch_id"),
  mechanic: text("mechanic").notNull(),
  productIds: jsonb("product_ids").$type<string[]>().notNull(),
  seed: integer("seed").notNull(),
  resultVariant: text("result_variant").notNull(),
  status: text("status").notNull().default("pending"),
  retries: integer("retries").notNull().default(0),
  contentSource: text("content_source").notNull().default("local-template"),
  timings: jsonb("timings").$type<JobTimings>(),
  errors: jsonb("errors").$type<ValidationError[]>(),
  warnings: jsonb("warnings").$type<string[]>(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  startedAt: timestamp("started_at", { withTimezone: true }),
  finishedAt: timestamp("finished_at", { withTimezone: true }),
});

export const batches = pgTable("batches", {
  batchId: text("batch_id").primaryKey(),
  status: text("status").notNull().default("running"),
  total: integer("total").notNull(),
  passed: integer("passed").notNull().default(0),
  failed: integer("failed").notNull().default(0),
  avgRenderMs: integer("avg_render_ms").notNull().default(0),
  distinctProducts: integer("distinct_products").notNull().default(0),
  workerPoolMax: integer("worker_pool_max").notNull().default(1),
  report: jsonb("report").$type<BatchReport>().notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  finishedAt: timestamp("finished_at", { withTimezone: true }),
});

/** observability/ (NFR-4) — one log document per gameId. */
export const renderLogs = pgTable("render_logs", {
  gameId: text("game_id").primaryKey(),
  jobId: text("job_id").notNull(),
  batchId: text("batch_id"),
  seed: integer("seed").notNull(),
  products: jsonb("products").$type<string[]>().notNull(),
  status: text("status").notNull(),
  timings: jsonb("timings").$type<JobTimings>(),
  validatorErrors: jsonb("validator_errors").$type<ValidationError[]>().notNull(),
  warnings: jsonb("warnings").$type<string[]>().notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export type ProductRow = typeof products.$inferSelect;
export type GameRow = typeof games.$inferSelect;
export type JobRow = typeof jobs.$inferSelect;
export type BatchRow = typeof batches.$inferSelect;
