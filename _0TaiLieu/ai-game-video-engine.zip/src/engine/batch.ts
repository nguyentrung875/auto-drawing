import crypto from "node:crypto";
import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { batches as batchesTable, jobs as jobsTable } from "@/db/schema";
import { listProducts } from "@/engine/product-provider";
import { runJob, WORKER_POOL_MAX, type JobRequest } from "@/engine/pipeline";
import { createRng } from "@/engine/rng";
import type {
  BatchReport,
  BatchReportJob,
  Mechanic,
  Product,
  ResultVariant,
} from "@/engine/types";

export interface BatchRequest {
  count: number;
  mechanics: Mechanic[];
  baseSeed?: number;
  resultVariant?: ResultVariant;
}

function selectProducts(
  mechanic: Mechanic,
  pool: Product[],
  rng: ReturnType<typeof createRng>,
): string[] {
  if (mechanic === "ONE_AWAY") {
    const candidate =
      pool.find((product) => product.price >= 100_000) ?? pool[0];
    return [candidate.productId];
  }
  if (mechanic === "HI_LO") {
    for (let i = 0; i < pool.length; i += 1) {
      for (let j = i + 1; j < pool.length; j += 1) {
        const a = pool[i];
        const b = pool[j];
        const delta =
          Math.abs(b.price - a.price) / Math.min(a.price, b.price);
        if (delta >= 0.1) return [a.productId, b.productId];
      }
    }
    return [pool[0].productId, pool[1].productId];
  }
  for (let i = 0; i + 2 < pool.length; i += 1) {
    const trio = [pool[i], pool[i + 1], pool[i + 2]];
    const prices = trio.map((product) => product.price);
    const sorted = [...prices].sort((x, y) => y - x);
    const gap = (sorted[0] - sorted[1]) / Math.max(sorted[1], 1);
    if (new Set(prices).size === 3 && gap >= 0.02) {
      return trio.map((product) => product.productId);
    }
  }
  return pool.slice(0, 3).map((product) => product.productId);
}

/** UJ-2 heuristic: random + price delta so every question is meaningful. */
export function planJobs(
  request: BatchRequest,
  pool: Product[],
): JobRequest[] {
  const baseSeed = request.baseSeed ?? Date.now() % 1_000_000;
  const resultVariant: ResultVariant = request.resultVariant ?? "in_video";
  const jobs: JobRequest[] = [];
  const gameIds = new Set<string>();

  for (let index = 0; index < request.count; index += 1) {
    const mechanic = request.mechanics[index % request.mechanics.length];
    const seed = baseSeed + index * 17;
    const rng = createRng(seed);
    const offset = rng.int(0, Math.max(0, pool.length - 1));
    const rotated = [
      ...pool.slice(offset),
      ...pool.slice(0, offset),
    ];
    const shuffled = rng.shuffle(rotated);
    const productIds = selectProducts(mechanic, shuffled, rng);
    const gameId = `${mechanic.toLowerCase()}_${productIds.join("_")}_${seed}`;
    if (gameIds.has(gameId)) continue;
    gameIds.add(gameId);
    jobs.push({
      jobId: crypto.randomUUID().slice(0, 12),
      gameId,
      mechanic,
      productIds,
      seed,
      resultVariant,
      batchId: null,
    });
  }
  return jobs;
}

const running = new Set<string>();

/** Enqueue then run with a bounded worker pool — hands-free (SM-3). */
export async function createBatch(request: BatchRequest): Promise<string> {
  const pool = await listProducts();
  const planned = planJobs(request, pool);
  const batchId = `batch_${new Date().toISOString().slice(0, 10)}_${crypto
    .randomUUID()
    .slice(0, 8)}`;

  const report: BatchReport = {
    batchId,
    createdAt: new Date().toISOString(),
    finishedAt: null,
    total: planned.length,
    passed: 0,
    failed: 0,
    avgRenderMs: 0,
    distinctProducts: 0,
    workerPoolMax: WORKER_POOL_MAX,
    manualInterventions: 0,
    jobs: [],
  };

  await db.insert(batchesTable).values({
    batchId,
    status: "running",
    total: planned.length,
    report,
  });

  for (const job of planned) {
    await db.insert(jobsTable).values({
      jobId: job.jobId,
      gameId: job.gameId,
      batchId,
      mechanic: job.mechanic,
      productIds: job.productIds,
      seed: job.seed,
      resultVariant: job.resultVariant,
      status: "pending",
    });
    job.batchId = batchId;
  }

  if (!running.has(batchId)) {
    running.add(batchId);
    void runBatch(batchId, planned).finally(() => running.delete(batchId));
  }

  return batchId;
}

async function runBatch(batchId: string, planned: JobRequest[]): Promise<void> {
  const knownGameIds = planned.map((job) => job.gameId);
  const outcomes: BatchReportJob[] = [];
  let cursor = 0;

  const worker = async () => {
    for (;;) {
      const index = cursor;
      cursor += 1;
      if (index >= planned.length) return;
      const job = planned[index];
      const outcome = await runJob(job, knownGameIds);
      outcomes.push({
        jobId: outcome.jobId,
        gameId: outcome.gameId,
        mechanic: outcome.mechanic,
        seed: outcome.seed,
        productIds: outcome.productIds,
        status: outcome.status,
        render_ms: outcome.timings.render_ms,
        outputPath: outcome.outputPath,
        errors: outcome.errors,
        warnings: outcome.warnings,
      });
      const [current] = await db
        .select({ report: batchesTable.report })
        .from(batchesTable)
        .where(eq(batchesTable.batchId, batchId));
      if (current) {
        const report = current.report;
        const passed = report.passed + (outcome.status === "done" ? 1 : 0);
        const failed = report.failed + (outcome.status === "failed" ? 1 : 0);
        const renderTimes = outcomes.map((entry) => entry.render_ms);
        await db
          .update(batchesTable)
          .set({
            passed,
            failed,
            avgRenderMs: Math.round(
              renderTimes.reduce((sum, value) => sum + value, 0) /
                Math.max(renderTimes.length, 1),
            ),
            distinctProducts: new Set(
              outcomes.flatMap((entry) => entry.productIds),
            ).size,
            report: { ...report, passed, failed, jobs: outcomes },
          })
          .where(eq(batchesTable.batchId, batchId));
      }
    }
  };

  await Promise.all(
    Array.from({ length: Math.min(WORKER_POOL_MAX, planned.length) }, worker),
  );

  const distinctProducts = new Set(
    outcomes.flatMap((entry) => entry.productIds),
  ).size;
  const renderTimes = outcomes.map((entry) => entry.render_ms);
  const finishedAt = new Date().toISOString();

  const finalReport: BatchReport = {
    batchId,
    createdAt: new Date().toISOString(),
    finishedAt,
    total: planned.length,
    passed: outcomes.filter((entry) => entry.status === "done").length,
    failed: outcomes.filter((entry) => entry.status === "failed").length,
    avgRenderMs: Math.round(
      renderTimes.reduce((sum, value) => sum + value, 0) /
        Math.max(renderTimes.length, 1),
    ),
    distinctProducts,
    workerPoolMax: WORKER_POOL_MAX,
    manualInterventions: 0,
    jobs: outcomes,
  };

  await db
    .update(batchesTable)
    .set({
      status: "done",
      passed: finalReport.passed,
      failed: finalReport.failed,
      avgRenderMs: finalReport.avgRenderMs,
      distinctProducts: finalReport.distinctProducts,
      report: finalReport,
      finishedAt: new Date(),
    })
    .where(eq(batchesTable.batchId, batchId));
}

export async function listBatches(limit = 8) {
  const rows = await db
    .select()
    .from(batchesTable)
    .orderBy(asc(batchesTable.createdAt));
  return rows.slice(-limit).reverse();
}
