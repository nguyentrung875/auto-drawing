import { createRng } from "@/engine/rng";
import { engineChoices } from "@/engine/mechanics";
import { formatVnd, wordCount } from "@/engine/format";
import type {
  GameContent,
  Gameplay,
  Mechanic,
  Product,
} from "@/engine/types";

export interface ContentRequest {
  mechanic: Mechanic;
  entities: Product[];
  gameplay: Gameplay;
  seed: number;
  answerText: string;
  /** Engine-owned short answer used for the reveal voice line. */
  answerShort: string;
  maskedPrice?: string;
}

export interface ContentResult {
  content: GameContent;
  voiceIntro: string;
  voiceReveal: string;
  warnings: string[];
  source: string;
}

const BASE_HASHTAGS = [
  "#tiktokshop",
  "#doangiagia",
  "#gamevuinhon",
  "#xuhuong2026",
];

/** LLM (and templates) may never emit a price — strip digit runs defensively. */
function stripPrices(text: string): { text: string; stripped: boolean } {
  const cleaned = text
    .replace(/\d[\d.,]{3,}/g, "")
    .replace(/\s{2,}/g, " ")
    .trim();
  return { text: cleaned, stripped: cleaned !== text.trim() };
}

const HOOKS = [
  "Đừng lướt — 90% người đoán sai câu này!",
  "Đoán đi, sai là xem lại giỏ hàng liền!",
  "3 giây thôi: bạn tin vào trực giác của mình không?",
  "Câu này làm cả phòng tranh cãi suốt 5 phút.",
  "Ai tự tin đoán đúng thì comment liền!",
];

const CTAS = [
  "Comment đáp án rồi xem kết quả nhé!",
  "Bạn đoán đúng hay sai? Comment bên dưới!",
  "Follow để mai chơi tiếp câu dễ hơn!",
  "Nhận xét xem mình đúng vòng mấy!",
];

const ONE_AWAY_HOOKS = [
  "Một chữ số bị giấu — bạn đoán được không?",
  "Con số thiếu chính là đáp án. Đoán thử!",
  "Điền số còn thiếu trong giá này đi!",
];

function localTemplate(req: ContentRequest): ContentResult {
  const rng = createRng(req.seed);
  const { entities, gameplay, mechanic, answerText } = req;
  const first = entities[0];
  const second = entities[1];

  let hook: string;
  let question: string;
  let voiceReveal: string;
  let title: string;

  if (mechanic === "HI_LO" && second) {
    hook = rng.pick(HOOKS);
    question = `${second.name.toUpperCase()} đắt hơn hay rẻ hơn ${first.name.toUpperCase()}?`;
    title = `Cao hơn hay thấp hơn: ${second.brand}?`;
    voiceReveal = `Đáp án là ${req.answerShort}`;
  } else if (mechanic === "MOST_EXPENSIVE") {
    hook = rng.pick(HOOKS);
    question = "Đâu là sản phẩm ĐẮT NHẤT trong mấy món này?";
    title = "Chọn món đắt nhất — đừng nhìn giá!";
    voiceReveal = `Đắt nhất là ${req.answerShort}`;
  } else {
    hook = rng.pick(ONE_AWAY_HOOKS);
    question = `Chữ số bị ẩn trong giá ${req.maskedPrice ?? ""} là số mấy?`;
    title = "Điền số còn thiếu!";
    voiceReveal = `Đáp án là ${req.answerShort}`;
  }
  void answerText;

  const cta = rng.pick(CTAS);
  const hashtags = [
    ...BASE_HASHTAGS,
    `#${first.category.toLowerCase().replace(/\s+/g, "")}`,
    `#${first.brand.toLowerCase().replace(/[^a-z0-9]/g, "")}`,
    mechanic === "HI_LO" ? "#caohonhaythaphon" : mechanic === "MOST_EXPENSIVE" ? "#datnhat" : "#diensoc",
  ];

  const caption = `${hook}\n${question}\n${cta}`;
  const voiceIntro = `${hook}`;

  return {
    content: {
      title,
      hook,
      question,
      choices: engineChoices(gameplay),
      cta,
      caption,
      hashtags,
      voiceScript: `${voiceIntro} ${voiceReveal}`.trim(),
      source: "local-template",
    },
    voiceIntro,
    voiceReveal,
    warnings: [],
    source: "local-template",
  };
}

function buildPrompt(req: ContentRequest): string {
  const names = req.entities
    .map(
      (product) =>
        `- ${product.name} (${product.brand}, ${product.category}) [id ${product.productId}]`,
    )
    .join("\n");
  return [
    "Bạn là copywriter video quiz TikTok Shop tiếng Việt, giọng trẻ, ngắn, gây tò mò.",
    "TUYỆT ĐỐI KHÔNG nêu giá tiền, số tiền hay bất kỳ con số giá nào.",
    `Luật chơi: ${req.mechanic}.`,
    req.mechanic === "HI_LO"
      ? "Người xem đoán sản phẩm thứ 2 đắt hơn hay rẻ hơn sản phẩm thứ 1."
      : req.mechanic === "MOST_EXPENSIVE"
        ? "Người xem chọn sản phẩm đắt nhất trong danh sách."
        : "Người xem đoán chữ số bị ẩn trong giá của sản phẩm.",
    `Sản phẩm (không kèm giá):\n${names}`,
    'Trả về JSON: {"title": string, "hook": string (<=12 từ), "question": string, "cta": string, "caption": string, "hashtags": string[] (5-7 tag bắt đầu bằng #), "voice_intro": string (<=12 từ)}',
  ].join("\n");
}

interface LlmDraft {
  title?: string;
  hook?: string;
  question?: string;
  cta?: string;
  caption?: string;
  hashtags?: unknown;
  voice_intro?: string;
  voice_reveal?: string;
}

function coerceHashtags(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  return value
    .filter((item): item is string => typeof item === "string")
    .map((tag) => (tag.startsWith("#") ? tag : `#${tag}`))
    .filter((tag) => tag.length > 1)
    .slice(0, 8);
}

async function callOpenAi(prompt: string): Promise<LlmDraft> {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) throw new Error("no openai key");
  const model = process.env.OPENAI_MODEL ?? "gpt-4o-mini";
  const response = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model,
      temperature: 0.9,
      response_format: { type: "json_object" },
      messages: [
        { role: "system", content: "Trả lời strictly bằng JSON hợp lệ." },
        { role: "user", content: prompt },
      ],
    }),
    signal: AbortSignal.timeout(12_000),
  });
  if (!response.ok) throw new Error(`openai ${response.status}`);
  const payload = (await response.json()) as {
    choices?: { message?: { content?: string } }[];
  };
  const text = payload.choices?.[0]?.message?.content;
  if (!text) throw new Error("openai empty");
  return JSON.parse(text) as LlmDraft;
}

async function callGemini(prompt: string): Promise<LlmDraft> {
  const apiKey =
    process.env.GEMINI_API_KEY ?? process.env.GOOGLE_GENERATIVE_AI_API_KEY;
  if (!apiKey) throw new Error("no gemini key");
  const model = process.env.GEMINI_MODEL ?? "gemini-2.0-flash";
  const response = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`,
    {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        contents: [{ role: "user", parts: [{ text: prompt }] }],
        generationConfig: {
          temperature: 0.9,
          responseMimeType: "application/json",
        },
      }),
      signal: AbortSignal.timeout(12_000),
    },
  );
  if (!response.ok) throw new Error(`gemini ${response.status}`);
  const payload = (await response.json()) as {
    candidates?: { content?: { parts?: { text?: string }[] } }[];
  };
  const text = payload.candidates?.[0]?.content?.parts?.[0]?.text;
  if (!text) throw new Error("gemini empty");
  return JSON.parse(text) as LlmDraft;
}

/**
 * FR-1: LLM only writes copy (hook/question/cta/hashtags/voice).
 * Prices, choices and answers stay engine-owned. Any LLM failure,
 * malformed JSON or price leak falls back to the deterministic template.
 */
export async function generateContent(
  req: ContentRequest,
): Promise<ContentResult> {
  const fallback = localTemplate(req);
  const provider = process.env.OPENAI_API_KEY
    ? "openai"
    : process.env.GEMINI_API_KEY ?? process.env.GOOGLE_GENERATIVE_AI_API_KEY
      ? "gemini"
      : null;

  if (!provider) return fallback;

  const warnings: string[] = [];
  for (let attempt = 1; attempt <= 3; attempt += 1) {
    try {
      const draft = provider === "openai" ? await callOpenAi(buildPrompt(req)) : await callGemini(buildPrompt(req));
      const sanitized = [
        draft.hook,
        draft.question,
        draft.cta,
        draft.caption,
        draft.voice_intro,
        draft.voice_reveal,
        draft.title,
      ].map((value) =>
        typeof value === "string" ? stripPrices(value) : { text: "", stripped: false },
      );
      if (sanitized.some((entry) => entry.stripped)) {
        warnings.push(
          "W_PRICE_OVERWRITTEN: LLM nhét số tiền vào copy — đã strip, price vẫn do ProductProvider sở hữu.",
        );
      }
      const hook = sanitized[0].text.trim();
      const question = sanitized[1].text.trim();
      const cta = sanitized[2].text.trim();
      const caption = sanitized[3].text.trim();
      const voiceIntro = sanitized[4].text.trim();
      const voiceReveal = sanitized[5].text.trim();
      const hashtags = coerceHashtags(draft.hashtags);

      if (!hook || !question || !cta) throw new Error("llm incomplete fields");

      const mergedHashtags =
        hashtags.length >= 3 ? [...new Set([...hashtags, ...BASE_HASHTAGS])] : fallback.content.hashtags;
      const finalVoiceReveal = voiceReveal || fallback.voiceReveal;
      const finalVoiceIntro = voiceIntro || fallback.voiceIntro;
      const voiceScript = `${finalVoiceIntro} ${finalVoiceReveal}`.trim();
      if (wordCount(voiceScript) > 30) throw new Error("llm voice too long");

      return {
        content: {
          title: sanitized[6].text.trim() || fallback.content.title,
          hook,
          question,
          choices: engineChoices(req.gameplay),
          cta,
          caption: caption || `${hook}\n${question}\n${cta}`,
          hashtags: mergedHashtags.slice(0, 8),
          voiceScript,
          source: `llm:${provider}`,
        },
        voiceIntro: finalVoiceIntro,
        voiceReveal: finalVoiceReveal,
        warnings,
        source: `llm:${provider}`,
      };
    } catch (error) {
      warnings.push(
        `W_LLM_RETRY_${attempt}: ${(error as Error).message} → fallback template deterministic.`,
      );
    }
  }

  return { ...fallback, warnings: [...fallback.warnings, ...warnings] };
}

export function priceHintFor(req: ContentRequest): string {
  if (req.entities.length === 0) return "";
  return formatVnd(req.entities[0].price);
}
