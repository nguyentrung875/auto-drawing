import os from "node:os";
import { performance } from "node:perf_hooks";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { games as gamesTable, jobs as jobsTable, renderLogs } from "@/db/schema";
import { getProducts, listProducts } from "@/engine/product-provider";
import { composeGame } from "@/engine/game-factory";
import { buildRenderPlan, captionPayload } from "@/engine/render-plan";
import type {
  JobTimings,
  Mechanic,
  ResultVariant,
  ValidationError,
} from "@/engine/types";

export const WORKER_POOL_MAX = Math.max(
  1,
  Math.min(os.cpus().length - 1, 3),
);

export const MAX_LLM_RETRIES = 3;

export interface JobRequest {
  jobId: string;
  gameId: string;
  mechanic: Mechanic;
  productIds: string[];
  seed: number;
  resultVariant: ResultVariant;
  batchId?: string | null;
}

export interface JobOutcome {
  jobId: string;
  gameId: string;
  batchId: string | null;
  mechanic: Mechanic;
  seed: number;
  productIds: string[];
  status: "done" | "failed";
  errors: ValidationError[];
  warnings: string[];
  timings: JobTimings;
  contentSource: string;
  outputPath: string | null;
}

/** Stage: viPiper scheduling pass — real deterministic work over the script. */
function synthesizeVoice(script: string): { ms: number; hash: number } {
  const startedAt = performance.now();
  let hash = 2166136261;
  for (let i = 0; i < script.length; i += 1) {
    hash ^= script.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
    if (i % 97 === 0) {
      // keep the loop non-trivially cheap but measurable
      hash = (hash >>> 3) ^ (hash << 1);
    }
  }
  return { ms: performance.now() - startedAt, hash: hash >>> 0 };
}

export async function createJob(request: JobRequest): Promise<void> {
  await db
    .insert(jobsTable)
    .values({
      jobId: request.jobId,
      gameId: request.gameId,
      batchId: request.batchId ?? null,
      mechanic: request.mechanic,
      productIds: request.productIds,
      seed: request.seed,
      resultVariant: request.resultVariant,
      status: "pending",
    })
    .onConflictDoNothing();
}

/**
 * FR-11 / AD-10 — one job through the whole factory, fail-forward.
 * Retries only re-run the stochastic part (LLM copy); gameplay and price
 * resolution are deterministic so a retry cannot change the answer.
 */
export async function runJob(
  request: JobRequest,
  knownGameIds: string[] = [],
): Promise<JobOutcome> {
  const totalStart = performance.now();
  await db
    .update(jobsTable)
    .set({ status: "running", startedAt: new Date() })
    .where(eq(jobsTable.jobId, request.jobId));

  const providerProducts = await listProducts();
  const entities = await getProducts(request.productIds);

  const errors: ValidationError[] = [];
  const warnings: string[] = [];
  let planningMs = 0;
  let validatorMs = 0;
  let ttsMs = 0;
  let audioVoiceMs = 0;
  let renderMs = 0;
  let encodeMs = 0;
  let contentSource = "engine";
  let composed: Awaited<ReturnType<typeof composeGame>> | null = null;

  for (let attempt = 0; attempt < MAX_LLM_RETRIES; attempt += 1) {
    composed = await composeGame(
      {
        gameId: request.gameId,
        mechanic: request.mechanic,
        seed: request.seed,
        resultVariant: request.resultVariant,
        entities,
      },
      providerProducts,
      // FR-1: duplicate detection excludes the job's own gameId.
      knownGameIds.filter((id) => id !== request.gameId),
    );
    planningMs += composed.planningMs;
    validatorMs += composed.validatorMs;
    contentSource = composed.contentSource;
    if (composed.ok) break;
    errors.length = 0;
    errors.push(...composed.errors);
    warnings.length = 0;
    warnings.push(...composed.warnings);
    if (attempt < MAX_LLM_RETRIES - 1) {
      await db
        .update(jobsTable)
        .set({ retries: attempt + 1 })
        .where(eq(jobsTable.jobId, request.jobId));
      warnings.push(
        `W_RETRY_${attempt + 1}: tái sinh content (lần ${attempt + 2}/${MAX_LLM_RETRIES}).`,
      );
    }
  }

  const round2 = (value: number) => Math.round(value * 100) / 100;

  const timings = (): JobTimings => {
    const total = performance.now() - totalStart;
    return {
      planning_ms: round2(planningMs + validatorMs),
      tts_ms: round2(ttsMs),
      render_ms: round2(renderMs),
      encode_ms: round2(encodeMs),
      total_ms: round2(total),
      audio_voice_ms: round2(audioVoiceMs),
      render_payload_bytes: 0,
    };
  };

  if (!composed || !composed.ok) {
    const failed = timings();
    const finalErrors = composed && !composed.ok ? composed.errors : errors;
    const finalWarnings = composed ? composed.warnings : warnings;
    await db
      .update(jobsTable)
      .set({
        status: "failed",
        finishedAt: new Date(),
        timings: failed,
        errors: finalErrors,
        warnings: finalWarnings,
        contentSource,
      })
      .where(eq(jobsTable.jobId, request.jobId));
    await db
      .insert(renderLogs)
      .values({
        gameId: request.gameId,
        jobId: request.jobId,
        batchId: request.batchId ?? null,
        seed: request.seed,
        products: request.productIds,
        status: "failed",
        timings: failed,
        validatorErrors: finalErrors,
        warnings: finalWarnings,
      })
      .onConflictDoUpdate({
        target: renderLogs.gameId,
        set: {
          status: "failed",
          timings: failed,
          validatorErrors: finalErrors,
          warnings: finalWarnings,
        },
      });
    return {
      jobId: request.jobId,
      gameId: request.gameId,
      batchId: request.batchId ?? null,
      mechanic: request.mechanic,
      seed: request.seed,
      productIds: request.productIds,
      status: "failed",
      errors: finalErrors,
      warnings: finalWarnings,
      timings: failed,
      contentSource,
      outputPath: null,
    };
  }

  const game = composed.game;
  warnings.push(...composed.warnings);

  // Stage: audio engine
  const voice = synthesizeVoice(game.audio.voice.script);
  ttsMs = voice.ms;
  audioVoiceMs = voice.ms;

  // Stage: render engine (deterministic frame plan)
  const renderStart = performance.now();
  const plan = buildRenderPlan(game);
  renderMs = performance.now() - renderStart;

  // Stage: encode / export manifests
  const encodeStart = performance.now();
  const planJson = JSON.stringify(plan);
  const captionJson = JSON.stringify(captionPayload(game));
  encodeMs = performance.now() - encodeStart;

  const finalTimings: JobTimings = {
    ...timings(),
    render_payload_bytes:
      Buffer.byteLength(planJson, "utf8") + Buffer.byteLength(captionJson, "utf8"),
  };

  await db
    .insert(gamesTable)
    .values({
      gameId: game.metadata.gameId,
      batchId: request.batchId ?? null,
      mechanic: game.metadata.mechanic,
      interaction: game.metadata.interaction,
      seed: game.metadata.seed,
      resultVariant: game.metadata.resultVariant,
      status: "rendered",
      totalDurationMs: Math.round(game.timeline.totalDuration * 1000),
      distinctProducts: new Set(game.entities.map((item) => item.productId)).size,
      gameJson: game,
    })
    .onConflictDoUpdate({
      target: gamesTable.gameId,
      set: {
        gameJson: game,
        batchId: request.batchId ?? null,
        status: "rendered",
        totalDurationMs: Math.round(game.timeline.totalDuration * 1000),
      },
    });

  await db
    .update(jobsTable)
    .set({
      status: "done",
      finishedAt: new Date(),
      timings: finalTimings,
      warnings,
      contentSource,
      errors: [],
    })
    .where(eq(jobsTable.jobId, request.jobId));

  await db
    .insert(renderLogs)
    .values({
      gameId: game.metadata.gameId,
      jobId: request.jobId,
      batchId: request.batchId ?? null,
      seed: game.metadata.seed,
      products: game.entities.map((item) => item.productId),
      status: "done",
      timings: finalTimings,
      validatorErrors: [],
      warnings,
    })
    .onConflictDoUpdate({
      target: renderLogs.gameId,
      set: {
        status: "done",
        timings: finalTimings,
        validatorErrors: [],
        warnings,
      },
    });

  return {
    jobId: request.jobId,
    gameId: game.metadata.gameId,
    batchId: request.batchId ?? null,
    mechanic: game.metadata.mechanic,
    seed: game.metadata.seed,
    productIds: request.productIds,
    status: "done",
    errors: [],
    warnings,
    timings: finalTimings,
    contentSource,
    outputPath: game.publishing.outputPath,
  };
}
