export function formatVnd(price: number): string {
  return `${Math.round(price).toLocaleString("vi-VN")}₫`;
}

export function formatVndPlain(price: number): string {
  return Math.round(price).toLocaleString("en-US");
}

export function maskPrice(
  price: number,
  hiddenIndex: number,
  replacement = "?",
): string {
  const digits = Math.round(price).toString();
  return digits
    .split("")
    .map((digit, index) => (index === hiddenIndex ? replacement : digit))
    .join("");
}

export function groupDigits(value: string): string {
  return value.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

export function wordCount(value: string): number {
  return value.trim().split(/\s+/).filter(Boolean).length;
}
