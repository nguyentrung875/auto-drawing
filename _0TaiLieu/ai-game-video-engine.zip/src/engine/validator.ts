import { z } from "zod";
import { performance } from "node:perf_hooks";
import {
  currentAnswer,
  recomputeAnswer,
  CANONICAL_SCENES,
} from "@/engine/mechanics";
import { wordCount } from "@/engine/format";
import type {
  GameJson,
  Product,
  SfxType,
  ValidationError,
  ValidationResult,
} from "@/engine/types";
import { INTERACTION_BY_MECHANIC } from "@/engine/types";

export const SCENE_DURATIONS = {
  hook: 2,
  product: 3,
  question: 3,
  countdown: 3,
  reveal: 2,
  result: 2.5,
  cta: 3,
} as const;

export const TOTAL_DURATION_MIN = 15;
export const TOTAL_DURATION_MAX = 21;
export const COUNTDOWN_MAX = 3.5;

const SFX_TYPES: SfxType[] = [
  "countdown",
  "tick",
  "reveal",
  "correct",
  "wrong",
  "transition",
];

const productSchema = z.object({
  productId: z.string().min(1),
  name: z.string().min(1),
  image: z.string().min(1),
  price: z.number().int().positive(),
  currency: z.literal("VND"),
  source: z.string().min(1),
  updatedAt: z.string().min(1),
  category: z.string().min(1),
  brand: z.string().min(1),
  affiliateLink: z.string().min(1),
  emoji: z.string().min(1),
});

const gameplaySchema = z.discriminatedUnion("kind", [
  z.object({
    kind: z.literal("HI_LO"),
    productIds: z.tuple([z.string(), z.string()]),
    priceA: z.number().int().positive(),
    priceB: z.number().int().positive(),
    answer: z.enum(["higher", "lower"]),
  }),
  z.object({
    kind: z.literal("MOST_EXPENSIVE"),
    productIds: z.array(z.string()).min(3).max(4),
    prices: z.record(z.string(), z.number().int().positive()),
    answer: z.string().min(1),
  }),
  z.object({
    kind: z.literal("ONE_AWAY"),
    productIds: z.tuple([z.string()]),
    price: z.number().int().positive(),
    hiddenIndex: z.number().int().min(0),
    correctDigit: z.number().int().min(0).max(9),
    options: z.tuple([z.number().int().min(0).max(9), z.number().int().min(0).max(9)]),
  }),
]);

const gameSchema = z.object({
  metadata: z.object({
    gameId: z.string().min(1),
    mechanic: z.enum(["HI_LO", "MOST_EXPENSIVE", "ONE_AWAY"]),
    interaction: z.enum(["BOOLEAN", "MULTIPLE_CHOICE", "DIGIT"]),
    language: z.literal("vi-VN"),
    difficulty: z.enum(["easy", "medium", "hard"]),
    seed: z.number().int(),
    resultVariant: z.enum(["in_video", "comment"]),
    createdAt: z.string().min(1),
    engineVersion: z.string().min(1),
  }),
  content: z.object({
    title: z.string().min(1),
    hook: z.string().min(1),
    question: z.string().min(1),
    choices: z.array(z.string()).min(2).max(4),
    cta: z.string().min(1),
    caption: z.string().min(1),
    hashtags: z.array(z.string()).min(1),
    voiceScript: z.string().min(1),
    source: z.string().min(1),
  }),
  entities: z.array(productSchema).min(1).max(4),
  gameplay: gameplaySchema,
  scenes: z
    .array(
      z.object({
        type: z.enum(["hook", "product", "question", "countdown", "reveal", "result", "cta"]),
        duration: z.number().positive(),
        variant: z.enum(["in_video", "comment"]).optional(),
        componentRefs: z.array(z.string()),
      }),
    )
    .min(1),
  timeline: z.object({
    totalDuration: z.number().positive(),
    sceneTimings: z
      .array(
        z.object({
          type: z.enum(["hook", "product", "question", "countdown", "reveal", "result", "cta"]),
          start: z.number().min(0),
          duration: z.number().positive(),
          end: z.number().positive(),
        }),
      )
      .min(1),
  }),
  audio: z.object({
    voice: z.object({
      script: z.string().min(1),
      voice: z.string().min(1),
      adapter: z.string().min(1),
      wavPath: z.string().min(1),
      segments: z
        .array(
          z.object({
            text: z.string().min(1),
            startAt: z.number().min(0),
            estimatedDuration: z.number().positive(),
            revealLocked: z.boolean(),
          }),
        )
        .min(1),
    }),
    music: z.object({ track: z.string().min(1), volume: z.number().min(0).max(1) }),
    sfx: z
      .array(
        z.object({
          type: z.enum(["countdown", "tick", "reveal", "correct", "wrong", "transition"]),
          at: z.number().min(0),
          label: z.string().min(1),
        }),
      )
      .min(1),
  }),
  diversification: z.object({
    paperColor: z.string().min(1),
    inkColor: z.string().min(1),
    accentColor: z.string().min(1),
    tiltDeg: z.number().min(-2).max(2),
    bgmTrack: z.string().min(1),
    layout: z.enum(["grid-a", "grid-b", "stack"]),
  }),
  publishing: z.object({
    caption: z.string().min(1),
    hashtags: z.array(z.string()).min(1),
    affiliateLink: z.string().min(1),
    outputPath: z.string().min(1),
  }),
});

export interface ValidateContext {
  /** Fresh rows from ProductProvider (AD-4 ownership check). */
  providerProducts: Product[];
  knownGameIds?: string[];
}

function schemaError(field: string, hint: string): ValidationError {
  return { code: "E_SCHEMA_MISSING_FIELD", field, hint, layer: "schema" };
}

/** Layer 1 — JSON structure (zod). */
function runSchemaLayer(game: GameJson): ValidationError[] {
  const parsed = gameSchema.safeParse(game);
  if (parsed.success) return [];
  return parsed.error.issues.slice(0, 8).map((issue) => {
    const field = issue.path.join(".") || "game";
    if (field.startsWith("scenes") || field.startsWith("timeline")) {
      return {
        code: "E_SCHEMA_SCENE_INVALID",
        field,
        hint: `${issue.message} (7 scene MVP: ${CANONICAL_SCENES.join(", ")})`,
        layer: "schema" as const,
      };
    }
    return schemaError(field, issue.message);
  });
}

/** Layer 2 — game logic, price ownership, scene contract. */
function runGameLogicLayer(
  game: GameJson,
  ctx: ValidateContext,
): { errors: ValidationError[]; warnings: string[] } {
  const errors: ValidationError[] = [];
  const warnings: string[] = [];
  const providerById = new Map(
    ctx.providerProducts.map((product) => [product.productId, product]),
  );

  // AD-4: price is owned by ProductProvider.
  for (const entity of game.entities) {
    const provider = providerById.get(entity.productId);
    if (!provider) {
      errors.push({
        code: "E_ASSET_MISSING",
        field: `entities.${entity.productId}`,
        hint: "SKU không tồn tại trong ProductProvider (50 SKU mock).",
        layer: "asset",
      });
      continue;
    }
    if (provider.price !== entity.price) {
      errors.push({
        code: "E_PRICE_SOURCE_INVALID",
        field: `entities.${entity.productId}.price`,
        hint: `Provider nói ${provider.price}₫ nhưng Game JSON chứa ${entity.price}₫. Engine luôn overwrite giá từ Provider.`,
        layer: "game_logic",
      });
    }
    if (entity.affiliateLink !== provider.affiliateLink) {
      errors.push({
        code: "E_PRICE_SOURCE_INVALID",
        field: `entities.${entity.productId}.affiliate_link`,
        hint: "affiliate_link phải lấy từ ProductProvider.",
        layer: "game_logic",
      });
    }
  }

  const gameplay = game.gameplay;
  if (gameplay.kind !== game.metadata.mechanic) {
    errors.push({
      code: "E_GAME_LOGIC_INVALID",
      field: "gameplay.kind",
      hint: `gameplay.kind (${gameplay.kind}) không khớp mechanic (${game.metadata.mechanic}).`,
      layer: "game_logic",
    });
  }

  if (gameplay.kind === "HI_LO") {
    const ids = gameplay.productIds;
    if (ids.length !== 2) {
      errors.push(logicErr("gameplay.productIds", "HI_LO cần 2 productId."));
    } else {
      const a = providerById.get(ids[0]);
      const b = providerById.get(ids[1]);
      if (a && b) {
        const delta = Math.abs(b.price - a.price) / Math.max(a.price, 1);
        if (delta < 0.05) {
          errors.push({
            code: "E_HILO_EQUAL_PRICE",
            field: "gameplay.priceB",
            hint: `Chênh lệch ${(delta * 100).toFixed(1)}% < 5% — cặp này không tạo câu hỏi có nghĩa.`,
            layer: "game_logic",
          });
        }
        if (gameplay.priceA !== a.price || gameplay.priceB !== b.price) {
          errors.push(
            logicErr(
              "gameplay.priceA",
              "priceA/priceB phải bằng giá trị trong ProductProvider.",
            ),
          );
        }
      }
    }
  }

  if (gameplay.kind === "MOST_EXPENSIVE") {
    const sorted = Object.entries(gameplay.prices).sort((x, y) => y[1] - x[1]);
    if (sorted.length >= 2) {
      const gap =
        (sorted[0][1] - sorted[1][1]) / Math.max(sorted[1][1], 1);
      if (gap < 0.02) {
        errors.push({
          code: "E_MOST_EXPENSIVE_TIE",
          field: "gameplay.answer",
          hint: `Top 2 chênh lệch ${(gap * 100).toFixed(1)}% < 2% — nguy cơ hoà.`,
          layer: "game_logic",
        });
      }
    }
    if (!gameplay.prices[gameplay.answer]) {
      errors.push(
        logicErr("gameplay.answer", "Đáp án không nằm trong tập lựa chọn."),
      );
    }
  }

  if (gameplay.kind === "ONE_AWAY") {
    const digits = String(gameplay.price);
    if (Number(digits[gameplay.hiddenIndex]) !== gameplay.correctDigit) {
      errors.push({
        code: "E_GAME_LOGIC_INVALID",
        field: "gameplay.correct_digit",
        hint: `correct_digit (${gameplay.correctDigit}) phải bằng digit tại hidden_index (${digits[gameplay.hiddenIndex]}).`,
        layer: "game_logic",
      });
    }
    const [x, y] = gameplay.options;
    if (Math.abs(x - y) !== 1) {
      errors.push(
        logicErr(
          "gameplay.options",
          "ONE_AWAY cần 2 digit cách nhau đúng 1 đơn vị (ví dụ 8 vs 9).",
        ),
      );
    }
    if (gameplay.hiddenIndex === 0) {
      errors.push(
        logicErr("gameplay.hidden_index", "Không được ẩn digit đầu tiên."),
      );
    }
  }

  // FR-4: answer must match the deterministic recomputation.
  const expected = recomputeAnswer(gameplay);
  if (expected !== currentAnswer(gameplay)) {
    errors.push({
      code: "E_GAME_LOGIC_INVALID",
      field: "gameplay.answer",
      hint: `Engine tính được "${expected}" nhưng Game JSON chứa "${currentAnswer(gameplay)}".`,
      layer: "game_logic",
    });
  }

  // Scene contract (FR-5) + counter-metric guardrails (SM-C1).
  const types = game.scenes.map((scene) => scene.type);
  for (const required of ["countdown", "reveal", "result"] as const) {
    if (!types.includes(required)) {
      errors.push({
        code: "E_MISSING_REQUIRED_SCENE",
        field: `scenes.${required}`,
        hint: "Countdown, Reveal, Result là scene bắt buộc của mọi game 15-21s.",
        layer: "schema",
      });
    }
  }
  const countdown = game.timeline.sceneTimings.find(
    (scene) => scene.type === "countdown",
  );
  if (countdown && countdown.duration > COUNTDOWN_MAX) {
    errors.push({
      code: "E_SCHEMA_SCENE_INVALID",
      field: "scenes.countdown.duration",
      hint: `Countdown ${countdown.duration}s > ${COUNTDOWN_MAX}s — guardrail SM-C1 cấm kéo dài video để cày watch time.`,
      layer: "schema",
    });
  }
  if (countdown && Math.abs(countdown.duration - SCENE_DURATIONS.countdown) > 0.1) {
    errors.push({
      code: "E_TIMELINE_DRIFT",
      field: "scenes.countdown.duration",
      hint: "CountdownScene phải đúng 3.0s ±0.1s.",
      layer: "render",
    });
  }
  const revealTiming = game.timeline.sceneTimings.find(
    (scene) => scene.type === "reveal",
  );
  if (revealTiming && Math.abs(revealTiming.duration - SCENE_DURATIONS.reveal) > 0.1) {
    errors.push({
      code: "E_TIMELINE_DRIFT",
      field: "scenes.reveal.duration",
      hint: "RevealScene phải đúng 2.0s ±0.1s.",
      layer: "render",
    });
  }
  const total = game.timeline.totalDuration;
  if (total < TOTAL_DURATION_MIN - 0.5 || total > TOTAL_DURATION_MAX + 0.5) {
    errors.push({
      code: "E_SCHEMA_SCENE_INVALID",
      field: "timeline.totalDuration",
      hint: `Tổng thời lượng ${total.toFixed(1)}s nằm ngoài khoảng ${TOTAL_DURATION_MIN}-${TOTAL_DURATION_MAX}s.`,
      layer: "schema",
    });
  }

  // Interaction ↔ choices contract.
  const expectedChoices: Record<string, [number, number]> = {
    BOOLEAN: [2, 2],
    MULTIPLE_CHOICE: [3, 4],
    DIGIT: [2, 2],
  };
  const [minChoices, maxChoices] =
    expectedChoices[INTERACTION_BY_MECHANIC[game.metadata.mechanic]] ?? [2, 4];
  if (
    game.content.choices.length < minChoices ||
    game.content.choices.length > maxChoices
  ) {
    errors.push(
      logicErr(
        "content.choices",
        `${game.metadata.mechanic} (${INTERACTION_BY_MECHANIC[game.metadata.mechanic]}) cần ${minChoices}-${maxChoices} lựa chọn.`,
      ),
    );
  }
  if (new Set(game.content.choices).size !== game.content.choices.length) {
    errors.push(
      logicErr("content.choices", "Các lựa chọn không được trùng nhau."),
    );
  }

  // Audio contract (FR-9).
  const countdownStart = countdown?.start ?? 0;
  const countdownEnd = countdown?.end ?? 0;
  const ticks = game.audio.sfx.filter((cue) => cue.type === "countdown");
  if (ticks.length === 0) {
    errors.push({
      code: "E_AUDIO_MISSING_SFX",
      field: "audio.sfx.countdown",
      hint: "CountdownScene cần tick SFX mỗi 0.5s.",
      layer: "render",
    });
  } else if (countdown) {
    const inside = ticks.filter(
      (cue) => cue.at >= countdownStart - 0.01 && cue.at <= countdownEnd + 0.01,
    );
    if (inside.length < 5) {
      errors.push({
        code: "E_AUDIO_MISSING_SFX",
        field: "audio.sfx.countdown",
        hint: "Cần tối thiểu 5 tick trong CountdownScene (mỗi 0.5s trong 3s).",
        layer: "render",
      });
    }
  }
  for (const cue of game.audio.sfx) {
    if (!SFX_TYPES.includes(cue.type)) {
      errors.push(
        logicErr(
          `audio.sfx.${cue.type}`,
          `SFX type phải thuộc [${SFX_TYPES.join(", ")}].`,
        ),
      );
    }
  }
  if (game.audio.music.volume > 0.25) {
    errors.push(
      logicErr(
        "audio.music.volume",
        "Music volume > 0.25 sẽ lấn voice (voice LUFS -16, music LUFS -24).",
      ),
    );
  }
  const revealVoice = game.audio.voice.segments.find(
    (segment) => segment.revealLocked,
  );
  if (!revealVoice) {
    errors.push({
      code: "E_AUDIO_MISSING_SFX",
      field: "audio.voice.segments",
      hint: "Phải có 1 voice segment revealLocked khớp RevealScene.",
      layer: "render",
    });
  } else if (revealTiming && Math.abs(revealVoice.startAt - revealTiming.start) > 0.1) {
    errors.push({
      code: "E_AUDIO_MISSING_SFX",
      field: "audio.voice.segments.startAt",
      hint: `Voice reveal phải khớp RevealScene ±0.1s (hiện lệch ${(
        revealVoice.startAt - revealTiming.start
      ).toFixed(2)}s).`,
      layer: "render",
    });
  }
  if (wordCount(game.audio.voice.script) > 30) {
    errors.push(
      logicErr("audio.voice.script", "Voice script phải ≤ 30 từ (FR-9)."),
    );
  }

  // Duplicate gameId inside the batch (FR-1).
  if (
    ctx.knownGameIds?.length &&
    ctx.knownGameIds.includes(game.metadata.gameId)
  ) {
    errors.push({
      code: "E_DUPLICATE_GAME_ID",
      field: "metadata.gameId",
      hint: "gameId phải unique trong batch.",
      layer: "game_logic",
    });
  }

  if (game.publishing.affiliateLink.length < 8) {
    warnings.push(
      "W_AFFILIATE_MISSING: link affiliate thiếu — vẫn render nhưng Hermes sẽ đăng thiếu commission.",
    );
  }
  if (game.content.source.startsWith("llm") === false) {
    warnings.push("W_CONTENT_LOCAL_TEMPLATE: dùng copywriter template deterministic.");
  }

  return { errors, warnings };
}

function logicErr(field: string, hint: string): ValidationError {
  return { code: "E_GAME_LOGIC_INVALID", field, hint, layer: "game_logic" };
}

/** AD-3 — the single entry point called before the Game Engine runs. */
export function validateGame(
  game: GameJson,
  ctx: ValidateContext,
): ValidationResult {
  const startedAt = performance.now();
  const schemaErrors = runSchemaLayer(game);
  const { errors, warnings } =
    schemaErrors.length > 0
      ? { errors: [] as ValidationError[], warnings: [] as string[] }
      : runGameLogicLayer(game, ctx);
  const all = [...schemaErrors, ...errors];
  return {
    ok: all.length === 0,
    errors: all,
    warnings,
    durationMs: performance.now() - startedAt,
  };
}

export { gameSchema };
