import { formatVnd, groupDigits, maskPrice } from "@/engine/format";
import { createRng, type Rng } from "@/engine/rng";
import type {
  Mechanic,
  Product,
  SceneType,
  ValidationError,
  Gameplay,
} from "@/engine/types";
import { INTERACTION_BY_MECHANIC, MVP_SCENES } from "@/engine/types";

export const MECHANIC_PRODUCT_COUNT: Record<
  Mechanic,
  { min: number; max: number }
> = {
  HI_LO: { min: 2, max: 2 },
  MOST_EXPENSIVE: { min: 3, max: 4 },
  ONE_AWAY: { min: 1, max: 1 },
};

export const CANONICAL_SCENES: SceneType[] = [...MVP_SCENES];

export type BuildResult =
  | { ok: true; gameplay: Gameplay }
  | { ok: false; error: ValidationError };

function logicError(field: string, hint: string, code: string): ValidationError {
  return { code, field, hint, layer: "game_logic" };
}

/** FR-6 — HI_LO (BOOLEAN). */
function buildHiLo(items: Product[]): BuildResult {
  const [a, b] = items;
  if (items.length !== 2) {
    return {
      ok: false,
      error: logicError(
        "entities",
        "HI_LO cần đúng 2 sản phẩm.",
        "E_GAME_LOGIC_INVALID",
      ),
    };
  }
  const delta = Math.abs(b.price - a.price) / Math.max(a.price, 1);
  if (delta < 0.05) {
    return {
      ok: false,
      error: logicError(
        "gameplay.priceB",
        `Chênh lệch giá ${(delta * 100).toFixed(1)}% < 5% — câu hỏi không có nghĩa. Chọn cặp khác.`,
        "E_HILO_EQUAL_PRICE",
      ),
    };
  }
  return {
    ok: true,
    gameplay: {
      kind: "HI_LO",
      productIds: [a.productId, b.productId],
      priceA: a.price,
      priceB: b.price,
      answer: b.price > a.price ? "higher" : "lower",
    },
  };
}

/** FR-7 — MOST_EXPENSIVE (MULTIPLE_CHOICE). */
function buildMostExpensive(items: Product[]): BuildResult {
  if (items.length < 3 || items.length > 4) {
    return {
      ok: false,
      error: logicError(
        "entities",
        "MOST_EXPENSIVE cần 3-4 sản phẩm.",
        "E_GAME_LOGIC_INVALID",
      ),
    };
  }
  const sorted = [...items].sort((x, y) => y.price - x.price);
  const top = sorted[0];
  const second = sorted[1];
  const gap = (top.price - second.price) / Math.max(second.price, 1);
  if (gap < 0.02) {
    return {
      ok: false,
      error: logicError(
        "gameplay.answer",
        `Top 2 chênh lệch ${(gap * 100).toFixed(1)}% < 2% — dễ hoà. Chọn SKU khác.`,
        "E_MOST_EXPENSIVE_TIE",
      ),
    };
  }
  const prices: Record<string, number> = {};
  for (const item of items) prices[item.productId] = item.price;
  return {
    ok: true,
    gameplay: {
      kind: "MOST_EXPENSIVE",
      productIds: items.map((item) => item.productId),
      prices,
      answer: top.productId,
    },
  };
}

/** FR-8 — ONE_AWAY (DIGIT). */
function buildOneAway(items: Product[], rng: Rng): BuildResult {
  const product = items[0];
  if (!product) {
    return {
      ok: false,
      error: logicError(
        "entities",
        "ONE_AWAY cần 1 sản phẩm.",
        "E_GAME_LOGIC_INVALID",
      ),
    };
  }
  const digits = product.price.toString();
  if (digits.length < 6) {
    return {
      ok: false,
      error: logicError(
        "gameplay.price",
        "Giá cần ≥ 6 chữ số để ẩn 1 digit có ý nghĩa.",
        "E_GAME_LOGIC_INVALID",
      ),
    };
  }
  // Any non-leading digit can be hidden; the decoy stays exactly 1 unit away.
  // Digits 1-8 make a more interesting question than a trailing 0/9, but we
  // never reject a SKU just because its digits are 0s and 9s.
  const everyDigit = digits
    .split("")
    .map((digit, index) => ({ index, digit: Number(digit) }))
    .filter((entry) => entry.index > 0);
  const preferred = everyDigit.filter(
    (entry) => entry.digit >= 1 && entry.digit <= 8,
  );
  const candidates = preferred.length > 0 ? preferred : everyDigit;
  if (candidates.length === 0) {
    return {
      ok: false,
      error: logicError(
        "gameplay.hidden_index",
        "Không có digit hợp lệ để ẩn (cần vị trí sau chữ số đầu tiên).",
        "E_GAME_LOGIC_INVALID",
      ),
    };
  }
  const chosen = rng.pick(candidates);
  const correctDigit = chosen.digit;
  const otherDigit =
    correctDigit >= 9
      ? correctDigit - 1
      : correctDigit <= 0
        ? correctDigit + 1
        : rng.bool()
          ? correctDigit + 1
          : correctDigit - 1;
  const options = rng.shuffle([correctDigit, otherDigit]) as [number, number];

  return {
    ok: true,
    gameplay: {
      kind: "ONE_AWAY",
      productIds: [product.productId],
      price: product.price,
      hiddenIndex: chosen.index,
      correctDigit,
      options,
    },
  };
}

export function buildGameplay(
  mechanic: Mechanic,
  items: Product[],
  seed: number,
): BuildResult {
  const rng = createRng(seed);
  switch (mechanic) {
    case "HI_LO":
      return buildHiLo(items);
    case "MOST_EXPENSIVE":
      return buildMostExpensive(items);
    case "ONE_AWAY":
      return buildOneAway(items, rng);
    default:
      return {
        ok: false,
        error: logicError(
          "metadata.mechanic",
          "MVP chỉ hỗ trợ HI_LO, MOST_EXPENSIVE, ONE_AWAY.",
          "E_SCHEMA_MISSING_FIELD",
        ),
      };
  }
}

/** FR-4 — answer is recomputed from entities, never trusted from input. */
export function recomputeAnswer(gameplay: Gameplay): string {
  switch (gameplay.kind) {
    case "HI_LO":
      return gameplay.priceB > gameplay.priceA ? "higher" : "lower";
    case "MOST_EXPENSIVE": {
      const entries = Object.entries(gameplay.prices);
      return entries.reduce(
        (best, [id, price]) => (price > (gameplay.prices[best] ?? 0) ? id : best),
        entries[0]?.[0] ?? "",
      );
    }
    case "ONE_AWAY":
      return String(gameplay.price)[gameplay.hiddenIndex];
    default:
      return "";
  }
}

export function currentAnswer(gameplay: Gameplay): string {
  switch (gameplay.kind) {
    case "HI_LO":
      return gameplay.answer;
    case "MOST_EXPENSIVE":
      return gameplay.answer;
    case "ONE_AWAY":
      return String(gameplay.correctDigit);
    default:
      return "";
  }
}

/** Short, speakable answer line — engine owned, ≤ 4 words (FR-9 voice sync). */
export function describeAnswerShort(
  gameplay: Gameplay,
  entities: Product[],
): string {
  void entities;
  switch (gameplay.kind) {
    case "HI_LO":
      return gameplay.answer === "higher" ? "cao hơn!" : "thấp hơn!";
    case "MOST_EXPENSIVE": {
      const index = Math.max(gameplay.productIds.indexOf(gameplay.answer), 0);
      return `lựa chọn ${String.fromCharCode(65 + index)}!`;
    }
    case "ONE_AWAY":
      return `số ${gameplay.correctDigit}!`;
    default:
      return "đây rồi!";
  }
}

export function describeAnswer(
  gameplay: Gameplay,
  entities: Product[],
): string {
  const byId = new Map(entities.map((item) => [item.productId, item]));
  switch (gameplay.kind) {
    case "HI_LO":
      return gameplay.answer === "higher"
        ? `CAO HƠN — ${byId.get(gameplay.productIds[1])?.name ?? ""} ${formatVnd(
            gameplay.priceB,
          )}`
        : `THẤP HƠN — ${byId.get(gameplay.productIds[1])?.name ?? ""} ${formatVnd(
            gameplay.priceB,
          )}`;
    case "MOST_EXPENSIVE":
      return `${byId.get(gameplay.answer)?.name ?? ""} — ${formatVnd(
        gameplay.prices[gameplay.answer] ?? 0,
      )}`;
    case "ONE_AWAY":
      return `Digit ẩn là ${gameplay.correctDigit} → ${groupDigits(
        maskPrice(gameplay.price, gameplay.hiddenIndex, String(gameplay.correctDigit)),
      )}`;
    default:
      return "";
  }
}

export function engineChoices(gameplay: Gameplay): string[] {
  switch (gameplay.kind) {
    case "HI_LO":
      return ["CAO HƠN ⬆️", "THẤP HƠN ⬇️"];
    case "MOST_EXPENSIVE":
      return gameplay.productIds.map((_, index) =>
        String.fromCharCode(65 + index),
      );
    case "ONE_AWAY":
      return gameplay.options.map((digit) => String(digit));
    default:
      return [];
  }
}

export function interactionOf(mechanic: Mechanic) {
  return INTERACTION_BY_MECHANIC[mechanic];
}
