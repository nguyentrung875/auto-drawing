/**
 * Universal Game Video Engine — shared kernel types (AD-1 shared kernel).
 * Pure types only: no imports, no runtime code, no cycles.
 */

export type Mechanic = "HI_LO" | "MOST_EXPENSIVE" | "ONE_AWAY";
export type Interaction = "BOOLEAN" | "MULTIPLE_CHOICE" | "DIGIT";
export type SceneType =
  | "hook"
  | "product"
  | "question"
  | "countdown"
  | "reveal"
  | "result"
  | "cta";
export type ResultVariant = "in_video" | "comment";
export type SfxType =
  | "countdown"
  | "tick"
  | "reveal"
  | "correct"
  | "wrong"
  | "transition";

export const MECHANICS: readonly Mechanic[] = [
  "HI_LO",
  "MOST_EXPENSIVE",
  "ONE_AWAY",
];

export const INTERACTION_BY_MECHANIC: Record<Mechanic, Interaction> = {
  HI_LO: "BOOLEAN",
  MOST_EXPENSIVE: "MULTIPLE_CHOICE",
  ONE_AWAY: "DIGIT",
};

export const MVP_SCENES: readonly SceneType[] = [
  "hook",
  "product",
  "question",
  "countdown",
  "reveal",
  "result",
  "cta",
];

export interface Product {
  productId: string;
  name: string;
  image: string;
  /** VND integer. Always resolved from ProductProvider, never from LLM. */
  price: number;
  currency: "VND";
  source: string;
  updatedAt: string;
  category: string;
  brand: string;
  affiliateLink: string;
  emoji: string;
}

export interface GameMetadata {
  gameId: string;
  mechanic: Mechanic;
  interaction: Interaction;
  language: "vi-VN";
  difficulty: "easy" | "medium" | "hard";
  seed: number;
  resultVariant: ResultVariant;
  createdAt: string;
  engineVersion: string;
}

export interface GameContent {
  title: string;
  hook: string;
  question: string;
  choices: string[];
  cta: string;
  caption: string;
  hashtags: string[];
  voiceScript: string;
  /** Where the copy came from: LLM adapter or deterministic local template. */
  source: string;
}

export type Gameplay =
  | {
      kind: "HI_LO";
      productIds: [string, string];
      priceA: number;
      priceB: number;
      answer: "higher" | "lower";
    }
  | {
      kind: "MOST_EXPENSIVE";
      productIds: string[];
      prices: Record<string, number>;
      answer: string;
    }
  | {
      kind: "ONE_AWAY";
      productIds: [string];
      price: number;
      hiddenIndex: number;
      correctDigit: number;
      options: [number, number];
    };

export interface SceneSpec {
  type: SceneType;
  duration: number;
  variant?: ResultVariant;
  componentRefs: string[];
}

export interface AudioCue {
  type: SfxType;
  at: number;
  label: string;
}

export interface VoiceSegment {
  text: string;
  startAt: number;
  estimatedDuration: number;
  /** true when this segment must land on the RevealScene (±0.1s, FR-9). */
  revealLocked: boolean;
}

export interface GameAudio {
  voice: {
    script: string;
    voice: string;
    adapter: string;
    wavPath: string;
    segments: VoiceSegment[];
  };
  music: { track: string; volume: number };
  sfx: AudioCue[];
}

export interface SceneTiming {
  type: SceneType;
  start: number;
  duration: number;
  end: number;
}

export interface Timeline {
  totalDuration: number;
  sceneTimings: SceneTiming[];
}

export interface Diversification {
  paperColor: string;
  inkColor: string;
  accentColor: string;
  tiltDeg: number;
  bgmTrack: string;
  layout: "grid-a" | "grid-b" | "stack";
}

export interface Publishing {
  caption: string;
  hashtags: string[];
  affiliateLink: string;
  outputPath: string;
}

export interface GameJson {
  metadata: GameMetadata;
  content: GameContent;
  entities: Product[];
  gameplay: Gameplay;
  scenes: SceneSpec[];
  timeline: Timeline;
  audio: GameAudio;
  diversification: Diversification;
  publishing: Publishing;
}

export interface ValidationError {
  code: string;
  field: string;
  hint: string;
  layer: "schema" | "game_logic" | "asset" | "render";
}

export interface ValidationResult {
  ok: boolean;
  errors: ValidationError[];
  warnings: string[];
  durationMs: number;
}

/** Deterministic, serialisable render plan consumed by the canvas renderer. */
export interface PlannedCard {
  productId: string;
  name: string;
  emoji: string;
  brand: string;
  priceLabel: string;
  maskedPriceLabel?: string;
  slot: number;
  emphasized: boolean;
  colorFrom: string;
  colorTo: string;
}

export interface PlannedScene {
  type: SceneType;
  start: number;
  duration: number;
  end: number;
  headline: string;
  subline: string;
  body: string;
  choices: string[];
  cardIds: string[];
  revealKind: "price" | "digit" | "choice";
  revealPrefix: string;
  revealDigitBefore: string;
  revealDigitAfter: string;
  answerText: string;
  variant: ResultVariant;
  countdownFrom: number;
  badges: string[];
}

export interface RenderPlan {
  gameId: string;
  seed: number;
  mechanic: Mechanic;
  interaction: Interaction;
  width: 1080;
  height: 1920;
  fps: 30;
  totalDuration: number;
  frames: number;
  diversification: Diversification;
  cards: PlannedCard[];
  scenes: PlannedScene[];
  audio: GameAudio;
}

export interface JobTimings {
  planning_ms: number;
  tts_ms: number;
  render_ms: number;
  encode_ms: number;
  total_ms: number;
  audio_voice_ms: number;
  render_payload_bytes: number;
}

export interface BatchReportJob {
  jobId: string;
  gameId: string;
  mechanic: Mechanic;
  seed: number;
  productIds: string[];
  status: "done" | "failed";
  render_ms: number;
  outputPath: string | null;
  errors: ValidationError[];
  warnings: string[];
}

export interface BatchReport {
  batchId: string;
  createdAt: string;
  finishedAt: string | null;
  total: number;
  passed: number;
  failed: number;
  avgRenderMs: number;
  distinctProducts: number;
  workerPoolMax: number;
  manualInterventions: 0;
  jobs: BatchReportJob[];
}
