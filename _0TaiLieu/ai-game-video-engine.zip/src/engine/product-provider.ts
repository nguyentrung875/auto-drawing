import "server-only";
import { asc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { products as productsTable, type ProductRow } from "@/db/schema";
import { SEED_PRODUCTS, STALE_PRICE_DAYS } from "@/db/seed-data";
import type { Product } from "@/engine/types";

let seedPromise: Promise<void> | null = null;

async function seedIfEmpty(): Promise<void> {
  const [row] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(productsTable);
  if ((row?.count ?? 0) >= SEED_PRODUCTS.length) return;

  await db
    .insert(productsTable)
    .values(
      SEED_PRODUCTS.map((product) => ({
        productId: product.productId,
        name: product.name,
        image: product.image,
        price: product.price,
        currency: product.currency,
        source: product.source,
        updatedAt: new Date(product.updatedAt),
        category: product.category,
        brand: product.brand,
        affiliateLink: product.affiliateLink,
        emoji: product.emoji,
      })),
    )
    .onConflictDoNothing();
}

/** Idempotent, memoised bootstrap of the mock Product DB. */
export function ensureSeeded(): Promise<void> {
  if (!seedPromise) {
    seedPromise = seedIfEmpty().catch((error) => {
      seedPromise = null;
      throw error;
    });
  }
  return seedPromise;
}

function toProduct(row: ProductRow): Product {
  return {
    productId: row.productId,
    name: row.name,
    image: row.image,
    price: row.price,
    currency: "VND",
    source: row.source,
    updatedAt: row.updatedAt.toISOString(),
    category: row.category,
    brand: row.brand,
    affiliateLink: row.affiliateLink,
    emoji: row.emoji,
  };
}

export async function listProducts(): Promise<Product[]> {
  await ensureSeeded();
  const rows = await db
    .select()
    .from(productsTable)
    .orderBy(asc(productsTable.productId));
  return rows.map(toProduct);
}

export async function getProducts(ids: string[]): Promise<Product[]> {
  const unique = [...new Set(ids)];
  if (unique.length === 0) return [];
  const all = await listProducts();
  const byId = new Map(all.map((product) => [product.productId, product]));
  return ids
    .map((id) => byId.get(id))
    .filter((product): product is Product => Boolean(product));
}

export function staleInfo(product: Product): {
  ageDays: number;
  stale: boolean;
} {
  const ageDays = Math.floor(
    (Date.now() - new Date(product.updatedAt).getTime()) / 86_400_000,
  );
  return { ageDays, stale: ageDays > STALE_PRICE_DAYS };
}

/** FR-2: price/affiliate_link edits require no code change, just a reload. */
export async function updateProductPrice(
  productId: string,
  price: number,
): Promise<Product | null> {
  await ensureSeeded();
  const [row] = await db
    .update(productsTable)
    .set({ price, updatedAt: new Date() })
    .where(eq(productsTable.productId, productId))
    .returning();
  return row ? toProduct(row) : null;
}
