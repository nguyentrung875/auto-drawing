import { formatVnd, groupDigits, maskPrice } from "@/engine/format";
import { hashString, type Rng } from "@/engine/rng";
import { describeAnswer } from "@/engine/mechanics";
import type {
  Diversification,
  GameJson,
  PlannedCard,
  PlannedScene,
  RenderPlan,
  ResultVariant,
  SceneType,
} from "@/engine/types";

const PAPERS = ["#f7f2e7", "#eef3f6", "#f4eef5", "#eef6ef", "#f6efe9"];
const INKS = ["#171a21", "#141b26", "#221b17", "#101c1a"];
const ACCENTS = ["#ff5a36", "#12a594", "#e0245e", "#f4b400", "#3b82f6"];
const BGMS = ["tension_01", "tension_02", "quiz_lofi_03", "pulse_04"];

/** AD-10 — diversification must come from the seeded PRNG, never Math.random. */
export function buildDiversification(rng: Rng): Diversification {
  return {
    paperColor: rng.pick(PAPERS),
    inkColor: rng.pick(INKS),
    accentColor: rng.pick(ACCENTS),
    tiltDeg: Number(((rng.next() * 4 - 2)).toFixed(2)),
    bgmTrack: rng.pick(BGMS),
    layout: rng.pick(["grid-a", "grid-b", "stack"] as const),
  };
}

function cardColors(productId: string): { from: string; to: string } {
  const hue = hashString(productId) % 360;
  return {
    from: `hsl(${hue} 78% 64%)`,
    to: `hsl(${(hue + 46) % 360} 70% 34%)`,
  };
}

const MECHANIC_LABEL: Record<string, string> = {
  HI_LO: "CAO HƠN / THẤP HƠN",
  MOST_EXPENSIVE: "CHỌN MÓN ĐẮT NHẤT",
  ONE_AWAY: "ĐIỀN SỐ CÒN THIẾU",
};

/**
 * FR-10 — deterministic frame plan. The same Game JSON + seed always yields an
 * identical plan (this is the "pen tip = drawing path" guarantee for quiz text,
 * prices and timers: every glyph is placed by code, not by a diffusion model).
 */
export function buildRenderPlan(game: GameJson): RenderPlan {
  const cards: PlannedCard[] = game.entities.map((entity, index) => {
    const colors = cardColors(entity.productId);
    const digits = Math.round(entity.price).toString();
    return {
      productId: entity.productId,
      name: entity.name,
      emoji: entity.emoji,
      brand: entity.brand,
      priceLabel: `${groupDigits(digits)}₫`,
      maskedPriceLabel:
        game.gameplay.kind === "ONE_AWAY" &&
        game.gameplay.productIds[0] === entity.productId
          ? `${groupDigits(maskPrice(entity.price, game.gameplay.hiddenIndex))}₫`
          : undefined,
      slot: index,
      emphasized:
        game.gameplay.kind === "MOST_EXPENSIVE" &&
        game.gameplay.answer === entity.productId,
      colorFrom: colors.from,
      colorTo: colors.to,
    };
  });

  const answerText = describeAnswer(game.gameplay, game.entities);
  const timingByType = new Map(
    game.timeline.sceneTimings.map((scene) => [scene.type, scene]),
  );

  const scenes: PlannedScene[] = game.timeline.sceneTimings.map((timing) => {
    const base: PlannedScene = {
      type: timing.type,
      start: timing.start,
      duration: timing.duration,
      end: timing.end,
      headline: "",
      subline: "",
      body: "",
      choices: [],
      cardIds: [],
      revealKind: "price",
      revealPrefix: "",
      revealDigitBefore: "",
      revealDigitAfter: "",
      answerText,
      variant: game.metadata.resultVariant,
      countdownFrom: 3,
      badges: [],
    };
    const t = timing.type as SceneType;
    if (t === "hook") {
      base.headline = game.content.hook;
      base.subline = MECHANIC_LABEL[game.metadata.mechanic] ?? "";
      base.badges = [`SEED ${game.metadata.seed}`, `#${game.metadata.gameId}`];
    } else if (t === "product") {
      base.headline =
        game.metadata.mechanic === "ONE_AWAY"
          ? "Giá của món này là bao nhiêu?"
          : "Sản phẩm trong vòng này";
      base.subline = `${game.entities.length} SKU từ ProductProvider`;
      base.cardIds = game.entities.map((entity) => entity.productId);
    } else if (t === "question") {
      base.headline = game.content.question;
      base.subline = game.metadata.interaction;
      base.choices = game.content.choices;
      base.cardIds = game.entities.map((entity) => entity.productId);
    } else if (t === "countdown") {
      base.headline = "3";
      base.subline = "Nghĩ đi rồi đoán!";
      base.badges = ["ĐOÁN NHANH", "3 GIÂY"];
    } else if (t === "reveal") {
      base.revealKind =
        game.metadata.mechanic === "ONE_AWAY"
          ? "digit"
          : game.metadata.mechanic === "MOST_EXPENSIVE"
            ? "choice"
            : "price";
      base.revealPrefix = "ĐÁP ÁN";
      if (game.gameplay.kind === "ONE_AWAY") {
        const gameplay = game.gameplay;
        const card = cards[0];
        const wrongOption = gameplay.options.find(
          (option) => option !== gameplay.correctDigit,
        );
        base.revealDigitBefore = card?.maskedPriceLabel ?? "";
        base.revealDigitAfter = card?.priceLabel ?? "";
        base.headline = "Số còn thiếu là";
        base.subline = `${gameplay.correctDigit} — không phải ${wrongOption ?? "?"}`;
      } else {
        base.headline = answerText;
        base.subline = "Đúng như bạn đoán chưa?";
      }
      base.cardIds = game.entities.map((entity) => entity.productId);
    } else if (t === "result") {
      base.variant = game.metadata.resultVariant;
      base.headline =
        game.metadata.resultVariant === "in_video"
          ? answerText
          : "Đáp án ở comment 👇";
      base.subline =
        game.metadata.resultVariant === "in_video"
          ? "Bạn đoán đúng chứ?"
          : "Comment xem đáp án + link giỏ hàng";
      base.badges =
        game.metadata.resultVariant === "in_video"
          ? ["IN-VIDEO REVEAL"]
          : ["COMMENT BAIT"];
      base.cardIds = game.entities.map((entity) => entity.productId);
    } else {
      base.headline = game.content.cta;
      base.subline = game.content.hashtags[0] ?? "#tiktokshop";
      base.body = game.content.hashtags.join(" ");
      base.badges = [formatVnd(game.entities[0]?.price ?? 0), "AFFILIATE"];
    }
    void timingByType;
    return base;
  });

  const frames = Math.round(game.timeline.totalDuration * 30);

  return {
    gameId: game.metadata.gameId,
    seed: game.metadata.seed,
    mechanic: game.metadata.mechanic,
    interaction: game.metadata.interaction,
    width: 1080,
    height: 1920,
    fps: 30,
    totalDuration: game.timeline.totalDuration,
    frames,
    diversification: game.diversification,
    cards,
    scenes,
    audio: game.audio,
  };
}

export function captionPayload(game: GameJson) {
  return {
    caption: game.publishing.caption,
    hashtags: game.publishing.hashtags,
    affiliate_link: game.publishing.affiliateLink,
    output_path: game.publishing.outputPath,
    answer: describeAnswer(game.gameplay, game.entities),
    result_variant: game.metadata.resultVariant as ResultVariant,
    seed: game.metadata.seed,
  };
}
