import { wordCount } from "@/engine/format";
import { SCENE_DURATIONS } from "@/engine/validator";
import type {
  Diversification,
  GameAudio,
  GameContent,
  Gameplay,
  Mechanic,
  Product,
  ResultVariant,
  SceneSpec,
  Timeline,
} from "@/engine/types";

export interface TimelineInput {
  gameId: string;
  mechanic: Mechanic;
  resultVariant: ResultVariant;
  content: GameContent;
  entities: Product[];
  gameplay: Gameplay;
  voiceIntro: string;
  voiceReveal: string;
  diversification: Diversification;
}

const EST_SECONDS_PER_WORD = 0.42;

function voiceDuration(text: string): number {
  return Math.min(3.2, wordCount(text) * EST_SECONDS_PER_WORD + 0.4);
}

export interface TimelineOutput {
  scenes: SceneSpec[];
  timeline: Timeline;
  audio: GameAudio;
}

/**
 * FR-4 / FR-5 — deterministic scene ordering, durations and audio cues.
 * Hook 2s → Product 3s → Question 3s → Countdown 3s → Reveal 2s → Result → CTA.
 */
export function buildTimeline(input: TimelineInput): TimelineOutput {
  const { resultVariant } = input;
  const durations: Record<string, number> = {
    ...SCENE_DURATIONS,
    result: resultVariant === "in_video" ? 2.5 : 2,
  };

  const order = [
    "hook",
    "product",
    "question",
    "countdown",
    "reveal",
    "result",
    "cta",
  ] as const;

  const scenes: SceneSpec[] = order.map((type) => ({
    type,
    duration: durations[type],
    variant: type === "result" ? resultVariant : undefined,
    componentRefs: [`${type[0].toUpperCase()}${type.slice(1)}Scene`],
  }));

  let cursor = 0;
  const sceneTimings = scenes.map((scene) => {
    const start = cursor;
    cursor += scene.duration;
    return {
      type: scene.type,
      start,
      duration: scene.duration,
      end: cursor,
    };
  });
  const totalDuration = cursor;

  const at = (type: string) =>
    sceneTimings.find((scene) => scene.type === type)?.start ?? 0;
  const end = (type: string) =>
    sceneTimings.find((scene) => scene.type === type)?.end ?? 0;

  const sfx: GameAudio["sfx"] = [];
  for (const scene of sceneTimings) {
    if (scene.type === "hook") continue;
    sfx.push({
      type: "transition",
      at: Number(scene.start.toFixed(2)),
      label: `transition → ${scene.type}`,
    });
  }
  const countdownStart = at("countdown");
  for (let i = 0; i < 6; i += 1) {
    sfx.push({
      type: i === 0 ? "tick" : "countdown",
      at: Number((countdownStart + i * 0.5).toFixed(2)),
      label: `countdown tick ${(countdownStart + i * 0.5).toFixed(1)}s`,
    });
  }
  const revealStart = at("reveal");
  sfx.push({ type: "reveal", at: revealStart, label: "reveal flip" });
  sfx.push({
    type: "correct",
    at: Number((revealStart + 0.2).toFixed(2)),
    label: "correct chime",
  });

  const audio: GameAudio = {
    voice: {
      script: input.content.voiceScript,
      voice: "vi-VN-vais-1000-medium",
      adapter: "ViPiperEngine (offline, MIT)",
      wavPath: `temp/${input.gameId}/voice.wav`,
      segments: [
        {
          text: input.voiceIntro,
          startAt: 0.15,
          estimatedDuration: voiceDuration(input.voiceIntro),
          revealLocked: false,
        },
        {
          text: input.voiceReveal,
          startAt: revealStart,
          estimatedDuration: voiceDuration(input.voiceReveal),
          revealLocked: true,
        },
      ],
    },
    music: {
      track: input.diversification.bgmTrack,
      volume: 0.18,
    },
    sfx,
  };

  return {
    scenes,
    timeline: { totalDuration, sceneTimings },
    audio,
  };
}
