import { performance } from "node:perf_hooks";
import { createRng } from "@/engine/rng";
import {
  buildGameplay,
  describeAnswer,
  describeAnswerShort,
} from "@/engine/mechanics";
import { generateContent } from "@/engine/content";
import { buildDiversification, captionPayload } from "@/engine/render-plan";
import { buildTimeline } from "@/engine/timeline";
import { validateGame } from "@/engine/validator";
import { groupDigits, maskPrice } from "@/engine/format";
import type {
  GameJson,
  Mechanic,
  Product,
  ResultVariant,
  ValidationError,
} from "@/engine/types";
import { INTERACTION_BY_MECHANIC } from "@/engine/types";

export const ENGINE_VERSION = "ugve-1.0.0";

export interface ComposeInput {
  gameId: string;
  mechanic: Mechanic;
  seed: number;
  resultVariant: ResultVariant;
  entities: Product[];
}

export type ComposeResult =
  | {
      ok: true;
      game: GameJson;
      warnings: string[];
      contentSource: string;
      planningMs: number;
      validatorMs: number;
    }
  | {
      ok: false;
      errors: ValidationError[];
      warnings: string[];
      planningMs: number;
      validatorMs: number;
      contentSource: string;
    };

/**
 * Pipeline stage 1: LLM copy (never price) → deterministic gameplay → timeline.
 * The composed Game JSON is then pushed through the two-layer Validator.
 */
export async function composeGame(
  input: ComposeInput,
  providerProducts: Product[],
  knownGameIds: string[] = [],
): Promise<ComposeResult> {
  const startedAt = performance.now();
  const warnings: string[] = [];
  const { entities, mechanic, seed, resultVariant, gameId } = input;

  const built = buildGameplay(mechanic, entities, seed);
  if (!built.ok) {
    return {
      ok: false,
      errors: [built.error],
      warnings,
      planningMs: performance.now() - startedAt,
      validatorMs: 0,
      contentSource: "engine",
    };
  }

  const answerText = describeAnswer(built.gameplay, entities);
  const answerShort = describeAnswerShort(built.gameplay, entities);
  const maskedPrice =
    built.gameplay.kind === "ONE_AWAY"
      ? groupDigits(maskPrice(built.gameplay.price, built.gameplay.hiddenIndex))
      : undefined;

  const contentResult = await generateContent({
    mechanic,
    entities,
    gameplay: built.gameplay,
    seed,
    answerText,
    answerShort,
    maskedPrice,
  });
  warnings.push(...contentResult.warnings);

  const diversification = buildDiversification(createRng(seed + 7919));
  const { scenes, timeline, audio } = buildTimeline({
    gameId,
    mechanic,
    resultVariant,
    content: contentResult.content,
    entities,
    gameplay: built.gameplay,
    voiceIntro: contentResult.voiceIntro,
    voiceReveal: contentResult.voiceReveal,
    diversification,
  });

  const game: GameJson = {
    metadata: {
      gameId,
      mechanic,
      interaction: INTERACTION_BY_MECHANIC[mechanic],
      language: "vi-VN",
      difficulty:
        mechanic === "HI_LO" ? "easy" : mechanic === "ONE_AWAY" ? "medium" : "hard",
      seed,
      resultVariant,
      createdAt: new Date().toISOString(),
      engineVersion: ENGINE_VERSION,
    },
    content: contentResult.content,
    entities,
    gameplay: built.gameplay,
    scenes,
    timeline,
    audio,
    diversification,
    publishing: {
      caption: contentResult.content.caption,
      hashtags: contentResult.content.hashtags,
      affiliateLink: entities[0]?.affiliateLink ?? "",
      outputPath: `export/${gameId}.mp4`,
    },
  };

  const validation = validateGame(game, { providerProducts, knownGameIds });
  warnings.push(...validation.warnings);

  if (!validation.ok) {
    return {
      ok: false,
      errors: validation.errors,
      warnings,
      planningMs: performance.now() - startedAt,
      validatorMs: validation.durationMs,
      contentSource: contentResult.source,
    };
  }

  return {
    ok: true,
    game,
    warnings,
    contentSource: contentResult.source,
    planningMs: performance.now() - startedAt,
    validatorMs: validation.durationMs,
  };
}

export { captionPayload };
