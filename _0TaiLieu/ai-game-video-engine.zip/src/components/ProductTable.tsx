"use client";

import { useMemo, useState } from "react";
import { Tag } from "@/components/ui";
import { formatVnd } from "@/engine/format";

export interface ProductRowView {
  productId: string;
  name: string;
  brand: string;
  category: string;
  price: number;
  image: string;
  affiliateLink: string;
  updatedAt: string;
  ageDays: number;
  stale: boolean;
}

export default function ProductTable({
  initial,
}: {
  initial: ProductRowView[];
}) {
  const [rows, setRows] = useState(initial);
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("all");
  const [drafts, setDrafts] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const categories = useMemo(
    () => ["all", ...new Set(rows.map((row) => row.category))],
    [rows],
  );

  const filtered = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return rows.filter((row) => {
      const matchesCategory = category === "all" || row.category === category;
      const matchesQuery =
        needle === "" ||
        row.name.toLowerCase().includes(needle) ||
        row.brand.toLowerCase().includes(needle) ||
        row.productId.includes(needle);
      return matchesCategory && matchesQuery;
    });
  }, [category, query, rows]);

  async function save(productId: string) {
    const raw = drafts[productId];
    if (raw === undefined) return;
    const price = Number(raw);
    if (!Number.isInteger(price) || price <= 0) {
      setNotice(`⚠ ${productId}: giá phải là số nguyên VND > 0.`);
      return;
    }
    setSaving(productId);
    try {
      const response = await fetch("/api/products", {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ productId, price }),
      });
      const payload = (await response.json()) as {
        ok?: boolean;
        product?: ProductRowView;
        error?: string;
      };
      if (!response.ok || !payload.ok || !payload.product) {
        setNotice(`⚠ ${payload.error ?? "update thất bại"}`);
        return;
      }
      setRows((current) =>
        current.map((row) =>
          row.productId === productId
            ? {
                ...row,
                price: payload.product!.price,
                updatedAt: payload.product!.updatedAt,
                ageDays: payload.product!.ageDays,
                stale: payload.product!.stale,
              }
            : row,
        ),
      );
      setDrafts((current) => {
        const next = { ...current };
        delete next[productId];
        return next;
      });
      setNotice(`✓ ${productId} → ${formatVnd(price)} (ProductProvider reloaded)`);
    } finally {
      setSaving(null);
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="tìm theo tên / brand / productId…"
          className="mono w-64 rounded-lg border border-white/10 bg-black/40 px-3 py-2 text-sm text-white outline-none focus:border-[#ff5a36]/60"
        />
        <select
          value={category}
          onChange={(event) => setCategory(event.target.value)}
          className="mono rounded-lg border border-white/10 bg-black/40 px-3 py-2 text-sm text-slate-200 outline-none"
        >
          {categories.map((item) => (
            <option key={item} value={item} className="bg-[#0b0f16]">
              {item}
            </option>
          ))}
        </select>
        <span className="mono text-xs text-slate-500">
          {filtered.length}/{rows.length} SKU
        </span>
        {notice && (
          <span className="mono ml-auto text-xs text-slate-300">{notice}</span>
        )}
      </div>

      <div className="overflow-x-auto rounded-xl border border-white/8">
        <table className="w-full text-left text-xs">
          <thead className="mono bg-black/40 text-[10px] uppercase tracking-[0.12em] text-slate-500">
            <tr>
              <th className="p-3">asset</th>
              <th className="p-3">productId</th>
              <th className="p-3">name</th>
              <th className="p-3">category</th>
              <th className="p-3">price (VND)</th>
              <th className="p-3">updated</th>
              <th className="p-3">affiliate_link</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {filtered.map((row) => {
              const draft = drafts[row.productId];
              return (
                <tr key={row.productId} className="text-slate-300">
                  <td className="p-3">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={row.image}
                      alt=""
                      className="h-11 w-11 rounded-lg"
                    />
                  </td>
                  <td className="mono p-3 text-slate-400">{row.productId}</td>
                  <td className="p-3">
                    <span className="block max-w-[240px] truncate text-slate-200">
                      {row.name}
                    </span>
                    <span className="mono text-[10px] text-slate-500">
                      {row.brand}
                    </span>
                  </td>
                  <td className="p-3 text-slate-400">{row.category}</td>
                  <td className="p-3">
                    <div className="flex items-center gap-2">
                      <input
                        value={draft ?? String(row.price)}
                        onChange={(event) =>
                          setDrafts((current) => ({
                            ...current,
                            [row.productId]: event.target.value,
                          }))
                        }
                        className="mono w-28 rounded-md border border-white/10 bg-black/40 px-2 py-1 text-[11px] text-white outline-none focus:border-[#12a594]/60"
                      />
                      {draft !== undefined && (
                        <button
                          type="button"
                          onClick={() => save(row.productId)}
                          disabled={saving === row.productId}
                          className="mono rounded-md bg-[#12a594] px-2 py-1 text-[10px] font-bold text-black disabled:opacity-50"
                        >
                          {saving === row.productId ? "…" : "SAVE"}
                        </button>
                      )}
                    </div>
                  </td>
                  <td className="mono p-3 text-[11px]">
                    {row.stale ? (
                      <span className="text-amber-300">stale · {row.ageDays}d</span>
                    ) : (
                      <span className="text-slate-500">{row.ageDays}d</span>
                    )}
                  </td>
                  <td className="mono p-3">
                    <a
                      href={row.affiliateLink}
                      target="_blank"
                      rel="noreferrer"
                      className="block max-w-[200px] truncate text-[#12a594] hover:underline"
                    >
                      {row.affiliateLink.replace("https://", "")}
                    </a>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <p className="mono text-[11px] text-slate-500">
        FR-2 · sửa giá là data-only (reload Provider, không cần code change). SKU
        &gt;7 ngày chưa update sẽ bị Hermes gắn <Tag tone="amber">stale_price</Tag>{" "}
        và không đăng (UJ-3).
      </p>
    </div>
  );
}
