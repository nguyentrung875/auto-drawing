import type { ReactNode } from "react";

export function Panel({
  title,
  subtitle,
  actions,
  children,
  className = "",
}: {
  title?: string;
  subtitle?: string;
  actions?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <section
      className={`rounded-2xl border border-white/8 bg-white/[0.03] p-5 shadow-[0_18px_50px_rgba(0,0,0,0.35)] ${className}`}
    >
      {(title || actions) && (
        <div className="mb-4 flex flex-wrap items-start gap-3">
          <div>
            {title && (
              <h2 className="text-sm font-semibold uppercase tracking-[0.12em] text-slate-200">
                {title}
              </h2>
            )}
            {subtitle && (
              <p className="mt-1 max-w-2xl text-xs text-slate-500">{subtitle}</p>
            )}
          </div>
          {actions && <div className="ml-auto">{actions}</div>}
        </div>
      )}
      {children}
    </section>
  );
}

export function Stat({
  label,
  value,
  hint,
  tone = "default",
}: {
  label: string;
  value: string;
  hint?: string;
  tone?: "default" | "good" | "warn" | "bad";
}) {
  const tones: Record<string, string> = {
    default: "text-white",
    good: "text-emerald-300",
    warn: "text-amber-300",
    bad: "text-rose-300",
  };
  return (
    <div className="rounded-xl border border-white/8 bg-black/25 p-4">
      <p className="mono text-[10px] uppercase tracking-[0.16em] text-slate-500">
        {label}
      </p>
      <p className={`mt-2 text-2xl font-semibold ${tones[tone]}`}>{value}</p>
      {hint && <p className="mt-1 text-[11px] text-slate-500">{hint}</p>}
    </div>
  );
}

export function Tag({
  children,
  tone = "slate",
}: {
  children: ReactNode;
  tone?: "slate" | "orange" | "teal" | "rose" | "amber";
}) {
  const tones: Record<string, string> = {
    slate: "border-white/10 bg-white/5 text-slate-300",
    orange: "border-orange-400/30 bg-orange-400/10 text-orange-200",
    teal: "border-teal-400/30 bg-teal-400/10 text-teal-200",
    rose: "border-rose-400/30 bg-rose-400/10 text-rose-200",
    amber: "border-amber-400/30 bg-amber-400/10 text-amber-100",
  };
  return (
    <span
      className={`mono inline-flex items-center gap-1 rounded-md border px-2 py-0.5 text-[10px] uppercase tracking-[0.12em] ${tones[tone]}`}
    >
      {children}
    </span>
  );
}

export function ErrorList({
  errors,
  warnings,
}: {
  errors: { code: string; field: string; hint: string; layer: string }[];
  warnings?: string[];
}) {
  if (errors.length === 0 && (warnings?.length ?? 0) === 0) return null;
  return (
    <div className="space-y-2">
      {errors.map((error, index) => (
        <div
          key={`${error.code}-${index}`}
          className="rounded-xl border border-rose-500/30 bg-rose-500/10 p-3"
        >
          <p className="mono text-xs font-semibold text-rose-200">
            {error.code} · {error.field} · layer={error.layer}
          </p>
          <p className="mt-1 text-xs text-rose-100/80">{error.hint}</p>
        </div>
      ))}
      {(warnings ?? []).map((warning, index) => (
        <div
          key={`warn-${index}`}
          className="rounded-xl border border-amber-500/25 bg-amber-500/10 p-3"
        >
          <p className="mono text-xs text-amber-200">{warning}</p>
        </div>
      ))}
    </div>
  );
}
