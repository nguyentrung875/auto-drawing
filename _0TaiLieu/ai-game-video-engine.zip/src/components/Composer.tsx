"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { ErrorList, Panel, Tag } from "@/components/ui";
import { formatVnd } from "@/engine/format";
import type { Mechanic, ResultVariant, Timeline } from "@/engine/types";

export interface ComposerProduct {
  productId: string;
  name: string;
  brand: string;
  price: number;
  category: string;
  emoji: string;
  image: string;
  stale: boolean;
}

interface ValidatorError {
  code: string;
  field: string;
  hint: string;
  layer: string;
}

const MECHANIC_INFO: Record<
  Mechanic,
  { label: string; interaction: string; count: string; min: number; max: number; tone: "orange" | "teal" | "rose" }
> = {
  HI_LO: {
    label: "HI_LO",
    interaction: "BOOLEAN",
    count: "2 sản phẩm",
    min: 2,
    max: 2,
    tone: "orange",
  },
  MOST_EXPENSIVE: {
    label: "MOST_EXPENSIVE",
    interaction: "MULTIPLE_CHOICE",
    count: "3-4 sản phẩm",
    min: 3,
    max: 4,
    tone: "teal",
  },
  ONE_AWAY: {
    label: "ONE_AWAY",
    interaction: "DIGIT",
    count: "1 sản phẩm",
    min: 1,
    max: 1,
    tone: "rose",
  },
};

function randomInt(max: number) {
  if (typeof crypto !== "undefined" && crypto.getRandomValues) {
    const buffer = new Uint32Array(1);
    crypto.getRandomValues(buffer);
    return buffer[0] % Math.max(max, 1);
  }
  return 0;
}

export default function Composer({ products }: { products: ComposerProduct[] }) {
  const router = useRouter();
  const [mechanic, setMechanic] = useState<Mechanic>("HI_LO");
  const [selected, setSelected] = useState<string[]>([]);
  const [resultVariant, setResultVariant] = useState<ResultVariant>("in_video");
  const [seedText, setSeedText] = useState("");
  const [busy, setBusy] = useState<null | "dry" | "render">(null);
  const [errors, setErrors] = useState<ValidatorError[]>([]);
  const [warnings, setWarnings] = useState<string[]>([]);
  const [dryRun, setDryRun] = useState<{
    answer: string;
    timeline: Timeline;
    voiceScript: string;
    validatorMs: number;
    contentSource: string;
  } | null>(null);

  const info = MECHANIC_INFO[mechanic];
  const countOk = selected.length >= info.min && selected.length <= info.max;
  const seed = seedText.trim() === "" ? null : Number(seedText);

  const byId = useMemo(
    () => new Map(products.map((product) => [product.productId, product])),
    [products],
  );

  const selectedProducts = selected
    .map((id) => byId.get(id))
    .filter((product): product is ComposerProduct => Boolean(product));

  function autoPick() {
    const pool = [...products];
    if (mechanic === "ONE_AWAY") {
      const eligible = pool.filter((product) => product.price >= 100_000);
      const pick = eligible[randomInt(eligible.length)] ?? pool[0];
      setSelected([pick.productId]);
      return;
    }
    if (mechanic === "HI_LO") {
      for (let attempt = 0; attempt < 60; attempt += 1) {
        const a = pool[randomInt(pool.length)];
        const b = pool[randomInt(pool.length)];
        if (!a || !b || a.productId === b.productId) continue;
        const delta =
          Math.abs(b.price - a.price) / Math.min(a.price, b.price);
        if (delta >= 0.1) {
          setSelected([a.productId, b.productId]);
          return;
        }
      }
      setSelected([pool[0].productId, pool[1].productId]);
      return;
    }
    for (let attempt = 0; attempt < 60; attempt += 1) {
      const trio = Array.from({ length: 3 }, () => pool[randomInt(pool.length)]);
      const ids = new Set(trio.map((product) => product.productId));
      if (ids.size < 3) continue;
      const prices = trio.map((product) => product.price);
      const sorted = [...prices].sort((a, b) => b - a);
      if ((sorted[0] - sorted[1]) / sorted[1] >= 0.02) {
        setSelected(trio.map((product) => product.productId));
        return;
      }
    }
    setSelected(pool.slice(0, 3).map((product) => product.productId));
  }

  function toggle(productId: string) {
    setSelected((current) => {
      if (current.includes(productId)) {
        return current.filter((id) => id !== productId);
      }
      if (current.length >= info.max) {
        return [...current.slice(current.length - info.max + 1), productId];
      }
      return [...current, productId];
    });
  }

  async function submit(mode: "dry" | "render") {
    setBusy(mode);
    setErrors([]);
    setWarnings([]);
    setDryRun(null);
    try {
      const response = await fetch("/api/games", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          mechanic,
          productIds: selected,
          resultVariant,
          seed: seed !== null && Number.isFinite(seed) ? Math.abs(Math.trunc(seed)) : undefined,
          dryRun: mode === "dry",
        }),
      });
      const payload = (await response.json()) as {
        ok?: boolean;
        gameId?: string;
        errors?: ValidatorError[];
        warnings?: string[];
        answer?: string | null;
        timeline?: Timeline | null;
        voiceScript?: string | null;
        validatorMs?: number;
        contentSource?: string;
      };
      setWarnings(payload.warnings ?? []);
      if (!response.ok || !payload.ok) {
        setErrors(payload.errors ?? [{ code: "E_UNKNOWN", field: "request", hint: "Render thất bại.", layer: "render" }]);
        return;
      }
      if (mode === "dry" && payload.timeline && payload.answer) {
        setDryRun({
          answer: payload.answer,
          timeline: payload.timeline,
          voiceScript: payload.voiceScript ?? "",
          validatorMs: payload.validatorMs ?? 0,
          contentSource: payload.contentSource ?? "local-template",
        });
        return;
      }
      if (payload.gameId) {
        router.push(`/games/${payload.gameId}`);
      }
    } catch (error) {
      setErrors([
        {
          code: "E_NETWORK",
          field: "fetch",
          hint: (error as Error).message,
          layer: "render",
        },
      ]);
    } finally {
      setBusy(null);
    }
  }

  return (
    <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_360px]">
      <div className="space-y-4">
        <Panel title="1 · Mechanic" subtitle="MVP chứng minh 3 họ Interaction: BOOLEAN / MULTIPLE_CHOICE / DIGIT.">
          <div className="grid gap-3 sm:grid-cols-3">
            {(Object.keys(MECHANIC_INFO) as Mechanic[]).map((key) => {
              const item = MECHANIC_INFO[key];
              const active = key === mechanic;
              return (
                <button
                  type="button"
                  key={key}
                  onClick={() => {
                    setMechanic(key);
                    setSelected([]);
                    setDryRun(null);
                    setErrors([]);
                  }}
                  className={`rounded-xl border p-4 text-left transition ${
                    active
                      ? "border-[#ff5a36]/60 bg-[#ff5a36]/10"
                      : "border-white/10 bg-black/25 hover:bg-white/5"
                  }`}
                >
                  <Tag tone={item.tone}>{item.label}</Tag>
                  <p className="mono mt-2 text-[11px] text-slate-400">
                    {item.interaction}
                  </p>
                  <p className="mt-1 text-xs text-slate-300">{item.count}</p>
                </button>
              );
            })}
          </div>
        </Panel>

        <Panel
          title="2 · Product Data"
          subtitle="Giá luôn resolve từ ProductProvider — LLM không được sinh price."
          actions={
            <button
              type="button"
              onClick={autoPick}
              className="mono rounded-lg border border-white/15 px-3 py-1.5 text-[11px] text-slate-200 hover:bg-white/5"
            >
              ⤿ auto chọn theo heuristic
            </button>
          }
        >
          <div className="max-h-[420px] overflow-y-auto pr-1">
            <div className="grid gap-2 sm:grid-cols-2">
              {products.map((product) => {
                const index = selected.indexOf(product.productId);
                const active = index >= 0;
                return (
                  <button
                    type="button"
                    key={product.productId}
                    onClick={() => toggle(product.productId)}
                    className={`flex items-center gap-3 rounded-xl border p-2.5 text-left transition ${
                      active
                        ? "border-[#12a594]/60 bg-[#12a594]/10"
                        : "border-white/8 bg-black/25 hover:bg-white/5"
                    }`}
                  >
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={product.image}
                      alt=""
                      className="h-12 w-12 shrink-0 rounded-lg"
                    />
                    <span className="min-w-0 flex-1">
                      <span className="mono block text-[10px] text-slate-500">
                        {product.productId} · {product.brand}
                        {product.stale ? " · stale" : ""}
                      </span>
                      <span className="block truncate text-xs text-slate-200">
                        {product.emoji} {product.name}
                      </span>
                      <span className="mono block text-[11px] text-slate-400">
                        {formatVnd(product.price)}
                      </span>
                    </span>
                    {active && (
                      <span className="mono grid h-6 w-6 shrink-0 place-items-center rounded-md bg-[#12a594] text-[11px] font-bold text-black">
                        {index + 1}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </Panel>
      </div>

      <div className="space-y-4">
        <Panel title="3 · Game config">
          <div className="space-y-4">
            <label className="block">
              <span className="mono text-[10px] uppercase tracking-[0.14em] text-slate-500">
                seed (reproducibility 100%)
              </span>
              <div className="mt-1 flex gap-2">
                <input
                  value={seedText}
                  onChange={(event) => setSeedText(event.target.value)}
                  placeholder="auto — ví dụ 839271"
                  className="mono w-full rounded-lg border border-white/10 bg-black/40 px-3 py-2 text-sm text-white outline-none focus:border-[#ff5a36]/60"
                />
                <button
                  type="button"
                  onClick={() => setSeedText(String(randomInt(999999)))}
                  className="mono rounded-lg border border-white/15 px-3 text-[11px] text-slate-300 hover:bg-white/5"
                >
                  🎲
                </button>
              </div>
            </label>

            <div>
              <span className="mono text-[10px] uppercase tracking-[0.14em] text-slate-500">
                result_variant
              </span>
              <div className="mt-1 grid grid-cols-2 gap-2">
                {(["in_video", "comment"] as ResultVariant[]).map((variant) => (
                  <button
                    type="button"
                    key={variant}
                    onClick={() => setResultVariant(variant)}
                    className={`rounded-lg border px-3 py-2 text-xs transition ${
                      resultVariant === variant
                        ? "border-[#ff5a36]/60 bg-[#ff5a36]/10 text-white"
                        : "border-white/10 bg-black/30 text-slate-400 hover:bg-white/5"
                    }`}
                  >
                    {variant === "in_video" ? "in_video (reveal)" : "comment (bait)"}
                  </button>
                ))}
              </div>
              <p className="mt-2 text-[11px] leading-snug text-slate-500">
                {resultVariant === "in_video"
                  ? "ResultScene hiện đáp án + badge correct."
                  : "ResultScene giấu đáp án, CTA “Đáp án ở comment 👇” để tăng comment rate (SM-6)."}
              </p>
            </div>

            <div className="rounded-xl border border-white/8 bg-black/30 p-3">
              <p className="mono text-[10px] uppercase text-slate-500">
                đã chọn {selected.length}/{info.max}
              </p>
              <ul className="mt-2 space-y-1 text-xs text-slate-300">
                {selectedProducts.map((product, index) => (
                  <li key={product.productId} className="mono truncate">
                    {String.fromCharCode(65 + index)} · {product.productId} ·{" "}
                    {formatVnd(product.price)}
                  </li>
                ))}
                {selectedProducts.length === 0 && (
                  <li className="text-slate-500">Chưa chọn SKU nào.</li>
                )}
              </ul>
              {!countOk && (
                <p className="mt-2 text-[11px] text-amber-300">
                  {mechanic} cần {info.count}.
                </p>
              )}
            </div>

            <div className="flex flex-col gap-2">
              <button
                type="button"
                disabled={!countOk || busy !== null}
                onClick={() => submit("dry")}
                className="rounded-xl border border-white/15 px-4 py-2.5 text-sm text-slate-100 transition hover:bg-white/5 disabled:cursor-not-allowed disabled:opacity-40"
              >
                {busy === "dry" ? "⏳ validating…" : "🧪 Chỉ validate (2 tầng)"}
              </button>
              <button
                type="button"
                disabled={!countOk || busy !== null}
                onClick={() => submit("render")}
                className="rounded-xl bg-[#ff5a36] px-4 py-2.5 text-sm font-semibold text-black transition hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-40"
              >
                {busy === "render" ? "⏳ rendering…" : "▶ game render → MP4"}
              </button>
            </div>
          </div>
        </Panel>

        {errors.length > 0 || warnings.length > 0 ? (
          <Panel title="Validator 2 tầng" subtitle="Chặn trước render — Engine không chạy trên JSON hỏng.">
            <ErrorList errors={errors} warnings={warnings} />
          </Panel>
        ) : null}

        {dryRun && (
          <Panel title="Dry-run pass" subtitle="Validator + Engine chạy nhưng không render.">
            <p className="text-xs text-slate-400">
              Đáp án do Engine tính:{" "}
              <span className="mono text-[#12a594]">{dryRun.answer}</span>
            </p>
            <p className="mono mt-2 text-[11px] text-slate-500">
              validator {dryRun.validatorMs}ms · content {dryRun.contentSource}
            </p>
            <div className="mt-3 space-y-1">
              {dryRun.timeline.sceneTimings.map((scene) => (
                <div
                  key={scene.type}
                  className="mono flex justify-between text-[11px] text-slate-400"
                >
                  <span>{scene.start.toFixed(2)}s → {scene.end.toFixed(2)}s</span>
                  <span className="uppercase">{scene.type}</span>
                </div>
              ))}
            </div>
            <p className="mt-3 text-xs italic text-slate-300">
              “{dryRun.voiceScript}”
            </p>
          </Panel>
        )}
      </div>
    </div>
  );
}
