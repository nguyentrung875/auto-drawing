"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { ErrorList, Panel, Stat, Tag } from "@/components/ui";

export interface BatchSummary {
  batchId: string;
  status: string;
  total: number;
  passed: number;
  failed: number;
  avgRenderMs: number;
  distinctProducts: number;
  createdAt: string;
}

interface BatchJobView {
  jobId: string;
  gameId: string;
  mechanic: string;
  seed: number;
  productIds: string[];
  status: string;
  retries: number;
  contentSource: string;
  timings: {
    planning_ms: number;
    tts_ms: number;
    render_ms: number;
    encode_ms: number;
    total_ms: number;
  } | null;
  errors: { code: string; field: string; hint: string; layer: string }[] | null;
  warnings: string[] | null;
}

interface BatchView {
  batchId: string;
  status: string;
  total: number;
  passed: number;
  failed: number;
  avgRenderMs: number;
  distinctProducts: number;
  workerPoolMax: number;
  createdAt: string;
  finishedAt: string | null;
  report: unknown;
  jobs: BatchJobView[];
}

const MECHANIC_OPTIONS = ["HI_LO", "MOST_EXPENSIVE", "ONE_AWAY"] as const;

export default function BatchRunner({
  initialBatches,
}: {
  initialBatches: BatchSummary[];
}) {
  const [count, setCount] = useState(12);
  const [mechanics, setMechanics] = useState<string[]>([...MECHANIC_OPTIONS]);
  const [resultVariant, setResultVariant] = useState<"in_video" | "comment">(
    "in_video",
  );
  const [batchId, setBatchId] = useState<string | null>(
    initialBatches[0]?.batchId ?? null,
  );
  const [data, setData] = useState<BatchView | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async (id: string) => {
    const response = await fetch(`/api/batch/${id}`, { cache: "no-store" });
    if (!response.ok) return;
    const payload = (await response.json()) as { batch?: BatchView };
    if (payload.batch) setData(payload.batch);
  }, []);

  useEffect(() => {
    if (!batchId) return;
    void load(batchId);
  }, [batchId, load]);

  useEffect(() => {
    if (!batchId || !data || data.status === "done") return;
    const timer = setInterval(() => void load(batchId), 700);
    return () => clearInterval(timer);
  }, [batchId, data, load]);

  async function start() {
    setBusy(true);
    setError(null);
    try {
      const response = await fetch("/api/batch", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          count,
          mechanics: mechanics.length > 0 ? mechanics : [...MECHANIC_OPTIONS],
          resultVariant,
        }),
      });
      const payload = (await response.json()) as { batchId?: string; error?: string };
      if (!response.ok || !payload.batchId) {
        setError(payload.error ?? "không tạo được batch");
        return;
      }
      setBatchId(payload.batchId);
      setData(null);
    } finally {
      setBusy(false);
    }
  }

  function downloadReport() {
    if (!data) return;
    const blob = new Blob([JSON.stringify(data.report, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `batch_report_${data.batchId}.json`;
    anchor.click();
    URL.revokeObjectURL(url);
  }

  const progress = data ? Math.round(((data.passed + data.failed) / Math.max(data.total, 1)) * 100) : 0;
  const failedJobs = (data?.jobs ?? []).filter((job) => job.status === "failed");

  return (
    <div className="space-y-4">
      <Panel
        title="game batch"
        subtitle="Enqueue jobs vào queue, worker pool min(CPU-1,3) tự dequeue, fail-forward, không cần can thiệp tay (SM-3)."
      >
        <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_320px]">
          <div className="space-y-4">
            <div className="flex flex-wrap items-center gap-4">
              <label className="block">
                <span className="mono text-[10px] uppercase tracking-[0.14em] text-slate-500">
                  count
                </span>
                <input
                  type="number"
                  min={1}
                  max={100}
                  value={count}
                  onChange={(event) =>
                    setCount(Math.min(100, Math.max(1, Number(event.target.value) || 1)))
                  }
                  className="mono mt-1 w-28 rounded-lg border border-white/10 bg-black/40 px-3 py-2 text-sm text-white outline-none focus:border-[#ff5a36]/60"
                />
              </label>
              <div>
                <span className="mono text-[10px] uppercase tracking-[0.14em] text-slate-500">
                  mechanics
                </span>
                <div className="mt-1 flex gap-2">
                  {MECHANIC_OPTIONS.map((mechanic) => {
                    const active = mechanics.includes(mechanic);
                    return (
                      <button
                        type="button"
                        key={mechanic}
                        onClick={() =>
                          setMechanics((current) =>
                            current.includes(mechanic)
                              ? current.filter((item) => item !== mechanic)
                              : [...current, mechanic],
                          )
                        }
                        className={`mono rounded-lg border px-3 py-2 text-[11px] transition ${
                          active
                            ? "border-[#ff5a36]/60 bg-[#ff5a36]/10 text-white"
                            : "border-white/10 bg-black/30 text-slate-400 hover:bg-white/5"
                        }`}
                      >
                        {mechanic}
                      </button>
                    );
                  })}
                </div>
              </div>
              <div>
                <span className="mono text-[10px] uppercase tracking-[0.14em] text-slate-500">
                  variant
                </span>
                <div className="mt-1 flex gap-2">
                  {(["in_video", "comment"] as const).map((variant) => (
                    <button
                      type="button"
                      key={variant}
                      onClick={() => setResultVariant(variant)}
                      className={`mono rounded-lg border px-3 py-2 text-[11px] transition ${
                        resultVariant === variant
                          ? "border-[#12a594]/60 bg-[#12a594]/10 text-white"
                          : "border-white/10 bg-black/30 text-slate-400 hover:bg-white/5"
                      }`}
                    >
                      {variant}
                    </button>
                  ))}
                </div>
              </div>
            </div>
            <button
              type="button"
              onClick={start}
              disabled={busy}
              className="rounded-xl bg-[#ff5a36] px-4 py-2.5 text-sm font-semibold text-black transition hover:brightness-110 disabled:opacity-50"
            >
              {busy ? "⏳ enqueueing…" : "⚡ enqueue batch → chạy tự động"}
            </button>
            {error && <p className="mono text-xs text-rose-300">{error}</p>}
          </div>

          <div className="space-y-2 rounded-xl border border-white/8 bg-black/30 p-4">
            <p className="mono text-[10px] uppercase tracking-[0.14em] text-slate-500">
              batches gần đây
            </p>
            {(initialBatches.length === 0 && !data) && (
              <p className="text-xs text-slate-500">Chưa có batch nào.</p>
            )}
            <div className="max-h-44 space-y-1 overflow-y-auto">
              {(data
                ? [
                    {
                      batchId: data.batchId,
                      status: data.status,
                      total: data.total,
                      passed: data.passed,
                      failed: data.failed,
                      avgRenderMs: data.avgRenderMs,
                      distinctProducts: data.distinctProducts,
                      createdAt: data.createdAt,
                    },
                    ...initialBatches.filter((item) => item.batchId !== data.batchId),
                  ]
                : initialBatches
              ).map((item) => (
                <button
                  type="button"
                  key={item.batchId}
                  onClick={() => setBatchId(item.batchId)}
                  className={`mono block w-full truncate rounded-lg border px-3 py-2 text-left text-[11px] ${
                    batchId === item.batchId
                      ? "border-[#ff5a36]/50 bg-[#ff5a36]/10 text-white"
                      : "border-white/8 text-slate-400 hover:bg-white/5"
                  }`}
                >
                  {item.batchId} · {item.passed}/{item.total} · {item.status}
                </button>
              ))}
            </div>
          </div>
        </div>
      </Panel>

      {data && (
        <>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <Stat
              label="SM-1 · passed"
              value={`${data.passed}/${data.total}`}
              hint={`${Math.round((data.passed / Math.max(data.total, 1)) * 100)}% pass validator + render`}
              tone={data.passed / Math.max(data.total, 1) >= 0.98 ? "good" : "warn"}
            />
            <Stat
              label="failed (fail-forward)"
              value={String(data.failed)}
              hint="batch vẫn chạy tiếp, có báo cáo lỗi"
              tone={data.failed === 0 ? "good" : "warn"}
            />
            <Stat label="avg render_ms" value={`${data.avgRenderMs} ms`} hint="≤45s/video" />
            <Stat
              label="SM-C2 · coverage"
              value={`${data.distinctProducts} SKU`}
              hint={`guardrail ≥20 distinct productId · pool ${data.workerPoolMax}`}
              tone={data.distinctProducts >= 20 ? "good" : "default"}
            />
          </div>

          <Panel
            title={`batch_report.json · ${data.batchId}`}
            subtitle={`${data.status} · manual_interventions 0`}
            actions={
              <button
                type="button"
                onClick={downloadReport}
                className="mono rounded-lg border border-white/15 px-3 py-1.5 text-[11px] text-slate-200 hover:bg-white/5"
              >
                ⬇ batch_report.json
              </button>
            }
          >
            <div className="mb-4 h-2 overflow-hidden rounded-full bg-white/10">
              <div
                className="h-full rounded-full bg-gradient-to-r from-[#ff5a36] to-[#12a594] transition-all"
                style={{ width: `${progress}%` }}
              />
            </div>
            <div className="max-h-[440px] overflow-y-auto rounded-xl border border-white/8">
              <table className="w-full text-left text-xs">
                <thead className="mono sticky top-0 bg-black/60 text-[10px] uppercase tracking-[0.12em] text-slate-500 backdrop-blur">
                  <tr>
                    <th className="p-2">gameId</th>
                    <th className="p-2">mechanic</th>
                    <th className="p-2">seed</th>
                    <th className="p-2">status</th>
                    <th className="p-2">plan+tts+render+encode</th>
                    <th className="p-2">content</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {data.jobs.map((job) => (
                    <tr key={job.jobId} className="text-slate-300">
                      <td className="p-2">
                        {job.status === "done" ? (
                          <Link
                            href={`/games/${job.gameId}`}
                            className="mono block max-w-[260px] truncate text-[#ff8a6b] hover:underline"
                          >
                            {job.gameId}
                          </Link>
                        ) : (
                          <span className="mono block max-w-[260px] truncate text-slate-500">
                            {job.gameId}
                          </span>
                        )}
                      </td>
                      <td className="mono p-2 text-slate-400">{job.mechanic}</td>
                      <td className="mono p-2">{job.seed}</td>
                      <td className="p-2">
                        {job.status === "done" ? (
                          <Tag tone="teal">done</Tag>
                        ) : (
                          <Tag tone="rose">{job.status}</Tag>
                        )}
                      </td>
                      <td className="mono p-2 text-[11px] text-slate-400">
                        {job.timings
                          ? `${job.timings.planning_ms} / ${job.timings.tts_ms} / ${job.timings.render_ms} / ${job.timings.encode_ms} ms`
                          : "—"}
                      </td>
                      <td className="mono max-w-[160px] truncate p-2 text-[11px] text-slate-500">
                        {job.contentSource}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Panel>

          {failedJobs.length > 0 && (
            <Panel
              title="Validator chặn trước render"
              subtitle="Job fail không chặn batch (fail-forward) — lỗi trả về đủ code / field / hint."
            >
              <ErrorList
                errors={failedJobs.flatMap((job) =>
                  (job.errors ?? []).map((item) => ({
                    ...item,
                    hint: `${job.gameId}: ${item.hint}`,
                  })),
                )}
              />
            </Panel>
          )}
        </>
      )}
    </div>
  );
}
