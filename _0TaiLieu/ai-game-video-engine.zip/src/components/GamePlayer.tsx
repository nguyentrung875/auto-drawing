"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { drawFrame } from "@/engine-canvas/draw";
import type { RenderPlan } from "@/engine/types";

const MIME_CANDIDATES = [
  "video/mp4;codecs=avc1.42E01E,mp4a.40.2",
  "video/mp4",
  "video/webm;codecs=vp9,opus",
  "video/webm;codecs=vp8,opus",
  "video/webm",
];

function pickMime(): string {
  if (typeof MediaRecorder === "undefined") return "video/webm";
  for (const mime of MIME_CANDIDATES) {
    if (MediaRecorder.isTypeSupported(mime)) return mime;
  }
  return "video/webm";
}

interface Props {
  plan: RenderPlan;
  gameId: string;
}

export default function GamePlayer({ plan, gameId }: Props) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const audioRef = useRef<AudioContext | null>(null);
  const masterRef = useRef<GainNode | null>(null);
  const musicRef = useRef<{ osc: OscillatorNode[]; gain: GainNode } | null>(null);
  const firedRef = useRef<Set<string>>(new Set());
  const rafRef = useRef<number | null>(null);
  const clockRef = useRef<{ startedAt: number; offset: number } | null>(null);
  const timeRef = useRef(0);
  const playingRef = useRef(false);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);

  const [playing, setPlaying] = useState(false);
  const [time, setTime] = useState(0);
  const [sfxOn, setSfxOn] = useState(true);
  const [voiceOn, setVoiceOn] = useState(true);
  const [recording, setRecording] = useState(false);
  const [recordedUrl, setRecordedUrl] = useState<string | null>(null);
  const [recordedMime, setRecordedMime] = useState<string>("video/webm");
  const [viVoice, setViVoice] = useState<boolean | null>(null);

  const cues = useMemo(() => plan.audio.sfx, [plan]);
  const segments = useMemo(() => plan.audio.voice.segments, [plan]);

  useEffect(() => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) {
      setViVoice(false);
      return;
    }
    const check = () => {
      const voices = window.speechSynthesis.getVoices();
      setViVoice(voices.some((voice) => voice.lang.toLowerCase().startsWith("vi")));
    };
    check();
    window.speechSynthesis.addEventListener("voiceschanged", check);
    return () => window.speechSynthesis.removeEventListener("voiceschanged", check);
  }, []);

  const ensureAudio = useCallback(() => {
    if (!audioRef.current) {
      const AudioCtor =
        window.AudioContext ??
        (window as unknown as { webkitAudioContext?: typeof AudioContext })
          .webkitAudioContext;
      if (!AudioCtor) return null;
      const ctx = new AudioCtor();
      const master = ctx.createGain();
      master.gain.value = 0.9;
      master.connect(ctx.destination);
      audioRef.current = ctx;
      masterRef.current = master;
    }
    return audioRef.current;
  }, []);

  const stopMusic = useCallback(() => {
    const music = musicRef.current;
    if (music) {
      try {
        music.gain.gain.cancelScheduledValues(audioRef.current?.currentTime ?? 0);
        music.osc.forEach((osc) => osc.stop());
      } catch {
        /* already stopped */
      }
      musicRef.current = null;
    }
  }, []);

  const startMusic = useCallback(() => {
    const ctx = ensureAudio();
    const master = masterRef.current;
    if (!ctx || !master || musicRef.current) return;
    const gain = ctx.createGain();
    gain.gain.value = plan.audio.music.volume * 0.35;
    const osc = [110, 164.81, 220].map((freq, index) => {
      const node = ctx.createOscillator();
      node.type = index === 2 ? "triangle" : "sine";
      node.frequency.value = freq;
      node.detune.value = index * 4;
      node.connect(gain);
      node.start();
      return node;
    });
    gain.connect(master);
    musicRef.current = { osc, gain };
  }, [ensureAudio, plan.audio.music.volume]);

  const blip = useCallback(
    (
      freq: number,
      duration: number,
      type: OscillatorType,
      volume: number,
      when = 0,
    ) => {
      const ctx = ensureAudio();
      const master = masterRef.current;
      if (!ctx || !master) return;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(freq, ctx.currentTime + when);
      gain.gain.setValueAtTime(0.0001, ctx.currentTime + when);
      gain.gain.exponentialRampToValueAtTime(volume, ctx.currentTime + when + 0.01);
      gain.gain.exponentialRampToValueAtTime(
        0.0001,
        ctx.currentTime + when + duration,
      );
      osc.connect(gain);
      gain.connect(master);
      osc.start(ctx.currentTime + when);
      osc.stop(ctx.currentTime + when + duration + 0.02);
    },
    [ensureAudio],
  );

  const playSfx = useCallback(
    (type: string) => {
      if (!sfxOn) return;
      switch (type) {
        case "tick":
        case "countdown":
          blip(1180, 0.07, "square", 0.16);
          break;
        case "transition":
          blip(320, 0.12, "sawtooth", 0.07);
          break;
        case "reveal":
          blip(420, 0.18, "sine", 0.16);
          blip(880, 0.22, "sine", 0.12, 0.12);
          break;
        case "correct":
          blip(660, 0.16, "triangle", 0.15);
          blip(990, 0.28, "triangle", 0.13, 0.1);
          break;
        case "wrong":
          blip(180, 0.3, "sawtooth", 0.12);
          break;
        default:
          blip(520, 0.08, "sine", 0.08);
      }
    },
    [blip, sfxOn],
  );

  const speak = useCallback(
    (text: string) => {
      if (!voiceOn || !viVoice || typeof window === "undefined") return;
      if (!("speechSynthesis" in window)) return;
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = "vi-VN";
      utterance.rate = 1.05;
      utterance.pitch = 1.0;
      const voice = window.speechSynthesis
        .getVoices()
        .find((item) => item.lang.toLowerCase().startsWith("vi"));
      if (voice) utterance.voice = voice;
      window.speechSynthesis.speak(utterance);
    },
    [viVoice, voiceOn],
  );

  const render = useCallback(
    (t: number) => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;
      drawFrame(ctx, plan, t);
    },
    [plan],
  );

  const stopLoop = useCallback(() => {
    playingRef.current = false;
    setPlaying(false);
    if (rafRef.current !== null) {
      cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
    }
    stopMusic();
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      window.speechSynthesis.cancel();
    }
  }, [stopMusic]);

  const tick = useCallback(() => {
    const clock = clockRef.current;
    if (!clock || !playingRef.current) return;
    const t = (performance.now() - clock.startedAt) / 1000;
    const clamped = Math.min(t, plan.totalDuration);
    timeRef.current = clamped;
    setTime(clamped);
    render(clamped);

    for (const cue of cues) {
      const key = `sfx-${cue.type}-${cue.at}`;
      if (clamped >= cue.at && !firedRef.current.has(key)) {
        firedRef.current.add(key);
        playSfx(cue.type);
      }
    }
    for (const [index, segment] of segments.entries()) {
      const key = `voice-${index}`;
      if (clamped >= segment.startAt && !firedRef.current.has(key)) {
        firedRef.current.add(key);
        speak(segment.text);
      }
    }

    if (t >= plan.totalDuration) {
      const recorder = recorderRef.current;
      if (recorder && recorder.state !== "inactive") {
        recorder.stop();
      }
      stopLoop();
      return;
    }
    rafRef.current = requestAnimationFrame(tick);
  }, [cues, plan.totalDuration, playSfx, render, segments, speak, stopLoop]);

  const play = useCallback(() => {
    ensureAudio();
    void audioRef.current?.resume();
    const startFrom = timeRef.current >= plan.totalDuration - 0.05 ? 0 : timeRef.current;
    firedRef.current.clear();
    clockRef.current = { startedAt: performance.now() - startFrom * 1000, offset: startFrom };
    playingRef.current = true;
    setPlaying(true);
    startMusic();
    rafRef.current = requestAnimationFrame(tick);
  }, [ensureAudio, plan.totalDuration, startMusic, tick]);

  const toggle = useCallback(() => {
    if (playingRef.current) stopLoop();
    else play();
  }, [play, stopLoop]);

  const seek = useCallback(
    (value: number) => {
      timeRef.current = value;
      setTime(value);
      render(value);
      firedRef.current.clear();
      if (clockRef.current) {
        clockRef.current.startedAt = performance.now() - value * 1000;
      }
    },
    [render],
  );

  const restart = useCallback(() => {
    stopLoop();
    seek(0);
    play();
  }, [play, seek, stopLoop]);

  const startRecording = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas || typeof MediaRecorder === "undefined") return;
    const ctx = ensureAudio();
    const stream = canvas.captureStream(30);
    const tracks: MediaStreamTrack[] = [...stream.getVideoTracks()];
    if (ctx && masterRef.current) {
      const dest = ctx.createMediaStreamDestination();
      masterRef.current.connect(dest);
      tracks.push(...dest.stream.getAudioTracks());
    }
    const mimeType = pickMime();
    const recorder = new MediaRecorder(new MediaStream(tracks), {
      mimeType,
      videoBitsPerSecond: 6_000_000,
    });
    chunksRef.current = [];
    recorder.ondataavailable = (event) => {
      if (event.data.size > 0) chunksRef.current.push(event.data);
    };
    recorder.onstop = () => {
      const blob = new Blob(chunksRef.current, { type: mimeType });
      const url = URL.createObjectURL(blob);
      setRecordedUrl(url);
      setRecordedMime(mimeType);
      setRecording(false);
      recorderRef.current = null;
    };
    recorderRef.current = recorder;
    setRecordedUrl(null);
    setRecording(true);
    recorder.start(250);
    restart();
  }, [ensureAudio, restart]);

  const stopRecording = useCallback(() => {
    const recorder = recorderRef.current;
    if (recorder && recorder.state !== "inactive") recorder.stop();
  }, []);

  useEffect(() => {
    render(0);
    return () => {
      stopLoop();
      recorderRef.current = null;
    };
  }, [render, stopLoop]);

  useEffect(() => {
    render(timeRef.current);
  }, [plan, render]);

  const extension = recordedMime.includes("mp4") ? "mp4" : "webm";
  const activeScene =
    plan.scenes.find((scene) => time >= scene.start && time < scene.end) ??
    plan.scenes[plan.scenes.length - 1];

  return (
    <div className="flex flex-col gap-4 lg:flex-row">
      <div className="flex flex-col items-center gap-3">
        <canvas
          ref={canvasRef}
          width={plan.width}
          height={plan.height}
          className="h-auto w-[300px] rounded-2xl border border-white/10 shadow-[0_24px_70px_rgba(0,0,0,0.55)] sm:w-[340px]"
        />
        <div className="flex flex-wrap items-center justify-center gap-2">
          <button
            type="button"
            onClick={toggle}
            className="rounded-lg bg-[#ff5a36] px-3 py-1.5 text-xs font-semibold text-black transition hover:brightness-110"
          >
            {playing ? "❚❚ Pause" : "▶ Play"}
          </button>
          <button
            type="button"
            onClick={restart}
            className="rounded-lg border border-white/15 px-3 py-1.5 text-xs text-slate-200 hover:bg-white/5"
          >
            ⟲ Restart
          </button>
          <button
            type="button"
            onClick={() => setSfxOn((value) => !value)}
            className={`rounded-lg border px-3 py-1.5 text-xs ${
              sfxOn
                ? "border-teal-400/40 bg-teal-400/10 text-teal-200"
                : "border-white/15 text-slate-400"
            }`}
          >
            SFX {sfxOn ? "on" : "off"}
          </button>
          <button
            type="button"
            onClick={() => setVoiceOn((value) => !value)}
            className={`rounded-lg border px-3 py-1.5 text-xs ${
              voiceOn
                ? "border-teal-400/40 bg-teal-400/10 text-teal-200"
                : "border-white/15 text-slate-400"
            }`}
          >
            Voice {voiceOn ? "on" : "off"}
          </button>
          <button
            type="button"
            onClick={recording ? stopRecording : startRecording}
            className={`rounded-lg border px-3 py-1.5 text-xs font-semibold ${
              recording
                ? "border-rose-400/50 bg-rose-500/20 text-rose-100"
                : "border-white/15 text-slate-200 hover:bg-white/5"
            }`}
          >
            {recording ? "■ Stop encode" : "● Encode MP4"}
          </button>
        </div>
        <input
          type="range"
          min={0}
          max={plan.totalDuration}
          step={0.01}
          value={time}
          onChange={(event) => seek(Number(event.target.value))}
          className="w-[300px] sm:w-[340px]"
        />
        {recordedUrl && (
          <a
            href={recordedUrl}
            download={`${gameId}.${extension}`}
            className="mono rounded-lg border border-emerald-400/40 bg-emerald-400/10 px-3 py-1.5 text-[11px] text-emerald-200"
          >
            ⬇ download {gameId}.{extension} ({extension.toUpperCase()} · H.264-class · 1080×1920)
          </a>
        )}
      </div>

      <div className="flex-1 space-y-3">
        <div className="rounded-xl border border-white/8 bg-black/30 p-4">
          <p className="mono text-[10px] uppercase tracking-[0.16em] text-slate-500">
            render plan
          </p>
          <div className="mt-2 grid grid-cols-2 gap-2 text-xs text-slate-300 sm:grid-cols-3">
            <span>{plan.width}×{plan.height} @{plan.fps}fps</span>
            <span>{plan.frames} frames</span>
            <span>{plan.totalDuration.toFixed(1)}s</span>
            <span>tilt {plan.diversification.tiltDeg}°</span>
            <span>bgm {plan.diversification.bgmTrack}</span>
            <span>layout {plan.diversification.layout}</span>
          </div>
        </div>

        <div className="rounded-xl border border-white/8 bg-black/30 p-4">
          <p className="mono text-[10px] uppercase tracking-[0.16em] text-slate-500">
            timeline · scene đang chiếu: {activeScene.type}
          </p>
          <div className="mt-3 space-y-2">
            {plan.scenes.map((scene) => {
              const active = scene.type === activeScene.type;
              return (
                <button
                  type="button"
                  key={scene.type}
                  onClick={() => seek(scene.start + 0.05)}
                  className={`flex w-full items-center gap-3 rounded-lg border px-3 py-2 text-left text-xs transition ${
                    active
                      ? "border-[#ff5a36]/50 bg-[#ff5a36]/10 text-white"
                      : "border-white/8 text-slate-400 hover:bg-white/5"
                  }`}
                >
                  <span className="mono w-24 shrink-0">{scene.start.toFixed(2)}s</span>
                  <span className="mono w-16 shrink-0 uppercase">{scene.type}</span>
                  <span className="mono w-14 shrink-0">{scene.duration.toFixed(1)}s</span>
                  <span className="truncate">{scene.headline || scene.subline}</span>
                </button>
              );
            })}
          </div>
        </div>

        <div className="rounded-xl border border-white/8 bg-black/30 p-4">
          <p className="mono text-[10px] uppercase tracking-[0.16em] text-slate-500">
            audio engine
          </p>
          <ul className="mt-2 space-y-1 text-xs text-slate-400">
            {segments.map((segment, index) => (
              <li key={index} className="mono">
                [{segment.startAt.toFixed(2)}s] {segment.revealLocked ? "🔊 reveal" : "🔊 hook"} — “{segment.text}”
              </li>
            ))}
            <li className="mono">
              music {plan.audio.music.track} · volume {plan.audio.music.volume} · {cues.length} SFX cues
            </li>
          </ul>
          <p className="mt-2 text-[11px] text-slate-500">
            {viVoice === false
              ? "⚠ Không tìm thấy giọng vi-VN của hệ điều hành — preview bỏ voice. Adapter viPiper (MIT) sẽ đảm nhiệm ở local factory."
              : "Voice preview dùng giọng vi-VN của hệ điều hành; bản encode local dùng viPiper offline."}
          </p>
        </div>
      </div>
    </div>
  );
}
