import { desc, sql } from "drizzle-orm";
import { db } from "@/db";
import { batches as batchesTable, games as gamesTable, jobs as jobsTable } from "@/db/schema";
import { listProducts, staleInfo } from "@/engine/product-provider";
import { WORKER_POOL_MAX } from "@/engine/pipeline";

export interface FactoryStats {
  products: {
    total: number;
    stale: number;
    categories: { category: string; count: number }[];
  };
  jobs: {
    total: number;
    done: number;
    failed: number;
    running: number;
    pending: number;
    successRate: number;
    avgRenderMs: number;
    avgTotalMs: number;
  };
  games: {
    total: number;
    byMechanic: { mechanic: string; count: number }[];
    byVariant: { variant: string; count: number }[];
  };
  batches: {
    total: number;
    latest: {
      batchId: string;
      status: string;
      total: number;
      passed: number;
      failed: number;
      avgRenderMs: number;
      distinctProducts: number;
      createdAt: string;
    } | null;
  };
  coverage: {
    distinctProductsAllTime: number;
    guardrailMet: boolean;
    guardrailTarget: number;
  };
  workerPoolMax: number;
}

export async function loadStats(): Promise<FactoryStats> {
  const products = await listProducts();

  const [jobStats] = await db
    .select({
      total: sql<number>`count(*)::int`,
      done: sql<number>`count(*) filter (where status = 'done')::int`,
      failed: sql<number>`count(*) filter (where status = 'failed')::int`,
      running: sql<number>`count(*) filter (where status = 'running')::int`,
      pending: sql<number>`count(*) filter (where status = 'pending')::int`,
      avgRenderMs: sql<number>`coalesce(avg((timings ->> 'render_ms')::numeric), 0)::int`,
      avgTotalMs: sql<number>`coalesce(avg((timings ->> 'total_ms')::numeric), 0)::int`,
    })
    .from(jobsTable);

  const mechanicRows = await db
    .select({
      mechanic: gamesTable.mechanic,
      count: sql<number>`count(*)::int`,
    })
    .from(gamesTable)
    .groupBy(gamesTable.mechanic);

  const variantRows = await db
    .select({
      variant: gamesTable.resultVariant,
      count: sql<number>`count(*)::int`,
    })
    .from(gamesTable)
    .groupBy(gamesTable.resultVariant);

  const batchRows = await db
    .select()
    .from(batchesTable)
    .orderBy(desc(batchesTable.createdAt))
    .limit(10);

  const productUsage = await db
    .select({ productIds: jobsTable.productIds })
    .from(jobsTable)
    .limit(2000);
  const distinctAllTime = new Set(
    productUsage.flatMap((row) => row.productIds ?? []),
  ).size;

  const categoryMap = new Map<string, number>();
  for (const product of products) {
    categoryMap.set(
      product.category,
      (categoryMap.get(product.category) ?? 0) + 1,
    );
  }

  const latest = batchRows[0];
  const done = jobStats?.done ?? 0;
  const finished = done + (jobStats?.failed ?? 0);

  return {
    products: {
      total: products.length,
      stale: products.filter((product) => staleInfo(product).stale).length,
      categories: [...categoryMap.entries()]
        .map(([category, count]) => ({ category, count }))
        .sort((a, b) => b.count - a.count),
    },
    jobs: {
      total: jobStats?.total ?? 0,
      done,
      failed: jobStats?.failed ?? 0,
      running: jobStats?.running ?? 0,
      pending: jobStats?.pending ?? 0,
      successRate: finished === 0 ? 0 : Math.round((done / finished) * 1000) / 10,
      avgRenderMs: jobStats?.avgRenderMs ?? 0,
      avgTotalMs: jobStats?.avgTotalMs ?? 0,
    },
    games: {
      total: mechanicRows.reduce((sum, row) => sum + row.count, 0),
      byMechanic: mechanicRows,
      byVariant: variantRows,
    },
    batches: {
      total: batchRows.length,
      latest: latest
        ? {
            batchId: latest.batchId,
            status: latest.status,
            total: latest.total,
            passed: latest.passed,
            failed: latest.failed,
            avgRenderMs: latest.avgRenderMs,
            distinctProducts: latest.distinctProducts,
            createdAt: latest.createdAt.toISOString(),
          }
        : null,
    },
    coverage: {
      distinctProductsAllTime: distinctAllTime,
      guardrailMet: (latest?.distinctProducts ?? 0) >= 20,
      guardrailTarget: 20,
    },
    workerPoolMax: WORKER_POOL_MAX,
  };
}
