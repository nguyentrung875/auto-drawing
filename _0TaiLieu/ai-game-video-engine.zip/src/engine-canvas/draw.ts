import type { PlannedCard, PlannedScene, RenderPlan } from "@/engine/types";

const W = 1080;
const H = 1920;

export function roundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
) {
  const radius = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.arcTo(x + w, y, x + w, y + h, radius);
  ctx.arcTo(x + w, y + h, x, y + h, radius);
  ctx.arcTo(x, y + h, x, y, radius);
  ctx.arcTo(x, y, x + w, y, radius);
  ctx.closePath();
}

function wrapLines(
  ctx: CanvasRenderingContext2D,
  text: string,
  maxWidth: number,
): string[] {
  const words = text.split(/\s+/).filter(Boolean);
  const lines: string[] = [];
  let current = "";
  for (const word of words) {
    const candidate = current ? `${current} ${word}` : word;
    if (ctx.measureText(candidate).width > maxWidth && current) {
      lines.push(current);
      current = word;
    } else {
      current = candidate;
    }
  }
  if (current) lines.push(current);
  return lines;
}

function drawParagraph(
  ctx: CanvasRenderingContext2D,
  text: string,
  x: number,
  y: number,
  maxWidth: number,
  lineHeight: number,
  maxLines = 4,
) {
  const lines = wrapLines(ctx, text, maxWidth).slice(0, maxLines);
  lines.forEach((line, index) => {
    ctx.fillText(line, x, y + index * lineHeight);
  });
  return lines.length;
}

const easeOut = (x: number) => 1 - Math.pow(1 - Math.min(Math.max(x, 0), 1), 3);

interface Box {
  x: number;
  y: number;
  w: number;
  h: number;
}

function cardLayout(count: number): Box[] {
  if (count <= 1) {
    return [{ x: 140, y: 520, w: 800, h: 700 }];
  }
  if (count === 2) {
    return [
      { x: 120, y: 430, w: 840, h: 430 },
      { x: 120, y: 900, w: 840, h: 430 },
    ];
  }
  return [
    { x: 90, y: 420, w: 420, h: 430 },
    { x: 570, y: 420, w: 420, h: 430 },
    { x: 90, y: 890, w: 420, h: 430 },
    { x: 570, y: 890, w: 420, h: 430 },
  ].slice(0, count);
}

function drawCard(
  ctx: CanvasRenderingContext2D,
  card: PlannedCard,
  box: Box,
  opts: { emphasized: boolean; showPrice: boolean; priceLabel?: string },
) {
  const gradient = ctx.createLinearGradient(box.x, box.y, box.x + box.w, box.y + box.h);
  gradient.addColorStop(0, card.colorFrom);
  gradient.addColorStop(1, card.colorTo);
  ctx.save();
  ctx.shadowColor = "rgba(0,0,0,0.45)";
  ctx.shadowBlur = 30;
  ctx.shadowOffsetY = 12;
  ctx.fillStyle = gradient;
  roundRect(ctx, box.x, box.y, box.w, box.h, 36);
  ctx.fill();
  ctx.restore();

  if (opts.emphasized) {
    ctx.strokeStyle = "#ffffff";
    ctx.lineWidth = 10;
    roundRect(ctx, box.x + 6, box.y + 6, box.w - 12, box.h - 12, 32);
    ctx.stroke();
  }

  ctx.textAlign = "center";
  ctx.fillStyle = "rgba(255,255,255,0.95)";
  ctx.font = "700 108px system-ui, sans-serif";
  ctx.fillText(card.emoji, box.x + box.w / 2, box.y + 190);

  ctx.font = "700 34px system-ui, sans-serif";
  ctx.fillStyle = "rgba(255,255,255,0.82)";
  ctx.fillText(
    card.brand.toUpperCase(),
    box.x + box.w / 2,
    box.y + 250,
  );

  ctx.font = "600 42px system-ui, sans-serif";
  ctx.fillStyle = "#ffffff";
  const nameLines = wrapLines(ctx, card.name, box.w - 90).slice(0, 2);
  nameLines.forEach((line, index) => {
    ctx.fillText(line, box.x + box.w / 2, box.y + 315 + index * 52);
  });

  if (opts.showPrice) {
    ctx.font = "800 62px ui-monospace, monospace";
    ctx.fillStyle = "#ffffff";
    ctx.fillText(
      opts.priceLabel ?? card.priceLabel,
      box.x + box.w / 2,
      box.y + box.h - 60,
    );
  }
  ctx.textAlign = "left";
}

function drawChips(
  ctx: CanvasRenderingContext2D,
  chips: string[],
  y: number,
  accent: string,
) {
  ctx.font = "600 26px ui-monospace, monospace";
  let x = 90;
  for (const chip of chips) {
    const width = ctx.measureText(chip).width + 44;
    ctx.fillStyle = accent;
    roundRect(ctx, x, y, width, 54, 27);
    ctx.fill();
    ctx.fillStyle = "#0b0f16";
    ctx.fillText(chip, x + 22, y + 36);
    x += width + 18;
  }
}

function drawChrome(
  ctx: CanvasRenderingContext2D,
  plan: RenderPlan,
  t: number,
  scene: PlannedScene,
) {
  // top progress bar segmented by scene
  const total = plan.totalDuration;
  ctx.fillStyle = "rgba(0,0,0,0.18)";
  roundRect(ctx, 60, 70, W - 120, 14, 7);
  ctx.fill();
  plan.scenes.forEach((entry) => {
    const startX = 60 + (entry.start / total) * (W - 120);
    const width = (entry.duration / total) * (W - 120);
    ctx.fillStyle =
      entry.type === scene.type ? plan.diversification.accentColor : "rgba(255,255,255,0.25)";
    roundRect(ctx, startX + 2, 70, Math.max(width - 4, 4), 14, 6);
    ctx.fill();
  });

  ctx.fillStyle = "rgba(255,255,255,0.55)";
  ctx.font = "600 24px ui-monospace, monospace";
  ctx.fillText(
    `${plan.mechanic} · ${plan.interaction} · seed ${plan.seed}`,
    60,
    140,
  );
  ctx.textAlign = "right";
  ctx.fillText(`${t.toFixed(2)}s / ${total.toFixed(1)}s`, W - 60, 140);
  ctx.textAlign = "left";
}

function drawScene(
  ctx: CanvasRenderingContext2D,
  plan: RenderPlan,
  scene: PlannedScene,
  localT: number,
) {
  const p = easeOut(localT / scene.duration);
  const ink = plan.diversification.inkColor;
  const accent = plan.diversification.accentColor;
  const cards = plan.cards;
  const cardById = new Map(cards.map((card) => [card.productId, card]));
  const sceneCards = scene.cardIds
    .map((id) => cardById.get(id))
    .filter((card): card is PlannedCard => Boolean(card));

  ctx.fillStyle = ink;
  ctx.textAlign = "left";

  if (scene.type === "hook") {
    ctx.font = "800 96px system-ui, sans-serif";
    const lines = wrapLines(ctx, scene.headline, W - 200).slice(0, 4);
    ctx.fillStyle = ink;
    let y = 620;
    for (const line of lines) {
      ctx.globalAlpha = Math.min(1, p * 1.4);
      ctx.fillText(line, 100, y);
      y += 118;
    }
    ctx.globalAlpha = 1;
    ctx.font = "700 44px system-ui, sans-serif";
    ctx.fillStyle = accent;
    ctx.fillText(scene.subline, 100, y + 40);
    drawChips(ctx, scene.badges, 1560, accent);
    return;
  }

  if (scene.type === "product") {
    ctx.font = "800 66px system-ui, sans-serif";
    ctx.fillStyle = ink;
    ctx.fillText(scene.headline, 100, 300);
    ctx.font = "500 34px system-ui, sans-serif";
    ctx.fillStyle = "rgba(0,0,0,0.55)";
    ctx.fillText(scene.subline, 100, 360);
    const boxes = cardLayout(sceneCards.length);
    sceneCards.forEach((card, index) => {
      const box = boxes[index];
      const rise = (1 - p) * 60;
      drawCard(ctx, card, { ...box, y: box.y + rise }, {
        emphasized: false,
        showPrice: plan.mechanic !== "ONE_AWAY",
        priceLabel: card.maskedPriceLabel,
      });
    });
    return;
  }

  if (scene.type === "question") {
    ctx.font = "800 74px system-ui, sans-serif";
    ctx.fillStyle = ink;
    const lines = wrapLines(ctx, scene.headline, W - 200).slice(0, 3);
    let y = 300;
    for (const line of lines) {
      ctx.fillText(line, 100, y);
      y += 92;
    }
    const boxes = cardLayout(sceneCards.length).map((box) => ({
      ...box,
      y: box.y - 90,
      h: sceneCards.length > 2 ? 330 : 350,
    }));
    sceneCards.forEach((card, index) => {
      drawCard(ctx, card, boxes[index], {
        emphasized: false,
        showPrice: false,
      });
    });
    const choiceCount = scene.choices.length;
    const buttonHeight = 108;
    const gap = 26;
    const totalHeight = choiceCount * buttonHeight + (choiceCount - 1) * gap;
    const startY = 1490 - totalHeight + 120;
    scene.choices.forEach((choice, index) => {
      const width = choiceCount > 2 ? (W - 240 - gap) / 2 : W - 240;
      const x = choiceCount > 2 ? 120 + (index % 2) * (width + gap) : 120;
      const row = choiceCount > 2 ? Math.floor(index / 2) : index;
      const boxY = startY + row * (buttonHeight + gap);
      const appear = Math.min(1, Math.max(0, p * 1.6 - index * 0.15));
      ctx.globalAlpha = appear;
      ctx.fillStyle = accent;
      roundRect(ctx, x, boxY, width, buttonHeight, 28);
      ctx.fill();
      ctx.fillStyle = "#0b0f16";
      ctx.font = "800 46px system-ui, sans-serif";
      ctx.textAlign = "center";
      ctx.fillText(choice, x + width / 2, boxY + 68);
      ctx.textAlign = "left";
      ctx.globalAlpha = 1;
    });
    return;
  }

  if (scene.type === "countdown") {
    const remaining = Math.max(0, scene.duration - localT);
    const display = Math.max(1, Math.ceil(remaining));
    const frac = remaining / scene.duration;
    ctx.save();
    ctx.translate(W / 2, 900);
    ctx.textAlign = "center";
    ctx.strokeStyle = "rgba(0,0,0,0.12)";
    ctx.lineWidth = 34;
    ctx.beginPath();
    ctx.arc(0, 0, 300, 0, Math.PI * 2);
    ctx.stroke();
    ctx.strokeStyle = accent;
    ctx.beginPath();
    ctx.arc(0, 0, 300, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * frac);
    ctx.stroke();
    ctx.fillStyle = ink;
    ctx.font = "800 380px ui-monospace, monospace";
    ctx.fillText(String(display), 0, 130);
    ctx.font = "700 46px system-ui, sans-serif";
    ctx.fillStyle = "rgba(0,0,0,0.55)";
    ctx.fillText(scene.subline, 0, 420);
    ctx.restore();
    drawChips(ctx, scene.badges, 1500, accent);
    ctx.textAlign = "left";
    return;
  }

  if (scene.type === "reveal") {
    ctx.textAlign = "center";
    ctx.font = "700 40px ui-monospace, monospace";
    ctx.fillStyle = accent;
    ctx.fillText(scene.revealPrefix, W / 2, 300);

    if (scene.revealKind === "digit") {
      const card = sceneCards[0];
      const flip = p > 0.35 ? Math.min(1, (p - 0.35) / 0.45) : 0;
      ctx.font = "800 132px ui-monospace, monospace";
      ctx.fillStyle = ink;
      const shown = flip > 0.5 ? scene.revealDigitAfter : scene.revealDigitBefore;
      const scale = 1 + Math.sin(flip * Math.PI) * 0.18;
      ctx.save();
      ctx.translate(W / 2, 560);
      ctx.scale(scale, 1 / scale);
      ctx.fillText(shown, 0, 0);
      ctx.restore();
      ctx.font = "800 92px system-ui, sans-serif";
      ctx.fillStyle = accent;
      ctx.fillText(`${scene.headline} ${flip > 0.5 ? "" : "?"}`, W / 2, 780);
      ctx.font = "600 44px system-ui, sans-serif";
      ctx.fillStyle = "rgba(0,0,0,0.6)";
      ctx.fillText(scene.subline, W / 2, 850);
      if (card) {
        drawCard(ctx, card, { x: 200, y: 950, w: 680, h: 520 }, {
          emphasized: true,
          showPrice: true,
          priceLabel: flip > 0.5 ? card.priceLabel : card.maskedPriceLabel,
        });
      }
    } else if (scene.revealKind === "choice") {
      const boxes = cardLayout(sceneCards.length);
      sceneCards.forEach((card, index) => {
        drawCard(ctx, card, boxes[index], {
          emphasized: card.emphasized && p > 0.25,
          showPrice: p > 0.25,
        });
      });
      ctx.font = "800 60px system-ui, sans-serif";
      ctx.fillStyle = ink;
      ctx.fillText(scene.headline, W / 2, 330);
    } else {
      ctx.font = "800 78px system-ui, sans-serif";
      ctx.fillStyle = ink;
      ctx.fillText(scene.headline, W / 2, 400);
      const card = sceneCards[sceneCards.length - 1];
      if (card) {
        drawCard(ctx, card, { x: 190, y: 520, w: 700, h: 560 }, {
          emphasized: true,
          showPrice: true,
        });
      }
      ctx.font = "600 44px system-ui, sans-serif";
      ctx.fillStyle = "rgba(0,0,0,0.6)";
      ctx.fillText(scene.subline, W / 2, 1180);
    }
    ctx.textAlign = "left";
    return;
  }

  if (scene.type === "result") {
    ctx.textAlign = "center";
    ctx.font = "800 84px system-ui, sans-serif";
    ctx.fillStyle = scene.variant === "in_video" ? ink : accent;
    const lines = wrapLines(ctx, scene.headline, W - 220).slice(0, 3);
    let y = 620;
    for (const line of lines) {
      ctx.fillText(line, W / 2, y);
      y += 104;
    }
    ctx.font = "600 44px system-ui, sans-serif";
    ctx.fillStyle = "rgba(0,0,0,0.6)";
    ctx.fillText(scene.subline, W / 2, y + 20);
    drawChips(ctx, scene.badges, 1180, accent);
    const card = sceneCards[0];
    if (card) {
      drawCard(ctx, card, { x: 240, y: 1300, w: 600, h: 420 }, {
        emphasized: scene.variant === "in_video",
        showPrice: scene.variant === "in_video",
      });
    }
    ctx.textAlign = "left";
    return;
  }

  // CTA
  ctx.textAlign = "center";
  ctx.font = "800 76px system-ui, sans-serif";
  ctx.fillStyle = ink;
  const lines = wrapLines(ctx, scene.headline, W - 200).slice(0, 3);
  let y = 520;
  for (const line of lines) {
    ctx.fillText(line, W / 2, y);
    y += 96;
  }
  ctx.font = "700 46px system-ui, sans-serif";
  ctx.fillStyle = accent;
  ctx.fillText(scene.subline, W / 2, y + 30);
  ctx.font = "500 36px system-ui, sans-serif";
  ctx.fillStyle = "rgba(0,0,0,0.55)";
  ctx.fillText(scene.body, W / 2, y + 110);
  const card = sceneCards[0];
  if (card) {
    drawCard(ctx, card, { x: 300, y: 1200, w: 480, h: 380 }, {
      emphasized: false,
      showPrice: true,
    });
  }
  ctx.font = "600 30px ui-monospace, monospace";
  ctx.fillStyle = "rgba(0,0,0,0.45)";
  ctx.fillText("link affiliate ở caption · Hermes sẽ đăng kèm", W / 2, 1700);
  ctx.textAlign = "left";
}

/** Draws one deterministic frame — the code-rendered "pen tip". */
export function drawFrame(
  ctx: CanvasRenderingContext2D,
  plan: RenderPlan,
  t: number,
) {
  const { paperColor, inkColor, tiltDeg } = plan.diversification;
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.fillStyle = "#0b0f16";
  ctx.fillRect(0, 0, W, H);

  ctx.save();
  ctx.translate(W / 2, H / 2);
  ctx.rotate((tiltDeg * Math.PI) / 180);
  ctx.translate(-W / 2, -H / 2);

  ctx.fillStyle = paperColor;
  ctx.fillRect(-40, -40, W + 80, H + 80);

  // paper grain (deterministic, no Math.random)
  ctx.fillStyle = "rgba(0,0,0,0.035)";
  for (let i = 0; i < 140; i += 1) {
    const x = ((i * 977) % (W + 80)) - 40;
    const y = ((i * 3571) % (H + 80)) - 40;
    ctx.fillRect(x, y, 6, 6);
  }

  ctx.fillStyle = inkColor;
  ctx.textAlign = "left";

  const scene =
    plan.scenes.find((entry) => t >= entry.start && t < entry.end) ??
    plan.scenes[plan.scenes.length - 1];
  const localT = Math.max(0, Math.min(scene.duration, t - scene.start));
  drawScene(ctx, plan, scene, localT);
  ctx.restore();

  drawChrome(ctx, plan, t, scene);
}
