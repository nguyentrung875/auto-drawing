import ProductTable, { type ProductRowView } from "@/components/ProductTable";
import { Panel, Stat, Tag } from "@/components/ui";
import { formatVnd } from "@/engine/format";
import { listProducts, staleInfo } from "@/engine/product-provider";

export const dynamic = "force-dynamic";

export default async function ProductsPage() {
  const products = await listProducts();
  const rows: ProductRowView[] = products.map((product) => {
    const info = staleInfo(product);
    return {
      productId: product.productId,
      name: product.name,
      brand: product.brand,
      category: product.category,
      price: product.price,
      image: product.image,
      affiliateLink: product.affiliateLink,
      updatedAt: product.updatedAt,
      ageDays: info.ageDays,
      stale: info.stale,
    };
  });

  const prices = products.map((product) => product.price);

  return (
    <main className="mx-auto max-w-7xl space-y-6 px-6 py-8">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold text-white">ProductProvider</h1>
          <p className="mt-1 max-w-2xl text-sm text-slate-400">
            Mock DB 50 SKU — nguồn sự thật duy nhất cho{" "}
            <span className="mono">price</span> và{" "}
            <span className="mono">affiliate_link</span>.
          </p>
        </div>
        <div className="flex gap-2">
          <Tag tone="teal">source=mock</Tag>
          <Tag>FR-2 / AD-4 / AD-5</Tag>
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="total SKU" value={String(products.length)} hint="A-04" />
        <Stat
          label="stale price"
          value={String(rows.filter((row) => row.stale).length)}
          hint="> 7 ngày — chặn đăng (UJ-3)"
          tone="warn"
        />
        <Stat
          label="min price"
          value={formatVnd(Math.min(...prices))}
          hint="VND integer"
        />
        <Stat
          label="max price"
          value={formatVnd(Math.max(...prices))}
          hint="dải giá đủ rộng cho 3 mechanic"
        />
      </div>

      <Panel title="50 SKU" subtitle="Ảnh asset được sinh deterministic từ productId qua Asset Resolver.">
        <ProductTable initial={rows} />
      </Panel>
    </main>
  );
}
