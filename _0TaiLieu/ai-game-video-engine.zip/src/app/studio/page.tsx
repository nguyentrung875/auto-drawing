import Composer, { type ComposerProduct } from "@/components/Composer";
import { Panel, Tag } from "@/components/ui";
import { listProducts, staleInfo } from "@/engine/product-provider";

export const dynamic = "force-dynamic";

export default async function StudioPage() {
  const products = await listProducts();
  const data: ComposerProduct[] = products.map((product) => ({
    productId: product.productId,
    name: product.name,
    brand: product.brand,
    price: product.price,
    category: product.category,
    emoji: product.emoji,
    image: product.image,
    stale: staleInfo(product).stale,
  }));

  return (
    <main className="mx-auto max-w-7xl space-y-6 px-6 py-8">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold text-white">Studio</h1>
          <p className="mt-1 max-w-2xl text-sm text-slate-400">
            <span className="mono">game render --mechanic hi_lo --products p001,p042 --seed 839271</span>{" "}
            — một lệnh, một video 15-21s hoàn chỉnh.
          </p>
        </div>
        <div className="flex gap-2">
          <Tag tone="orange">UJ-1</Tag>
          <Tag>validator &lt; 200ms</Tag>
          <Tag>7 scenes</Tag>
        </div>
      </div>

      <Panel>
        <Composer products={data} />
      </Panel>
    </main>
  );
}
