import Link from "next/link";
import { notFound } from "next/navigation";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { games as gamesTable, renderLogs } from "@/db/schema";
import GamePlayer from "@/components/GamePlayer";
import { Panel, Stat, Tag } from "@/components/ui";
import { buildRenderPlan, captionPayload } from "@/engine/render-plan";
import { formatVnd } from "@/engine/format";
import { staleInfo } from "@/engine/product-provider";

export const dynamic = "force-dynamic";

export default async function GameDetailPage({
  params,
}: {
  params: Promise<{ gameId: string }>;
}) {
  const { gameId } = await params;
  const [row] = await db
    .select()
    .from(gamesTable)
    .where(eq(gamesTable.gameId, gameId))
    .limit(1);
  if (!row) notFound();

  const game = row.gameJson;
  const plan = buildRenderPlan(game);
  const caption = captionPayload(game);
  const [log] = await db
    .select()
    .from(renderLogs)
    .where(eq(renderLogs.gameId, gameId))
    .limit(1);

  const timings = log?.timings;

  return (
    <main className="mx-auto max-w-7xl space-y-6 px-6 py-8">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div className="min-w-0">
          <Link href="/games" className="mono text-xs text-slate-500 hover:text-white">
            ← export/
          </Link>
          <h1 className="mono mt-1 break-all text-xl font-semibold text-white">
            {game.metadata.gameId}
          </h1>
          <p className="mt-1 text-sm text-slate-400">{game.content.title}</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Tag tone="orange">{game.metadata.mechanic}</Tag>
          <Tag>{game.metadata.interaction}</Tag>
          <Tag tone="teal">{game.metadata.resultVariant}</Tag>
          <Tag>seed {game.metadata.seed}</Tag>
          <Tag>{game.metadata.language}</Tag>
        </div>
      </div>

      <Panel
        title="Renderer · 1080×1920 @30fps"
        subtitle="Mỗi glyph do code vẽ — price, timer và text không bao giờ vỡ như AI video đen. Bấm Encode MP4 để encode trực tiếp trong trình duyệt."
      >
        <GamePlayer plan={plan} gameId={game.metadata.gameId} />
      </Panel>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Stat
          label="total duration"
          value={`${game.timeline.totalDuration.toFixed(1)}s`}
          hint="guardrail 15-21s"
          tone="good"
        />
        <Stat
          label="plan + tts + render + encode"
          value={
            timings
              ? `${timings.planning_ms}/${timings.tts_ms}/${timings.render_ms}/${timings.encode_ms} ms`
              : "—"
          }
          hint={timings ? `total ${timings.total_ms} ms` : "chưa có log"}
        />
        <Stat
          label="render payload"
          value={`${((timings?.render_payload_bytes ?? 0) / 1024).toFixed(1)} KB`}
          hint="frame plan + caption manifest"
        />
        <Stat
          label="entities"
          value={String(game.entities.length)}
          hint={game.entities.map((entity) => entity.productId).join(", ")}
        />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Panel
          title="caption.json"
          subtitle="Hermes sẽ đăng kèm MP4 — affiliate_link chỉ nằm ở caption, không burn vào video."
        >
          <pre className="mono max-h-72 overflow-auto rounded-xl border border-white/8 bg-black/50 p-4 text-[11px] leading-relaxed text-slate-300">
{JSON.stringify(caption, null, 2)}
          </pre>
          <div className="mt-3 flex flex-wrap gap-2">
            {game.publishing.hashtags.map((tag) => (
              <Tag key={tag}>{tag}</Tag>
            ))}
          </div>
          <a
            href={`/api/games/${game.metadata.gameId}`}
            target="_blank"
            rel="noreferrer"
            className="mono mt-3 inline-block rounded-lg border border-white/15 px-3 py-1.5 text-[11px] text-slate-200 hover:bg-white/5"
          >
            ⬇ raw JSON (game + plan + logs)
          </a>
        </Panel>

        <Panel title="entities · ProductProvider" subtitle="Giá được resolve từ Provider, LLM không sinh được.">
          <div className="space-y-2">
            {game.entities.map((entity) => {
              const info = staleInfo(entity);
              return (
                <div
                  key={entity.productId}
                  className="flex items-center gap-3 rounded-xl border border-white/8 bg-black/25 p-3"
                >
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={entity.image}
                    alt=""
                    className="h-14 w-14 shrink-0 rounded-lg"
                  />
                  <div className="min-w-0 flex-1">
                    <p className="mono text-[10px] text-slate-500">
                      {entity.productId} · {entity.brand} · {entity.category}
                    </p>
                    <p className="truncate text-xs text-slate-200">
                      {entity.emoji} {entity.name}
                    </p>
                    <p className="mono text-[11px] text-[#12a594]">
                      {formatVnd(entity.price)} · source={entity.source}
                    </p>
                  </div>
                  {info.stale && <Tag tone="amber">stale {info.ageDays}d</Tag>}
                </div>
              );
            })}
          </div>
          <p className="mono mt-3 text-[11px] text-slate-500">
            affiliate: {game.publishing.affiliateLink}
          </p>
        </Panel>
      </div>

      <Panel title="logs" subtitle="NFR-4 — observability cho Hermes tự retry/skip mà không cần operator canh.">
        {timings ? (
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {(
              [
                ["planning_ms", timings.planning_ms],
                ["tts_ms", timings.tts_ms],
                ["render_ms", timings.render_ms],
                ["encode_ms", timings.encode_ms],
                ["audio_voice_ms", timings.audio_voice_ms],
                ["total_ms", timings.total_ms],
              ] as const
            ).map(([key, value]) => (
              <div
                key={key}
                className="mono flex items-center justify-between rounded-lg border border-white/8 bg-black/30 px-3 py-2 text-[11px] text-slate-300"
              >
                <span className="text-slate-500">{key}</span>
                <span>{value} ms</span>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-xs text-slate-500">Chưa có log cho game này.</p>
        )}
        {log && log.warnings.length > 0 && (
          <ul className="mt-3 space-y-1">
            {log.warnings.map((warning, index) => (
              <li key={index} className="mono text-[11px] text-amber-200">
                {warning}
              </li>
            ))}
          </ul>
        )}
        <p className="mono mt-3 text-[11px] text-slate-500">
          replay: game render --mechanic {game.metadata.mechanic.toLowerCase()}{" "}
          --products {game.gameplay.productIds.join(",")} --seed{" "}
          {game.metadata.seed} --result-variant {game.metadata.resultVariant}
        </p>
      </Panel>

      <Panel title="Universal Game JSON" subtitle="Aggregate root — metadata / content / entities / gameplay / scenes / timeline / audio / publishing.">
        <details className="rounded-xl border border-white/8 bg-black/40 p-4">
          <summary className="mono cursor-pointer text-xs text-slate-300">
            mở Game JSON ({game.metadata.engineVersion})
          </summary>
          <pre className="mono mt-3 max-h-[520px] overflow-auto text-[11px] leading-relaxed text-slate-400">
{JSON.stringify(game, null, 2)}
          </pre>
        </details>
      </Panel>
    </main>
  );
}
