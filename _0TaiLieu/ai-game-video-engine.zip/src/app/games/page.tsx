import Link from "next/link";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import { games as gamesTable } from "@/db/schema";
import { Panel, Tag } from "@/components/ui";

export const dynamic = "force-dynamic";

export default async function GamesPage() {
  const rows = await db
    .select({
      gameId: gamesTable.gameId,
      mechanic: gamesTable.mechanic,
      interaction: gamesTable.interaction,
      seed: gamesTable.seed,
      resultVariant: gamesTable.resultVariant,
      totalDurationMs: gamesTable.totalDurationMs,
      batchId: gamesTable.batchId,
      createdAt: gamesTable.createdAt,
    })
    .from(gamesTable)
    .orderBy(desc(gamesTable.createdAt))
    .limit(60);

  return (
    <main className="mx-auto max-w-7xl space-y-6 px-6 py-8">
      <Panel
        title="Export / export/"
        subtitle="MP4 plan + caption.json + hashtags + affiliate_link. Link affiliate chỉ nằm trong caption, không burn vào video."
        actions={<Tag>{rows.length} video</Tag>}
      >
        {rows.length === 0 ? (
          <p className="text-sm text-slate-500">
            Chưa có video. <Link href="/studio" className="text-[#ff5a36]">Render ở Studio</Link>.
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="mono text-[10px] uppercase tracking-[0.12em] text-slate-500">
                <tr>
                  <th className="pb-2">gameId</th>
                  <th className="pb-2">mechanic / interaction</th>
                  <th className="pb-2">variant</th>
                  <th className="pb-2">duration</th>
                  <th className="pb-2">seed</th>
                  <th className="pb-2">batch</th>
                  <th className="pb-2">created</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {rows.map((row) => (
                  <tr key={row.gameId} className="text-slate-300">
                    <td className="py-2 pr-3">
                      <Link
                        href={`/games/${row.gameId}`}
                        className="mono break-all text-[#ff8a6b] hover:underline"
                      >
                        {row.gameId}
                      </Link>
                    </td>
                    <td className="mono py-2 pr-3 text-slate-400">
                      {row.mechanic} · {row.interaction}
                    </td>
                    <td className="py-2 pr-3">{row.resultVariant}</td>
                    <td className="mono py-2 pr-3">
                      {(row.totalDurationMs / 1000).toFixed(1)}s
                    </td>
                    <td className="mono py-2 pr-3">{row.seed}</td>
                    <td className="mono py-2 pr-3 text-slate-500">
                      {row.batchId ?? "—"}
                    </td>
                    <td className="mono py-2 text-slate-500">
                      {row.createdAt.toISOString().slice(0, 19).replace("T", " ")}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Panel>
    </main>
  );
}
