import BatchRunner, { type BatchSummary } from "@/components/BatchRunner";
import { listBatches } from "@/engine/batch";
import { WORKER_POOL_MAX } from "@/engine/pipeline";
import { Tag } from "@/components/ui";

export const dynamic = "force-dynamic";

export default async function BatchPage() {
  const rows = await listBatches(10);
  const initialBatches: BatchSummary[] = rows.map((row) => ({
    batchId: row.batchId,
    status: row.status,
    total: row.total,
    passed: row.passed,
    failed: row.failed,
    avgRenderMs: row.avgRenderMs,
    distinctProducts: row.distinctProducts,
    createdAt: row.createdAt.toISOString(),
  }));

  return (
    <main className="mx-auto max-w-7xl space-y-6 px-6 py-8">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold text-white">Batch factory</h1>
          <p className="mt-1 max-w-2xl text-sm text-slate-400">
            <span className="mono">
              game batch --count 50 --mechanic hi_lo,most_expensive,one_away
            </span>{" "}
            — queue file-semantics, worker pool bounded, retry 3 lần, batch_report
            tự ghi.
          </p>
        </div>
        <div className="flex gap-2">
          <Tag tone="orange">UJ-2</Tag>
          <Tag>WORKER_POOL_MAX={WORKER_POOL_MAX}</Tag>
          <Tag>fail-forward</Tag>
        </div>
      </div>

      <BatchRunner initialBatches={initialBatches} />
    </main>
  );
}
