import Link from "next/link";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import { games as gamesTable } from "@/db/schema";
import { Panel, Stat, Tag } from "@/components/ui";
import { loadStats } from "@/lib/stats";
import { formatVnd } from "@/engine/format";

export const dynamic = "force-dynamic";

const PIPELINE = [
  { label: "Khai báo", detail: "Game + Product Data" },
  { label: "LLM copy", detail: "hook / question / cta" },
  { label: "Game JSON", detail: "universal schema" },
  { label: "Validator", detail: "schema + game logic" },
  { label: "Game Engine", detail: "answer + timeline" },
  { label: "Audio", detail: "viPiper + SFX" },
  { label: "Renderer", detail: "canvas → encoder" },
  { label: "MP4", detail: "1080×1920 30fps" },
];

export default async function DashboardPage() {
  const [stats, recentGames] = await Promise.all([
    loadStats(),
    db
      .select({
        gameId: gamesTable.gameId,
        mechanic: gamesTable.mechanic,
        seed: gamesTable.seed,
        resultVariant: gamesTable.resultVariant,
        totalDurationMs: gamesTable.totalDurationMs,
        createdAt: gamesTable.createdAt,
      })
      .from(gamesTable)
      .orderBy(desc(gamesTable.createdAt))
      .limit(8),
  ]);

  const sm1 = stats.jobs.successRate;
  const sm2 = stats.jobs.avgTotalMs;

  return (
    <main className="mx-auto max-w-7xl space-y-6 px-6 py-8">
      <section className="rounded-3xl border border-white/8 bg-white/[0.03] p-8">
        <div className="flex flex-wrap items-center gap-2">
          <Tag tone="orange">content factory · local-first</Tag>
          <Tag tone="teal">3 mechanics · 3 interaction families</Tag>
          <Tag>7 scenes</Tag>
          <Tag>seed deterministic</Tag>
        </div>
        <h1 className="mt-5 max-w-4xl text-3xl font-semibold leading-tight text-white sm:text-4xl">
          Chỉ cần khai báo game + data — hệ thống tự sinh video quiz 15-21s có
          HOOK, countdown, reveal và lồng tiếng Việt.
        </h1>
        <p className="mt-4 max-w-3xl text-sm leading-relaxed text-slate-400">
          Không phải AI video generator: text, giá và timer luôn render bằng code
          nên không bao giờ vỡ. LLM chỉ viết lời dẫn — mọi con số, đáp án và
          timeline do Engine tính deterministic theo <span className="mono">seed</span>.
        </p>
        <div className="mt-6 flex flex-wrap gap-3">
          <Link
            href="/studio"
            className="rounded-xl bg-[#ff5a36] px-4 py-2 text-sm font-semibold text-black transition hover:brightness-110"
          >
            ▶ Mở Studio render 1 video
          </Link>
          <Link
            href="/batch"
            className="rounded-xl border border-white/15 px-4 py-2 text-sm text-slate-200 transition hover:bg-white/5"
          >
            ⚡ Chạy batch 50 video
          </Link>
          <Link
            href="/products"
            className="rounded-xl border border-white/15 px-4 py-2 text-sm text-slate-200 transition hover:bg-white/5"
          >
            📦 Product DB ({stats.products.total} SKU)
          </Link>
        </div>
      </section>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Stat
          label="SM-1 · render success"
          value={`${sm1}%`}
          hint={`≥98% mục tiêu · ${stats.jobs.done}/${stats.jobs.done + stats.jobs.failed} jobs pass validator + render`}
          tone={sm1 >= 98 ? "good" : sm1 === 0 ? "default" : "warn"}
        />
        <Stat
          label="SM-2 · time-to-mp4"
          value={`${sm2} ms`}
          hint="≤45s/video trên CPU 8 nhân (trung bình toàn bộ job)"
          tone={sm2 <= 45_000 ? "good" : "warn"}
        />
        <Stat
          label="SM-C2 · coverage"
          value={`${stats.batches.latest?.distinctProducts ?? 0}/${stats.coverage.guardrailTarget}`}
          hint="batch 50 phải cover ≥20 distinct productId"
          tone={
            (stats.batches.latest?.distinctProducts ?? 0) >=
            stats.coverage.guardrailTarget
              ? "good"
              : "default"
          }
        />
        <Stat
          label="jobs / games"
          value={`${stats.jobs.total} / ${stats.games.total}`}
          hint={`worker pool max ${stats.workerPoolMax} · manual interventions 0`}
        />
      </div>

      <Panel
        title="Pipeline"
        subtitle="Modular monolith — 6 bounded contexts gọi nhau qua interface nội bộ, không HTTP/RPC ở MVP."
      >
        <div className="flex flex-wrap items-stretch gap-2">
          {PIPELINE.map((stage, index) => (
            <div key={stage.label} className="flex items-center gap-2">
              <div className="w-[132px] rounded-xl border border-white/10 bg-black/30 p-3">
                <p className="mono text-[10px] uppercase tracking-[0.12em] text-slate-500">
                  0{index + 1}
                </p>
                <p className="mt-1 text-xs font-semibold text-white">
                  {stage.label}
                </p>
                <p className="mt-1 text-[11px] leading-snug text-slate-500">
                  {stage.detail}
                </p>
              </div>
              {index < PIPELINE.length - 1 && (
                <span className="text-slate-600">→</span>
              )}
            </div>
          ))}
        </div>
      </Panel>

      <div className="grid gap-4 lg:grid-cols-2">
        <Panel title="Mechanics MVP" subtitle="Mỗi mechanic một họ Interaction khác nhau để chứng minh engine universal.">
          <div className="space-y-3">
            {[
              {
                mechanic: "HI_LO",
                interaction: "BOOLEAN",
                rule: "answer == (priceB > priceA), chênh lệch ≥5%",
                tone: "orange" as const,
              },
              {
                mechanic: "MOST_EXPENSIVE",
                interaction: "MULTIPLE_CHOICE",
                rule: "answer = max(prices), top-2 chênh ≥2%",
                tone: "teal" as const,
              },
              {
                mechanic: "ONE_AWAY",
                interaction: "DIGIT",
                rule: "ẩn 1 digit, 2 options cách nhau 1 đơn vị",
                tone: "rose" as const,
              },
            ].map((item) => {
              const count =
                stats.games.byMechanic.find(
                  (entry) => entry.mechanic === item.mechanic,
                )?.count ?? 0;
              return (
                <div
                  key={item.mechanic}
                  className="rounded-xl border border-white/8 bg-black/25 p-4"
                >
                  <div className="flex flex-wrap items-center gap-2">
                    <Tag tone={item.tone}>{item.mechanic}</Tag>
                    <Tag>{item.interaction}</Tag>
                    <span className="mono ml-auto text-xs text-slate-500">
                      {count} video
                    </span>
                  </div>
                  <p className="mono mt-2 text-[11px] text-slate-400">
                    {item.rule}
                  </p>
                </div>
              );
            })}
          </div>
        </Panel>

        <Panel
          title="ProductProvider"
          subtitle="Source-of-truth cho price + affiliate_link. LLM đề xuất giá khác sẽ bị overwrite."
        >
          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="rounded-xl border border-white/8 bg-black/25 p-3">
              <p className="mono text-[10px] uppercase text-slate-500">total SKU</p>
              <p className="mt-1 text-xl text-white">{stats.products.total}</p>
            </div>
            <div className="rounded-xl border border-white/8 bg-black/25 p-3">
              <p className="mono text-[10px] uppercase text-slate-500">stale price</p>
              <p className="mt-1 text-xl text-amber-300">{stats.products.stale}</p>
              <p className="text-[11px] text-slate-500">&gt;7 ngày chưa update</p>
            </div>
          </div>
          <div className="mt-3 flex flex-wrap gap-2">
            {stats.products.categories.map((entry) => (
              <Tag key={entry.category}>
                {entry.category} · {entry.count}
              </Tag>
            ))}
          </div>
          <p className="mono mt-4 text-[11px] text-slate-500">
            dải giá: {formatVnd(39000)} → {formatVnd(18900000)} · VND integer
          </p>
        </Panel>
      </div>

      <Panel
        title="Video mới render"
        subtitle="Mỗi video có MP4 plan + caption.json + affiliate_link cho Hermes đăng sau."
        actions={
          <Link href="/games" className="mono text-xs text-slate-400 hover:text-white">
            xem tất cả →
          </Link>
        }
      >
        {recentGames.length === 0 ? (
          <p className="text-sm text-slate-500">
            Chưa có video nào. Vào <Link href="/studio" className="text-[#ff5a36]">Studio</Link>{" "}
            render video đầu tiên — hoặc chạy batch ở{" "}
            <Link href="/batch" className="text-[#ff5a36]">Batch</Link>.
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="mono text-[10px] uppercase tracking-[0.12em] text-slate-500">
                <tr>
                  <th className="pb-2">gameId</th>
                  <th className="pb-2">mechanic</th>
                  <th className="pb-2">variant</th>
                  <th className="pb-2">duration</th>
                  <th className="pb-2">seed</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {recentGames.map((game) => (
                  <tr key={game.gameId} className="text-slate-300">
                    <td className="py-2 pr-3">
                      <Link
                        href={`/games/${game.gameId}`}
                        className="mono break-all text-[#ff8a6b] hover:underline"
                      >
                        {game.gameId}
                      </Link>
                    </td>
                    <td className="py-2 pr-3">{game.mechanic}</td>
                    <td className="py-2 pr-3">{game.resultVariant}</td>
                    <td className="py-2 pr-3">
                      {(game.totalDurationMs / 1000).toFixed(1)}s
                    </td>
                    <td className="mono py-2">{game.seed}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Panel>
    </main>
  );
}
