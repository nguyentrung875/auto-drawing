import type { Metadata } from "next";
import type { ReactNode } from "react";
import Nav from "@/components/Nav";
import "./globals.css";

export const metadata: Metadata = {
  title: "Universal AI Game Video Engine",
  description:
    "Content factory nội bộ: LLM → Game JSON → Validator 2 tầng → Game Engine → Asset/Audio → Renderer → MP4 1080×1920.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="vi">
      <body className="min-h-screen bg-[#06080d] text-slate-200 antialiased">
        <div className="grid-bg min-h-screen">
          <Nav />
          {children}
          <footer className="border-t border-white/5 px-6 py-8 text-xs text-slate-500">
            <p className="mono">
              universal-game-video-engine · modular monolith · local-first ·
              Motion Canvas / viPiper / FFmpeg adapters · MIT stack
            </p>
          </footer>
        </div>
      </body>
    </html>
  );
}
