import { loadStats } from "@/lib/stats";

export const dynamic = "force-dynamic";

export async function GET() {
  const stats = await loadStats();
  return Response.json(stats);
}
