import { listProducts, staleInfo, updateProductPrice } from "@/engine/product-provider";

export const dynamic = "force-dynamic";

export async function GET() {
  const products = await listProducts();
  return Response.json({
    total: products.length,
    staleCount: products.filter((product) => staleInfo(product).stale).length,
    products: products.map((product) => ({
      ...product,
      ...staleInfo(product),
    })),
  });
}

/** FR-2 — editing a SKU price is data-only, no code change required. */
export async function PATCH(request: Request) {
  const body = (await request.json().catch(() => null)) as {
    productId?: string;
    price?: number;
  } | null;
  if (!body?.productId || typeof body.price !== "number") {
    return Response.json(
      { ok: false, error: "productId and price are required" },
      { status: 400 },
    );
  }
  if (!Number.isInteger(body.price) || body.price <= 0) {
    return Response.json(
      { ok: false, error: "price must be a positive VND integer" },
      { status: 400 },
    );
  }
  const updated = await updateProductPrice(body.productId, body.price);
  if (!updated) {
    return Response.json({ ok: false, error: "product not found" }, { status: 404 });
  }
  return Response.json({ ok: true, product: { ...updated, ...staleInfo(updated) } });
}
