import { createBatch, listBatches } from "@/engine/batch";
import { MECHANICS } from "@/engine/types";
import type { Mechanic } from "@/engine/types";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await listBatches(10);
  return Response.json({
    batches: rows.map((row) => ({
      batchId: row.batchId,
      status: row.status,
      total: row.total,
      passed: row.passed,
      failed: row.failed,
      avgRenderMs: row.avgRenderMs,
      distinctProducts: row.distinctProducts,
      workerPoolMax: row.workerPoolMax,
      createdAt: row.createdAt,
      finishedAt: row.finishedAt,
    })),
  });
}

/** FR-11 — `game batch --count 50 --mechanic hi_lo,most_expensive,one_away` */
export async function POST(request: Request) {
  const body = (await request.json().catch(() => null)) as {
    count?: number;
    mechanics?: string[];
    resultVariant?: string;
    baseSeed?: number;
  } | null;

  const count = Math.min(Math.max(Number(body?.count ?? 12) || 12, 1), 100);
  const requested = (body?.mechanics ?? [])
    .map((value) => String(value).toUpperCase() as Mechanic)
    .filter((value) => MECHANICS.includes(value));
  const mechanics = requested.length > 0 ? requested : [...MECHANICS];
  const resultVariant = body?.resultVariant === "comment" ? "comment" : "in_video";
  const baseSeed =
    typeof body?.baseSeed === "number" && Number.isInteger(body?.baseSeed)
      ? Math.abs(body.baseSeed) % 1_000_000
      : undefined;

  const batchId = await createBatch({ count, mechanics, resultVariant, baseSeed });
  return Response.json({ ok: true, batchId, count, mechanics, resultVariant });
}
