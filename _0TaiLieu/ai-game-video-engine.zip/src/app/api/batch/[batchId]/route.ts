import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { batches as batchesTable, jobs as jobsTable } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function GET(
  _request: Request,
  context: { params: Promise<{ batchId: string }> },
) {
  const { batchId } = await context.params;
  const [row] = await db
    .select()
    .from(batchesTable)
    .where(eq(batchesTable.batchId, batchId))
    .limit(1);
  if (!row) {
    return Response.json({ ok: false, error: "batch not found" }, { status: 404 });
  }
  const jobs = await db
    .select()
    .from(jobsTable)
    .where(eq(jobsTable.batchId, batchId))
    .orderBy(asc(jobsTable.createdAt));

  return Response.json({
    ok: true,
    batch: {
      batchId: row.batchId,
      status: row.status,
      total: row.total,
      passed: row.passed,
      failed: row.failed,
      avgRenderMs: row.avgRenderMs,
      distinctProducts: row.distinctProducts,
      workerPoolMax: row.workerPoolMax,
      createdAt: row.createdAt,
      finishedAt: row.finishedAt,
      report: row.report,
    },
    jobs: jobs.map((job) => ({
      jobId: job.jobId,
      gameId: job.gameId,
      mechanic: job.mechanic,
      seed: job.seed,
      productIds: job.productIds,
      status: job.status,
      retries: job.retries,
      contentSource: job.contentSource,
      timings: job.timings,
      errors: job.errors,
      warnings: job.warnings,
    })),
  });
}
