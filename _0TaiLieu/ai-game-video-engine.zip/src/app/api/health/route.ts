import { sql } from "drizzle-orm";
import { db } from "@/db";
import { ENGINE_VERSION } from "@/engine/game-factory";
import { WORKER_POOL_MAX } from "@/engine/pipeline";
import { listProducts } from "@/engine/product-provider";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await db.execute(sql`select 1`);
    const products = await listProducts();
    return Response.json({
      ok: true,
      engine: "universal-game-video-engine",
      engineVersion: ENGINE_VERSION,
      workerPoolMax: WORKER_POOL_MAX,
      products: products.length,
      mechanics: ["HI_LO", "MOST_EXPENSIVE", "ONE_AWAY"],
    });
  } catch (error) {
    return Response.json(
      { ok: false, error: (error as Error).message },
      { status: 500 },
    );
  }
}
