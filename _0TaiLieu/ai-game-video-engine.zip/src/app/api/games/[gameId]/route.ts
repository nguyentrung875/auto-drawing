import { eq } from "drizzle-orm";
import { db } from "@/db";
import { games as gamesTable, renderLogs } from "@/db/schema";
import { buildRenderPlan, captionPayload } from "@/engine/render-plan";
import { staleInfo } from "@/engine/product-provider";

export const dynamic = "force-dynamic";

export async function GET(
  _request: Request,
  context: { params: Promise<{ gameId: string }> },
) {
  const { gameId } = await context.params;
  const [row] = await db
    .select()
    .from(gamesTable)
    .where(eq(gamesTable.gameId, gameId))
    .limit(1);
  if (!row) {
    return Response.json({ ok: false, error: "game not found" }, { status: 404 });
  }
  const [log] = await db
    .select()
    .from(renderLogs)
    .where(eq(renderLogs.gameId, gameId))
    .limit(1);

  const game = row.gameJson;
  return Response.json({
    ok: true,
    game,
    plan: buildRenderPlan(game),
    caption: captionPayload(game),
    logs: log
      ? {
          gameId: log.gameId,
          jobId: log.jobId,
          seed: log.seed,
          products: log.products,
          status: log.status,
          timings: log.timings,
          warnings: log.warnings,
          createdAt: log.createdAt,
        }
      : null,
    entities: game.entities.map((entity) => ({
      ...entity,
      ...staleInfo(entity),
    })),
    replay: {
      command: `game render --mechanic ${game.metadata.mechanic.toLowerCase()} --products ${game.gameplay.productIds.join(
        ",",
      )} --seed ${game.metadata.seed} --result-variant ${game.metadata.resultVariant}`,
    },
  });
}
