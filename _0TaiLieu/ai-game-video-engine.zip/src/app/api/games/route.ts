import crypto from "node:crypto";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import { games as gamesTable } from "@/db/schema";
import { createJob, runJob } from "@/engine/pipeline";
import { composeGame } from "@/engine/game-factory";
import { describeAnswer } from "@/engine/mechanics";
import { getProducts, listProducts } from "@/engine/product-provider";
import { MECHANICS } from "@/engine/types";
import type { Mechanic, ResultVariant } from "@/engine/types";

export const dynamic = "force-dynamic";

interface RenderRequest {
  mechanic?: string;
  productIds?: string[];
  seed?: number;
  resultVariant?: string;
  dryRun?: boolean;
}

export async function GET() {
  const rows = await db
    .select({
      gameId: gamesTable.gameId,
      mechanic: gamesTable.mechanic,
      seed: gamesTable.seed,
      resultVariant: gamesTable.resultVariant,
      totalDurationMs: gamesTable.totalDurationMs,
      batchId: gamesTable.batchId,
      createdAt: gamesTable.createdAt,
    })
    .from(gamesTable)
    .orderBy(desc(gamesTable.createdAt))
    .limit(24);
  return Response.json({ games: rows });
}

/** FR-11 — `game render --mechanic hi_lo --products p001,p042 --seed 839271` */
export async function POST(request: Request) {
  const body = (await request.json().catch(() => null)) as RenderRequest | null;
  if (!body) {
    return Response.json({ ok: false, error: "invalid JSON body" }, { status: 400 });
  }

  const mechanic = String(body.mechanic ?? "").toUpperCase() as Mechanic;
  if (!MECHANICS.includes(mechanic)) {
    return Response.json(
      {
        ok: false,
        error: `mechanic must be one of ${MECHANICS.join(", ")} (MVP scope)`,
      },
      { status: 400 },
    );
  }

  const productIds = Array.from(
    new Set((body.productIds ?? []).filter((id) => typeof id === "string")),
  );
  const resultVariant: ResultVariant =
    body.resultVariant === "comment" ? "comment" : "in_video";
  const seed =
    typeof body.seed === "number" && Number.isInteger(body.seed)
      ? Math.abs(body.seed) % 2_000_000_000
      : Date.now() % 1_000_000;

  const entities = await getProducts(productIds);
  if (entities.length !== productIds.length) {
    return Response.json(
      {
        ok: false,
        errors: [
          {
            code: "E_ASSET_MISSING",
            field: "productIds",
            hint: `Không resolve đủ SKU từ ProductProvider (đã tìm thấy ${entities.length}/${productIds.length}).`,
            layer: "asset",
          },
        ],
      },
      { status: 422 },
    );
  }

  const gameId = `${mechanic.toLowerCase()}_${productIds.join("_")}_${seed}`;

  if (body.dryRun) {
    const composed = await composeGame(
      { gameId, mechanic, seed, resultVariant, entities },
      await listProducts(),
    );
    return Response.json(
      {
        ok: composed.ok,
        gameId,
        errors: composed.ok ? [] : composed.errors,
        warnings: composed.warnings,
        validatorMs: Math.round(composed.validatorMs),
        planningMs: Math.round(composed.planningMs),
        contentSource: composed.contentSource,
        answer: composed.ok ? describeAnswer(composed.game.gameplay, entities) : null,
        timeline: composed.ok ? composed.game.timeline : null,
        voiceScript: composed.ok ? composed.game.audio.voice.script : null,
      },
      { status: composed.ok ? 200 : 422 },
    );
  }

  const jobId = crypto.randomUUID().slice(0, 12);
  const job = {
    jobId,
    gameId,
    mechanic,
    productIds,
    seed,
    resultVariant,
    batchId: null as string | null,
  };

  await createJob(job);
  const outcome = await runJob(job);

  if (outcome.status === "failed") {
    return Response.json(
      {
        ok: false,
        jobId,
        gameId,
        productCount: (await listProducts()).length,
        errors: outcome.errors,
        warnings: outcome.warnings,
        timings: outcome.timings,
      },
      { status: 422 },
    );
  }

  return Response.json({
    ok: true,
    jobId,
    gameId,
    status: outcome.status,
    warnings: outcome.warnings,
    timings: outcome.timings,
    contentSource: outcome.contentSource,
    outputPath: outcome.outputPath,
  });
}
