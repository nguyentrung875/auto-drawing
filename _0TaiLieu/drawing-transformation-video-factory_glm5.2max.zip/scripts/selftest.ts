/* Pipeline self-test: run with `npx tsx scripts/selftest.ts` */
import { generateProject } from "@/lib/engine";
import { VARIANTS } from "@/lib/engine/types";
import { TRANSFORMATIONS } from "@/lib/library/transformations";
import { registrySize } from "@/lib/registry";

let failures = 0;
let total = 0;
const rows: string[] = [];

for (const t of TRANSFORMATIONS) {
  for (const variant of VARIANTS) {
    total += 1;
    let generated;
    try {
      generated = generateProject(t, { seed: 12345, variant: variant.key });
    } catch (error) {
      failures += 1;
      rows.push(
        `THROW ${t.slug} [${variant.key}]: ${error instanceof Error ? error.message : error}`,
      );
      continue;
    }
    if (!generated.validation.pass) {
      failures += 1;
      rows.push(
        `FAIL  ${t.slug} [${variant.key}] ${(generated.timeline.totalMs / 1000).toFixed(1)}s: ${generated.validation.errors
          .map((e) => e.code)
          .join(",")}`,
      );
    } else if (variant.key === "curious") {
      rows.push(
        `ok    ${t.slug.padEnd(20)} steps=${generated.plan.steps.length} strokes=${generated.plan.strokeCount} ink=${Math.round(
          generated.plan.inkLength,
        )} dur=${(generated.timeline.totalMs / 1000).toFixed(1)}s bounds=[${generated.plan.bounds.minX.toFixed(
          0,
        )},${generated.plan.bounds.minY.toFixed(0)}..${generated.plan.bounds.maxX.toFixed(0)},${generated.plan.bounds.maxY.toFixed(
          0,
        )}] score=${t.scores.total}`,
      );
    }
  }
}

console.log(rows.join("\n"));
console.log(
  `\nregistry=${JSON.stringify(registrySize())} transformations=${TRANSFORMATIONS.length} combos=${total} failures=${failures} passRate=${(
    ((total - failures) / total) *
    100
  ).toFixed(1)}%`,
);
if (failures > 0) process.exitCode = 1;
