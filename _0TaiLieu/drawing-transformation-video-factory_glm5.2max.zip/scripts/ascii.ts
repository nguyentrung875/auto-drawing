/* Low-fi ASCII render of the final frame so geometry can be inspected in a terminal.
   npx tsx scripts/ascii.ts 8-gau */
import { generateProject } from "@/lib/engine";
import { TRANSFORMATIONS } from "@/lib/library/transformations";

const COLS = 54;

function render(slug: string, progress = 1) {
  const transformation = TRANSFORMATIONS.find((t) => t.slug === slug);
  if (!transformation) {
    console.log(`không tìm thấy ${slug}`);
    return;
  }
  const { plan } = generateProject(transformation, { seed: 12345, variant: "curious" });
  const rows = Math.round((COLS * plan.canvas.height) / plan.canvas.width / 1.85);
  const grid: string[][] = Array.from({ length: rows }, () => Array(COLS).fill(" "));

  const strokes = plan.steps.flatMap((step) => step.strokes);
  let drawn = 0;
  const total = strokes.length;
  const limit = Math.ceil(total * progress);

  for (const stroke of strokes) {
    drawn += 1;
    if (drawn > limit) break;
    const thickness = Math.max(0, Math.round(stroke.width / 22));
    const mark = (px: number, py: number) => {
      const cx = Math.round((px / plan.canvas.width) * (COLS - 1));
      const cy = Math.round((py / plan.canvas.height) * (rows - 1));
      for (let dy = -thickness; dy <= thickness; dy += 1) {
        for (let dx = -thickness; dx <= thickness; dx += 1) {
          const y = cy + dy;
          const x = cx + dx;
          if (y >= 0 && y < rows && x >= 0 && x < COLS) grid[y][x] = "#";
        }
      }
    };
    for (let i = 1; i < stroke.points.length; i += 1) {
      const a = stroke.points[i - 1];
      const b = stroke.points[i];
      const dist = Math.hypot(b.x - a.x, b.y - a.y);
      const steps = Math.max(1, Math.ceil(dist / 6));
      for (let s = 0; s <= steps; s += 1) {
        const t = s / steps;
        mark(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t);
      }
    }
  }

  console.log(`\n=== ${transformation.hook} → ${transformation.subject} (${slug}) ===`);
  const border = "+".padEnd(COLS + 2, "-") + "+";
  console.log(border);
  for (const row of grid) console.log(`|${row.join("")}|`);
  console.log(border);
}

const args = process.argv.slice(2);
const slugs =
  args.length > 0
    ? args
    : ["8-gau", "0-gau-truc", "o-cu-meo", "q-meo", "b-buom-buom", "v-trai-tim"];
for (const slug of slugs) render(slug);
