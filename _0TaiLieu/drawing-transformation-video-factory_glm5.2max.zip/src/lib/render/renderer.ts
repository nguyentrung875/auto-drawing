import { hashString, mulberry32 } from "@/lib/engine/rng";
import { STAGE } from "@/lib/engine/plan";
import { getVariant, type DrawingPlan, type PlanStroke, type Timeline } from "@/lib/engine/types";

export type Palette = {
  paper: string;
  paperEdge: string;
  ink: string;
  inkSoft: string;
  accent: string;
  accentSoft: string;
  muted: string;
  text: string;
};

export const PALETTE: Palette = {
  paper: "#f8f4ec",
  paperEdge: "#efe8dc",
  ink: "#1c2029",
  inkSoft: "#3d4450",
  accent: "#ef6a3c",
  accentSoft: "#ffd9c7",
  muted: "#a49b8e",
  text: "#1c2029",
};

const FONT = `"Helvetica Neue", "Segoe UI", system-ui, -apple-system, sans-serif`;

type Ctx2D = CanvasRenderingContext2D | OffscreenCanvasRenderingContext2D;

/* ------------------------------ backdrop ------------------------------- */

let backdropCache: { key: string; canvas: HTMLCanvasElement | OffscreenCanvas } | null =
  null;

function createCanvas(w: number, h: number): HTMLCanvasElement | OffscreenCanvas {
  if (typeof OffscreenCanvas !== "undefined") {
    return new OffscreenCanvas(w, h);
  }
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  return canvas;
}

function buildBackdrop(width: number, height: number, seed: number) {
  const key = `${width}x${height}:${seed}`;
  if (backdropCache && backdropCache.key === key) return backdropCache.canvas;
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext("2d") as Ctx2D | null;
  if (!ctx) return canvas;

  ctx.fillStyle = PALETTE.paper;
  ctx.fillRect(0, 0, width, height);

  // Soft vignette so the paper does not look flat.
  const grad = ctx.createRadialGradient(
    width / 2,
    height * 0.45,
    width * 0.1,
    width / 2,
    height * 0.5,
    width * 1.15,
  );
  grad.addColorStop(0, "rgba(255,255,255,0.55)");
  grad.addColorStop(1, "rgba(215,203,184,0.5)");
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, width, height);

  // Deterministic paper grain.
  const rng = mulberry32(seed ^ 0x9e3779b9);
  ctx.fillStyle = "rgba(120,110,96,0.06)";
  for (let i = 0; i < 2200; i += 1) {
    const x = rng() * width;
    const y = rng() * height;
    const r = 0.6 + rng() * 1.6;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }

  // Corner margin guides (sketchbook feel).
  ctx.strokeStyle = "rgba(120,110,96,0.18)";
  ctx.lineWidth = 2;
  const pad = 56;
  ctx.beginPath();
  ctx.moveTo(pad, pad + 26);
  ctx.lineTo(pad, pad);
  ctx.lineTo(pad + 26, pad);
  ctx.moveTo(width - pad - 26, height - pad);
  ctx.lineTo(width - pad, height - pad);
  ctx.lineTo(width - pad, height - pad - 26);
  ctx.stroke();

  backdropCache = { key, canvas };
  return canvas;
}

/* ------------------------------- text ---------------------------------- */

function drawText(
  ctx: Ctx2D,
  text: string,
  x: number,
  y: number,
  opts: {
    size: number;
    color?: string;
    weight?: number;
    align?: CanvasTextAlign;
    alpha?: number;
  },
) {
  ctx.save();
  ctx.globalAlpha = opts.alpha ?? 1;
  ctx.fillStyle = opts.color ?? PALETTE.text;
  ctx.font = `${opts.weight ?? 700} ${opts.size}px ${FONT}`;
  ctx.textAlign = opts.align ?? "center";
  ctx.textBaseline = "middle";
  ctx.fillText(text, x, y);
  ctx.restore();
}

function roundRect(
  ctx: Ctx2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

/* ------------------------------ renderer ------------------------------- */

export type FrameRendererOptions = {
  ctaText: string;
  showPen?: boolean;
  showUi?: boolean;
  grain?: boolean;
};

export type FrameRenderer = {
  width: number;
  height: number;
  render: (ctx: Ctx2D, timeMs: number) => void;
};

type PreparedStroke = {
  stroke: PlanStroke;
  offsets: Float32Array;
};

function easeOut(t: number): number {
  return 1 - Math.pow(1 - t, 3);
}

function clamp01(v: number): number {
  return v < 0 ? 0 : v > 1 ? 1 : v;
}

export function createFrameRenderer(
  plan: DrawingPlan,
  timeline: Timeline,
  options: FrameRendererOptions,
): FrameRenderer {
  const variant = getVariant(plan.variant);
  const ctaText = options.ctaText;
  const showPen = options.showPen ?? true;
  const showUi = options.showUi ?? true;

  const prepared: PreparedStroke[] = [];
  for (const step of plan.steps) {
    for (const stroke of step.strokes) {
      const rng = mulberry32(hashString(stroke.id) ^ plan.seed);
      const phase = rng() * Math.PI * 2;
      const phase2 = rng() * Math.PI * 2;
      const freq = 0.07 + rng() * 0.05;
      const amp = variant.penWobble * 1.1;
      const offsets = new Float32Array(stroke.points.length * 2);
      for (let i = 0; i < stroke.points.length; i += 1) {
        offsets[i * 2] = Math.sin(i * freq + phase) * amp;
        offsets[i * 2 + 1] =
          Math.cos(i * freq * 1.27 + phase2) * amp * 0.85;
      }
      prepared.push({ stroke, offsets });
    }
  }

  const boundsCx = (plan.bounds.minX + plan.bounds.maxX) / 2;
  const boundsCy = (plan.bounds.minY + plan.bounds.maxY) / 2;

  const drawStroke = (
    ctx: Ctx2D,
    item: PreparedStroke,
    progress: number,
    color: string,
  ) => {
    const { stroke, offsets } = item;
    if (progress <= 0) return;
    const target = progress >= 1 ? stroke.length : stroke.length * progress;
    ctx.save();
    ctx.strokeStyle = color;
    ctx.lineWidth = stroke.width;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.beginPath();
    const pts = stroke.points;
    let acc = 0;
    ctx.moveTo(
      pts[0].x + offsets[0],
      pts[0].y + offsets[1],
    );
    for (let i = 1; i < pts.length; i += 1) {
      const dx = pts[i].x - pts[i - 1].x;
      const dy = pts[i].y - pts[i - 1].y;
      const seg = Math.hypot(dx, dy);
      if (acc + seg <= target) {
        acc += seg;
        ctx.lineTo(
          pts[i].x + offsets[i * 2],
          pts[i].y + offsets[i * 2 + 1],
        );
      } else {
        const t = seg === 0 ? 0 : (target - acc) / seg;
        ctx.lineTo(
          pts[i - 1].x + dx * t + offsets[i * 2],
          pts[i - 1].y + dy * t + offsets[i * 2 + 1],
        );
        break;
      }
    }
    ctx.stroke();
    ctx.restore();
  };

  const penPosition = (timeMs: number) => {
    let last: { x: number; y: number } | null = null;
    let active: { x: number; y: number } | null = null;
    let lifting = false;
    for (const item of prepared) {
      const { stroke } = item;
      const lastPoint = stroke.points[stroke.points.length - 1];
      const start = stroke.points[0];
      if (timeMs < stroke.startMs) {
        if (!last) last = start;
        break;
      }
      if (timeMs >= stroke.endMs) {
        last = lastPoint;
        if (timeMs < stroke.endMs + stroke.liftMs) {
          lifting = true;
        }
        continue;
      }
      const p = clamp01(
        (timeMs - stroke.startMs) / Math.max(1, stroke.endMs - stroke.startMs),
      );
      const target = stroke.length * p;
      let acc = 0;
      let point = start;
      for (let i = 1; i < stroke.points.length; i += 1) {
        const seg = Math.hypot(
          stroke.points[i].x - stroke.points[i - 1].x,
          stroke.points[i].y - stroke.points[i - 1].y,
        );
        if (acc + seg >= target) {
          const t = seg === 0 ? 0 : (target - acc) / seg;
          point = {
            x:
              stroke.points[i - 1].x +
              (stroke.points[i].x - stroke.points[i - 1].x) * t,
            y:
              stroke.points[i - 1].y +
              (stroke.points[i].y - stroke.points[i - 1].y) * t,
          };
          break;
        }
        acc += seg;
        point = stroke.points[i];
      }
      active = point;
      break;
    }
    return { point: active ?? last, lifting };
  };

  const drawPen = (ctx: Ctx2D, x: number, y: number, lifting: boolean) => {
    ctx.save();
    ctx.translate(x, y);
    const lift = lifting ? 1 : 0;
    ctx.globalAlpha = lifting ? 0.82 : 1;
    ctx.rotate(-0.92);
    ctx.translate(0, -lift * 26);
    // nib
    ctx.fillStyle = PALETTE.ink;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(15, -66);
    ctx.lineTo(-15, -66);
    ctx.closePath();
    ctx.fill();
    // body
    ctx.fillStyle = "#f2f3f7";
    ctx.strokeStyle = "#2a2f3a";
    ctx.lineWidth = 4;
    roundRect(ctx, -19, -248, 38, 184, 14);
    ctx.fill();
    ctx.stroke();
    // grip band
    ctx.fillStyle = PALETTE.accent;
    roundRect(ctx, -19, -132, 38, 34, 6);
    ctx.fill();
    ctx.restore();
  };

  const render = (ctx: Ctx2D, timeMs: number) => {
    const { width, height } = plan.canvas;
    const t = Math.max(0, Math.min(timeMs, timeline.totalMs));

    ctx.save();
    ctx.clearRect(0, 0, width, height);
    const backdrop = buildBackdrop(width, height, plan.seed);
    ctx.drawImage(backdrop as CanvasImageSource, 0, 0);

    const inHook = t < timeline.hookMs;
    const revealStart = timeline.segments.find((s) => s.kind === "reveal")!.startMs;
    const ctaStart = timeline.segments.find((s) => s.kind === "cta")!.startMs;
    const inReveal = t >= revealStart && t < ctaStart;
    const inCta = t >= ctaStart;

    /* ------------------------------ ink ------------------------------ */
    const revealT = clamp01((t - revealStart) / 900);
    const pulse = inReveal ? 1 + Math.sin(easeOut(revealT) * Math.PI) * 0.035 : 1;

    ctx.save();
    if (inReveal || inCta) {
      ctx.translate(boundsCx, boundsCy);
      ctx.scale(pulse, pulse);
      ctx.translate(-boundsCx, -boundsCy);
    }

    if (inHook) {
      // Ghost of the hook so the viewer instantly reads the hook (Q1).
      ctx.globalAlpha = 0.16;
      for (const item of prepared) {
        if (item.stroke.stepId !== plan.steps[0].id) continue;
        drawStroke(ctx, item, 1, PALETTE.inkSoft);
      }
      ctx.globalAlpha = 1;
    } else {
      for (const item of prepared) {
        const p = clamp01(
          (t - item.stroke.startMs) /
            Math.max(1, item.stroke.endMs - item.stroke.startMs),
        );
        if (p <= 0) continue;
        drawStroke(ctx, item, p, PALETTE.ink);
      }
      if (inReveal || inCta) {
        ctx.globalAlpha = 0.1 * (1 - clamp01((t - revealStart) / 1400));
        for (const item of prepared) {
          drawStroke(ctx, item, 1, PALETTE.accent);
        }
        ctx.globalAlpha = 1;
      }
    }
    ctx.restore();

    /* ------------------------------ pen ------------------------------ */
    const drawing = t >= timeline.hookMs && t < revealStart;
    if (showPen && drawing) {
      const { point, lifting } = penPosition(t);
      if (point) drawPen(ctx, point.x, point.y, lifting);
    }

    /* ---------------------------- reveal fx -------------------------- */
    if (inReveal || inCta) {
      const burst = clamp01((t - revealStart) / 700);
      const alpha = (1 - burst) * 0.85;
      if (alpha > 0.01) {
        ctx.save();
        ctx.strokeStyle = PALETTE.accent;
        ctx.globalAlpha = alpha;
        ctx.lineWidth = 7;
        ctx.lineCap = "round";
        const rays = 14;
        for (let i = 0; i < rays; i += 1) {
          const a = (i / rays) * Math.PI * 2 + 0.3;
          const inner = 120 + burst * 300;
          const outer = 210 + burst * 420;
          ctx.beginPath();
          ctx.moveTo(
            boundsCx + Math.cos(a) * inner,
            boundsCy + Math.sin(a) * inner,
          );
          ctx.lineTo(
            boundsCx + Math.cos(a) * outer,
            boundsCy + Math.sin(a) * outer,
          );
          ctx.stroke();
        }
        ctx.restore();
      }
    }

    /* ------------------------------- ui ------------------------------ */
    if (!showUi) {
      ctx.restore();
      return;
    }

    const hookTitle = inHook
      ? variant.hookTitle
      : inReveal || inCta
        ? plan.subjectLabel
        : currentStepLabel(plan, t);

    drawText(ctx, "DRAWING TRANSFORMATION", width / 2, 108, {
      size: 30,
      color: PALETTE.muted,
      weight: 700,
      alpha: 0.9,
    });

    const title = inHook
      ? `${plan.hook}  →  ?`
      : inReveal || inCta
        ? `${plan.hook}  →  ${plan.subjectLabel}`
        : `${plan.hook}  →  ?`;
    drawText(ctx, title, width / 2, 208, {
      size: inReveal || inCta ? 104 : 92,
      color: inReveal || inCta ? PALETTE.accent : PALETTE.text,
      weight: 800,
    });

    if (hookTitle) {
      drawText(ctx, hookTitle, width / 2, 300, {
        size: 46,
        color: inReveal || inCta ? PALETTE.text : PALETTE.inkSoft,
        weight: 600,
        alpha: 0.95,
      });
    }

    // step counter + caption during the drawing phase
    if (!inHook && !inReveal && !inCta) {
      const index = plan.steps.findIndex(
        (step) => t >= step.startMs && t <= step.endMs + step.pauseMs,
      );
      if (index >= 0) {
        drawText(
          ctx,
          `${index + 1}/${plan.steps.length} · ${plan.steps[index].name}`,
          width / 2,
          1390,
          { size: 40, color: PALETTE.inkSoft, weight: 600 },
        );
      }
    }

    // progress bar
    const barW = 880;
    const barX = (width - barW) / 2;
    const barY = 1452;
    ctx.save();
    ctx.fillStyle = "rgba(120,110,96,0.22)";
    roundRect(ctx, barX, barY, barW, 14, 7);
    ctx.fill();
    ctx.fillStyle = PALETTE.accent;
    roundRect(
      ctx,
      barX,
      barY,
      Math.max(14, barW * clamp01(t / timeline.totalMs)),
      14,
      7,
    );
    ctx.fill();
    ctx.restore();

    // CTA card
    if (inCta) {
      const pop = easeOut(clamp01((t - ctaStart) / 420));
      ctx.save();
      ctx.globalAlpha = pop;
      ctx.translate(width / 2, 1600);
      ctx.scale(0.9 + pop * 0.1, 0.9 + pop * 0.1);
      ctx.translate(-width / 2, -1600);
      ctx.fillStyle = PALETTE.accentSoft;
      roundRect(ctx, 110, 1520, width - 220, 170, 40);
      ctx.fill();
      drawText(ctx, ctaText, width / 2, 1590, {
        size: 58,
        color: "#8a3113",
        weight: 800,
      });
      drawText(ctx, `${plan.hook} → ${plan.subjectLabel} · seed ${plan.seed}`, width / 2, 1652, {
        size: 28,
        color: "#8a3113",
        weight: 600,
        alpha: 0.8,
      });
      ctx.restore();
    }

    drawText(
      ctx,
      `deterministic drawing · ${plan.strokeCount} nét · ${(timeline.totalMs / 1000).toFixed(1)}s`,
      width / 2,
      1820,
      { size: 26, color: PALETTE.muted, weight: 600 },
    );

    ctx.restore();
  };

  return { width: plan.canvas.width, height: plan.canvas.height, render };
}

function currentStepLabel(plan: DrawingPlan, tMs: number): string {
  const step = plan.steps.find(
    (s) => tMs >= s.startMs && tMs <= s.endMs + s.pauseMs,
  );
  if (!step) return "đang vẽ…";
  return step.kind === "glyph" ? `vẽ ${step.name.toLowerCase()}` : step.name;
}

export { STAGE };
