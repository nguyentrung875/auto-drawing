import { ArrayBufferTarget, Muxer } from "mp4-muxer";
import type { DrawingPlan, Timeline } from "@/lib/engine/types";
import { createFrameRenderer, type FrameRendererOptions } from "./renderer";

export type ExportResult = {
  blob: Blob;
  fileName: string;
  encoder: string;
  frames: number;
  durationMs: number;
  renderMs: number;
  sizeBytes: number;
  width: number;
  height: number;
  fps: number;
};

const AVC_CANDIDATES = [
  "avc1.640028",
  "avc1.4d0028",
  "avc1.420028",
  "avc1.64001f",
  "avc1.42001f",
];

export function webCodecsSupported(): boolean {
  return (
    typeof window !== "undefined" &&
    typeof (window as unknown as { VideoEncoder?: unknown }).VideoEncoder ===
      "function" &&
    typeof (window as unknown as { VideoFrame?: unknown }).VideoFrame ===
      "function"
  );
}

async function pickCodec(
  width: number,
  height: number,
  framerate: number,
  bitrate: number,
): Promise<string | null> {
  for (const codec of AVC_CANDIDATES) {
    try {
      const support = await VideoEncoder.isConfigSupported({
        codec,
        width,
        height,
        bitrate,
        framerate,
      });
      if (support.supported) return codec;
    } catch {
      // keep probing
    }
  }
  return null;
}

/**
 * Renders every frame from the timeline into an H.264 MP4.
 * Frames come from the same deterministic renderer used for preview, so
 * the exported file is byte-for-byte reproducible from the plan (NFR-002).
 */
export async function exportMp4(
  options: FrameRendererOptions & {
    plan: DrawingPlan;
    timeline: Timeline;
    bitrate?: number;
    onProgress?: (progress: number, stage: string) => void;
  },
): Promise<ExportResult> {
  const { plan, timeline, onProgress } = options;
  const started = Date.now();
  const width = plan.canvas.width;
  const height = plan.canvas.height;
  const fps = timeline.fps;
  const bitrate = options.bitrate ?? 6_000_000;

  const renderer = createFrameRenderer(plan, timeline, {
    ctaText: options.ctaText,
    showPen: options.showPen ?? true,
    showUi: options.showUi ?? true,
  });

  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d", { alpha: false });
  if (!ctx) throw new Error("Canvas 2D không khả dụng");

  if (!webCodecsSupported()) {
    return exportWebmFallback({
      canvas,
      ctx,
      renderer: { render: (t) => renderer.render(ctx, t) },
      plan,
      timeline,
      started,
    });
  }

  const codec = await pickCodec(width, height, fps, bitrate);
  if (!codec) {
    return exportWebmFallback({
      canvas,
      ctx,
      renderer: { render: (t) => renderer.render(ctx, t) },
      plan,
      timeline,
      started,
    });
  }

  const muxer = new Muxer({
    target: new ArrayBufferTarget(),
    video: { codec: "avc", width, height, frameRate: fps },
    fastStart: "in-memory",
  });

  let encodeError: Error | null = null;
  const encoder = new VideoEncoder({
    output: (chunk, meta) => muxer.addVideoChunk(chunk, meta),
    error: (e: DOMException) => {
      encodeError = new Error(e.message);
    },
  });
  encoder.configure({
    codec,
    width,
    height,
    bitrate,
    framerate: fps,
    latencyMode: "quality",
  });

  const frameCount = Math.min(timeline.frameCount, fps * 120);
  for (let frame = 0; frame < frameCount; frame += 1) {
    if (encodeError) throw encodeError;
    renderer.render(ctx, (frame * 1000) / fps);
    const videoFrame = new VideoFrame(canvas, {
      timestamp: Math.round((frame * 1e6) / fps),
      duration: Math.round(1e6 / fps),
    });
    encoder.encode(videoFrame, { keyFrame: frame % (fps * 2) === 0 });
    videoFrame.close();
    if (encoder.encodeQueueSize > 12) {
      await new Promise((resolve) => setTimeout(resolve, 0));
    }
    if (onProgress && frame % 15 === 0) {
      onProgress(frame / frameCount, `Encoding ${frame}/${frameCount}`);
    }
  }

  onProgress?.(0.97, "Finalising MP4");
  await encoder.flush();
  encoder.close();
  muxer.finalize();
  const buffer = (muxer.target as ArrayBufferTarget).buffer;
  if (!buffer) throw new Error("MP4 muxer trả về buffer rỗng");
  const blob = new Blob([buffer], { type: "video/mp4" });

  return {
    blob,
    fileName: `${plan.hook.replace(/[^a-z0-9]+/gi, "-")}-to-${plan.subject
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-zA-Z0-9]+/g, "-")
      .toLowerCase()}-seed${plan.seed}.mp4`,
    encoder: `webcodecs:${codec}`,
    frames: frameCount,
    durationMs: (frameCount * 1000) / fps,
    renderMs: Date.now() - started,
    sizeBytes: blob.size,
    width,
    height,
    fps,
  };
}

/**
 * Fallback for browsers without WebCodecs: real-time capture with
 * MediaRecorder. Output is WebM and not frame-exact, so the deterministic
 * MP4 path is always preferred.
 */
async function exportWebmFallback(args: {
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
  renderer: { render: (t: number) => void };
  plan: DrawingPlan;
  timeline: Timeline;
  started: number;
  onProgress?: (progress: number, stage: string) => void;
}): Promise<ExportResult> {
  const { canvas, renderer, plan, timeline, started } = args;
  const stream = canvas.captureStream(timeline.fps);
  const mimeType = MediaRecorder.isTypeSupported("video/webm;codecs=vp9")
    ? "video/webm;codecs=vp9"
    : "video/webm";
  const recorder = new MediaRecorder(stream, {
    mimeType,
    videoBitsPerSecond: 6_000_000,
  });
  const chunks: BlobPart[] = [];
  recorder.ondataavailable = (event) => {
    if (event.data.size > 0) chunks.push(event.data);
  };
  const done = new Promise<void>((resolve) => {
    recorder.onstop = () => resolve();
  });
  recorder.start(200);

  const totalMs = timeline.totalMs;
  const t0 = performance.now();
  await new Promise<void>((resolve) => {
    const tick = () => {
      const t = performance.now() - t0;
      renderer.render(Math.min(t, totalMs));
      args.onProgress?.(t / totalMs, `Recording ${(t / 1000).toFixed(1)}s`);
      if (t >= totalMs) {
        resolve();
        return;
      }
      requestAnimationFrame(tick);
    };
    tick();
  });
  recorder.stop();
  await done;
  const blob = new Blob(chunks, { type: "video/webm" });
  return {
    blob,
    fileName: `${plan.subjectKey}-seed${plan.seed}.webm`,
    encoder: `mediarecorder:${mimeType}`,
    frames: Math.round((totalMs / 1000) * timeline.fps),
    durationMs: totalMs,
    renderMs: Date.now() - started,
    sizeBytes: blob.size,
    width: plan.canvas.width,
    height: plan.canvas.height,
    fps: timeline.fps,
  };
}

export function downloadBlob(blob: Blob, fileName: string) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

export function capturePoster(
  plan: DrawingPlan,
  timeline: Timeline,
  options: FrameRendererOptions & { timeMs?: number; width?: number },
): string {
  const renderer = createFrameRenderer(plan, timeline, {
    ctaText: options.ctaText,
    showPen: false,
    showUi: true,
  });
  const scale = (options.width ?? 540) / renderer.width;
  const canvas = document.createElement("canvas");
  canvas.width = Math.round(renderer.width * scale);
  canvas.height = Math.round(renderer.height * scale);
  const ctx = canvas.getContext("2d");
  if (!ctx) return "";
  ctx.scale(scale, scale);
  renderer.render(ctx, options.timeMs ?? timeline.inkEndMs);
  return canvas.toDataURL("image/jpeg", 0.72);
}
