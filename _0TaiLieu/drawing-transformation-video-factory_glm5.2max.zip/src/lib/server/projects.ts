import { and, desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  batchItems,
  batches,
  performanceMetrics,
  projects,
  renders,
  transformations,
} from "@/db/schema";
import { ensureSeed } from "@/db/seed";
import { generateProject } from "@/lib/engine";
import {
  TRANSFORMATIONS,
  findTransformationByInput,
  getTransformation,
} from "@/lib/library/transformations";

export type CreateProjectInput = {
  slug: string;
  seed?: number | null;
  variant?: string;
  cta?: string;
  batchId?: number | null;
};

export async function createProject(input: CreateProjectInput) {
  await ensureSeed();
  const def =
    getTransformation(input.slug) ?? findTransformationByInput(input.slug);
  if (!def) {
    throw new Error(`Không tìm thấy transformation: ${input.slug}`);
  }

  const [row] = await db
    .select()
    .from(transformations)
    .where(eq(transformations.slug, def.slug))
    .limit(1);
  const transformationRow = row;
  if (!transformationRow) {
    throw new Error(`Transformation chưa được seed: ${def.slug}`);
  }

  const generated = generateProject(def, {
    seed: input.seed,
    variant: input.variant,
    cta: input.cta,
  });

  const [inserted] = await db
    .insert(projects)
    .values({
      transformationId: transformationRow.id,
      seed: generated.plan.seed,
      version: generated.plan.version,
      variant: generated.plan.variant,
      status: generated.validation.pass ? "validated" : "invalid",
      plan: generated.plan,
      timeline: generated.timeline,
      validation: generated.validation,
      voiceCues: generated.voiceCues,
      cost: generated.cost,
      generationMs: generated.generationMs,
      batchId: input.batchId ?? null,
    })
    .returning();

  return { project: inserted, transformation: transformationRow, generated };
}

export async function listProjects(limit = 40) {
  await ensureSeed();
  return db
    .select({
      id: projects.id,
      seed: projects.seed,
      variant: projects.variant,
      status: projects.status,
      createdAt: projects.createdAt,
      validation: projects.validation,
      timeline: projects.timeline,
      cost: projects.cost,
      hook: transformations.hook,
      subject: transformations.subject,
      title: transformations.title,
      slug: transformations.slug,
      scores: transformations.scores,
      category: transformations.hookCategory,
      poster: projects.poster,
    })
    .from(projects)
    .innerJoin(transformations, eq(projects.transformationId, transformations.id))
    .orderBy(desc(projects.id))
    .limit(limit);
}

export async function getProject(id: number) {
  await ensureSeed();
  const [row] = await db
    .select({
      project: projects,
      transformation: transformations,
    })
    .from(projects)
    .innerJoin(transformations, eq(projects.transformationId, transformations.id))
    .where(eq(projects.id, id))
    .limit(1);
  if (!row) return null;
  const renderRows = await db
    .select()
    .from(renders)
    .where(eq(renders.projectId, id))
    .orderBy(desc(renders.id))
    .limit(10);
  const metrics = await db
    .select()
    .from(performanceMetrics)
    .where(eq(performanceMetrics.projectId, id));
  return { ...row, renders: renderRows, metrics };
}

export async function updateProjectPoster(id: number, poster: string) {
  await db.update(projects).set({ poster }).where(eq(projects.id, id));
}

export async function recordRender(input: {
  projectId: number;
  format: string;
  encoder: string;
  status: string;
  width: number;
  height: number;
  fps: number;
  durationMs: number;
  sizeBytes: number;
  renderMs: number;
  hasVoice: number;
  notes?: string | null;
  poster?: string | null;
}) {
  const [row] = await db
    .insert(renders)
    .values({
      projectId: input.projectId,
      format: input.format,
      encoder: input.encoder,
      status: input.status,
      width: input.width,
      height: input.height,
      fps: input.fps,
      durationMs: input.durationMs,
      sizeBytes: input.sizeBytes,
      renderMs: input.renderMs,
      hasVoice: input.hasVoice,
      notes: input.notes ?? null,
    })
    .returning();
  if (input.poster) {
    await updateProjectPoster(input.projectId, input.poster);
  }
  return row;
}

/* ------------------------------- batches -------------------------------- */

export async function createBatch(input: {
  name: string;
  size: number;
  category?: string;
  seed?: number;
  variant?: string;
}) {
  await ensureSeed();
  const size = Math.max(1, Math.min(100, Math.floor(input.size)));
  const pool = TRANSFORMATIONS.filter(
    (t) => !input.category || input.category === "all" || t.hookCategory === input.category,
  );
  const usable = pool.length > 0 ? pool : TRANSFORMATIONS;
  const baseSeed = input.seed ?? 12345;

  const [batch] = await db
    .insert(batches)
    .values({
      name: input.name,
      sizeRequested: size,
      sizeCreated: 0,
      params: {
        category: input.category ?? "all",
        seed: baseSeed,
        variant: input.variant ?? "curious",
      },
    })
    .returning();

  const items: Array<{
    projectId: number;
    transformationId: number;
    hook: string;
    subject: string;
    status: string;
    validationPass: number;
    orderIndex: number;
  }> = [];

  for (let i = 0; i < size; i += 1) {
    const def = usable[(baseSeed + i * 7) % usable.length];
    try {
      const created = await createProject({
        slug: def.slug,
        seed: baseSeed + i,
        variant: input.variant ?? "curious",
        batchId: batch.id,
      });
      items.push({
        projectId: created.project.id,
        transformationId: created.transformation.id,
        hook: def.hook,
        subject: def.subject,
        status: created.generated.validation.pass ? "validated" : "invalid",
        validationPass: created.generated.validation.pass ? 1 : 0,
        orderIndex: i,
      });
    } catch {
      items.push({
        projectId: 0,
        transformationId: 0,
        hook: def.hook,
        subject: def.subject,
        status: "failed",
        validationPass: 0,
        orderIndex: i,
      });
    }
  }

  const validItems = items.filter((item) => item.projectId > 0);
  if (validItems.length > 0) {
    await db
      .insert(batchItems)
      .values(
        validItems.map((item) => ({
          batchId: batch.id,
          projectId: item.projectId,
          transformationId: item.transformationId,
          hook: item.hook,
          subject: item.subject,
          status: item.status,
          validationPass: item.validationPass,
          orderIndex: item.orderIndex,
        })),
      );
  }

  const [updated] = await db
    .update(batches)
    .set({ sizeCreated: validItems.length })
    .where(eq(batches.id, batch.id))
    .returning();

  return { batch: updated, items };
}

export async function listBatches(limit = 20) {
  await ensureSeed();
  return db
    .select()
    .from(batches)
    .orderBy(desc(batches.id))
    .limit(limit);
}

export async function getBatch(id: number) {
  await ensureSeed();
  const [batch] = await db.select().from(batches).where(eq(batches.id, id)).limit(1);
  if (!batch) return null;
  const items = await db
    .select({
      item: batchItems,
      project: projects,
    })
    .from(batchItems)
    .leftJoin(projects, eq(batchItems.projectId, projects.id))
    .where(eq(batchItems.batchId, id))
    .orderBy(batchItems.orderIndex);
  return { batch, items };
}

/* ------------------------------- metrics -------------------------------- */

export async function upsertMetrics(input: {
  projectId: number;
  platform: string;
  views: number;
  retention3s: number;
  avgWatchMs: number;
  completionRate: number;
  replayRate: number;
  shareRate: number;
  saveRate: number;
  ctr: number;
  conversions: number;
  revenueMicros: number;
  notes?: string | null;
}) {
  const existing = await db
    .select()
    .from(performanceMetrics)
    .where(
      and(
        eq(performanceMetrics.projectId, input.projectId),
        eq(performanceMetrics.platform, input.platform),
      ),
    )
    .limit(1);
  if (existing.length > 0) {
    const [row] = await db
      .update(performanceMetrics)
      .set({ ...input, updatedAt: new Date() })
      .where(eq(performanceMetrics.id, existing[0].id))
      .returning();
    return row;
  }
  const [row] = await db
    .insert(performanceMetrics)
    .values(input)
    .returning();
  return row;
}

export type FactoryStats = {
  transformations: number;
  categories: number;
  projects: number;
  validated: number;
  invalid: number;
  renders: number;
  batches: number;
  avgDurationMs: number;
  avgCostUsd: number;
  validationPassRate: number;
};

export async function getFactoryStats(): Promise<FactoryStats> {
  await ensureSeed();
  const [counts] = await db
    .select({
      transformations: sql<number>`(select count(*)::int from ${transformations})`,
      projects: sql<number>`(select count(*)::int from ${projects})`,
      validated: sql<number>`(select count(*)::int from ${projects} where status = 'validated')`,
      invalid: sql<number>`(select count(*)::int from ${projects} where status <> 'validated')`,
      renders: sql<number>`(select count(*)::int from ${renders})`,
      batches: sql<number>`(select count(*)::int from ${batches})`,
      avgDuration: sql<number>`(select coalesce(avg((timeline->>'totalMs')::numeric), 0)::int from ${projects})`,
      avgCost: sql<number>`(select coalesce(avg((cost->>'estCostUsd')::numeric), 0)::float from ${projects})`,
    })
    .from(sql`(select 1) as t`);
  const total = counts.projects ?? 0;
  return {
    transformations: counts.transformations ?? 0,
    categories: new Set(TRANSFORMATIONS.map((t) => t.hookCategory)).size,
    projects: total,
    validated: counts.validated ?? 0,
    invalid: counts.invalid ?? 0,
    renders: counts.renders ?? 0,
    batches: counts.batches ?? 0,
    avgDurationMs: counts.avgDuration ?? 0,
    avgCostUsd: counts.avgCost ?? 0,
    validationPassRate:
      total === 0 ? 0 : Math.round(((counts.validated ?? 0) / total) * 1000) / 10,
  };
}

export async function listPerformance(limit = 20) {
  await ensureSeed();
  return db
    .select({
      metrics: performanceMetrics,
      projectId: projects.id,
      variant: projects.variant,
      seed: projects.seed,
      hook: transformations.hook,
      subject: transformations.subject,
      slug: transformations.slug,
      scores: transformations.scores,
    })
    .from(performanceMetrics)
    .innerJoin(projects, eq(performanceMetrics.projectId, projects.id))
    .innerJoin(transformations, eq(projects.transformationId, transformations.id))
    .orderBy(desc(performanceMetrics.views))
    .limit(limit);
}
