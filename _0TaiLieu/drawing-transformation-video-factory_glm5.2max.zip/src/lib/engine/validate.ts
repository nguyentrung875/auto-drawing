import {
  CANVAS,
  type DrawingPlan,
  type Timeline,
  type ValidationCheck,
  type ValidationIssue,
  type ValidationReport,
} from "./types";

const MARGIN = 8;

/**
 * Quality gate (FR-005 / FR-017). A project that fails here is never marked
 * production-ready, no matter how nice the plan looks.
 */
export function validateProject(
  plan: DrawingPlan,
  timeline: Timeline,
): ValidationReport {
  const errors: ValidationIssue[] = [];
  const warnings: ValidationIssue[] = [];
  const checks: ValidationCheck[] = [];

  const add = (
    id: string,
    label: string,
    pass: boolean,
    detail: string,
    error?: ValidationIssue,
  ) => {
    checks.push({ id, label, pass, detail });
    if (!pass && error) errors.push(error);
  };

  const strokeList = plan.steps.flatMap((s) => s.strokes);
  const stepIds = new Set(plan.steps.map((s) => s.id));

  add(
    "steps-minimum",
    "Ít nhất 3 drawing steps",
    plan.steps.length >= 3,
    `${plan.steps.length} steps`,
    { code: "E_STEPS_MIN", message: "Cần ít nhất 3 drawing steps." },
  );

  add(
    "step-geometry",
    "Mọi step đều có geometry",
    plan.steps.every((s) => s.strokes.length > 0),
    `${plan.steps.filter((s) => s.strokes.length > 0).length}/${plan.steps.length} steps có nét`,
    {
      code: "E_STEP_NO_GEOMETRY",
      message: "Có step không chứa geometry nào.",
      stepId: plan.steps.find((s) => s.strokes.length === 0)?.id,
    },
  );

  const badPaths = strokeList.filter(
    (s) => s.points.length < 2 || !Number.isFinite(s.length) || s.length <= 0,
  );
  add(
    "path-renderable",
    "Path render được",
    badPaths.length === 0,
    `${strokeList.length - badPaths.length}/${strokeList.length} nét hợp lệ`,
    {
      code: "E_PATH_UNRENDERABLE",
      message: `Có ${badPaths.length} nét không thể render.`,
      stepId: badPaths[0]?.stepId,
    },
  );

  const outOfCanvas = strokeList.filter((s) =>
    s.points.some(
      (p) =>
        !Number.isFinite(p.x) ||
        !Number.isFinite(p.y) ||
        p.x < -MARGIN ||
        p.y < -MARGIN ||
        p.x > CANVAS.width + MARGIN ||
        p.y > CANVAS.height + MARGIN,
    ),
  );
  add(
    "canvas-bounds",
    "Geometry nằm trong canvas",
    outOfCanvas.length === 0,
    outOfCanvas.length === 0
      ? "Toàn bộ nét nằm trong khung 1080×1920"
      : `${outOfCanvas.length} nét tràn canvas`,
    {
      code: "E_OUT_OF_CANVAS",
      message: "Có nét nằm ngoài canvas.",
      stepId: outOfCanvas[0]?.stepId,
    },
  );

  const uniqueIds = new Set<string>();
  let duplicate = false;
  for (const id of stepIds) {
    if (uniqueIds.has(id)) duplicate = true;
    uniqueIds.add(id);
  }
  add(
    "drawing-order",
    "Drawing order hợp lệ",
    !duplicate && plan.steps[0]?.kind === "glyph",
    `Step đầu là hook glyph: ${plan.steps[0]?.name ?? "-"}`,
    { code: "E_DRAW_ORDER", message: "Thứ tự nét vẽ không hợp lệ." },
  );

  const sameSource = plan.finalFrameStrokes === strokeList.length;
  add(
    "final-consistency",
    "Final drawing = tổng các nét đã vẽ",
    sameSource && plan.strokeCount === strokeList.length,
    `${strokeList.length} nét dùng chung nguồn geometry với animation`,
    {
      code: "E_FINAL_MISMATCH",
      message: "Final drawing không khớp với geometry đã vẽ.",
    },
  );

  const monotonic = strokeList.every(
    (s, i) =>
      s.endMs > s.startMs &&
      (i === 0 || s.startMs >= strokeList[i - 1].endMs - 1),
  );
  add(
    "pen-continuity",
    "Pen theo path, không teleport",
    monotonic,
    monotonic
      ? "Timeline nét vẽ đơn điệu, pen lift giữa các nét"
      : "Có nét bị chồng lấn thời gian",
    { code: "E_PEN_TELEPORT", message: "Pen không đi liên tục theo path." },
  );

  add(
    "duration-range",
    "Thời lượng 15–30s",
    timeline.totalMs >= 15000 && timeline.totalMs <= 30000,
    `${(timeline.totalMs / 1000).toFixed(1)}s`,
    { code: "E_DURATION", message: "Thời lượng video ngoài khoảng 15–30s." },
  );

  const missingVoice = plan.steps.filter((s) => !s.voiceLine);
  if (missingVoice.length > 0) {
    warnings.push({
      code: "W_VOICE_MISSING",
      message: `Có ${missingVoice.length} step chưa có voice line.`,
      stepId: missingVoice[0]?.id,
    });
  }
  add(
    "voice-coverage",
    "Voice phủ các bước vẽ",
    missingVoice.length === 0,
    `${plan.steps.length - missingVoice.length}/${plan.steps.length} steps có thoại`,
  );

  add(
    "registry-refs",
    "Component tồn tại trong registry",
    plan.components.length === 2 &&
      plan.components[0] === plan.glyphKey &&
      plan.components[1] === plan.subjectKey,
    plan.components.join(" + "),
    {
      code: "E_REGISTRY_MISS",
      message: "Concept tham chiếu component không có trong registry.",
      componentKey: plan.components.join(","),
    },
  );

  const inkOk = plan.inkLength > 500;
  add(
    "ink-density",
    "Mực đủ để vẽ",
    inkOk,
    `${Math.round(plan.inkLength)} px ink`,
  );

  return {
    pass: errors.length === 0,
    errors,
    warnings,
    checks,
    checkedAt: new Date().toISOString(),
    stepCount: plan.steps.length,
    strokeCount: strokeList.length,
    inkLength: Math.round(plan.inkLength),
  };
}
