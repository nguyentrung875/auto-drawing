import type { TransformationRecord } from "@/lib/library/transformations";
import { buildProject, estimateVoiceMs } from "./plan";
import { validateProject } from "./validate";
import type {
  DrawingPlan,
  GenerationCost,
  Timeline,
  ValidationReport,
  VoiceCue,
} from "./types";

export * from "./types";
export * from "./plan";
export * from "./validate";

export type GeneratedProject = {
  plan: DrawingPlan;
  timeline: Timeline;
  validation: ValidationReport;
  voiceCues: VoiceCue[];
  cost: GenerationCost;
  generationMs: number;
};

/**
 * Transformation -> Drawing Definition -> Validated Drawing.
 * Pure, deterministic and independent from any renderer (Decision 3).
 */
export function generateProject(
  transformation: TransformationRecord,
  options: { seed?: number | null; variant?: string; cta?: string } = {},
): GeneratedProject {
  const started = Date.now();
  const { plan, timeline } = buildProject(transformation, options);
  const validation = validateProject(plan, timeline);
  const voiceCues = timeline.voice;
  const voiceChars = voiceCues.reduce((acc, cue) => acc + cue.text.length, 0);
  const cost: GenerationCost = {
    renderMs: Date.now() - started,
    voiceChars,
    estCostUsd:
      Math.round(
        (0.0008 + (voiceChars / 1000) * 0.015 + timeline.frameCount * 0.000004) *
          100000,
      ) / 100000,
  };
  return { plan, timeline, validation, voiceCues, cost, generationMs: cost.renderMs };
}

export { estimateVoiceMs };
