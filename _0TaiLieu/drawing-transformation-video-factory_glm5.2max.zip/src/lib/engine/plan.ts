import {
  boundsOf,
  flattenPath,
  type Pt,
  type StrokeDef,
} from "@/lib/geometry/path";
import { getGlyph } from "@/lib/registry/glyphs";
import { getSubject } from "@/lib/registry/subjects";
import type { TransformationRecord } from "@/lib/library/transformations";
import { mulberry32, normalizeSeed } from "./rng";
import {
  CANVAS,
  FPS,
  getVariant,
  type DrawingPlan,
  type PlanStep,
  type PlanStroke,
  type SfxCue,
  type Timeline,
  type TimelineSegment,
  type VoiceCue,
} from "./types";

export const STAGE = {
  width: CANVAS.width,
  height: CANVAS.height,
  /** Region of the 1080x1920 frame where ink lives. */
  drawRect: { x: 96, y: 470, w: 888, h: 850 },
  targetMinMs: 15000,
  targetMaxMs: 30000,
  minDrawMs: 2600,
};

/** Pen lift between two strokes — reads as hand movement, not a teleport (Q4). */
export const PEN_LIFT_MS = 120;

const FLATTEN_RESOLUTION = 4;

type Flat = { points: Pt[]; length: number; width: number };

function flattenStrokes(strokes: StrokeDef[]): Flat[] {
  const out: Flat[] = [];
  for (const stroke of strokes) {
    const subs = flattenPath(stroke.d, FLATTEN_RESOLUTION);
    for (const sub of subs) {
      if (sub.points.length < 2) continue;
      out.push({ points: sub.points, length: sub.length, width: stroke.w });
    }
  }
  return out;
}

function estimateVoiceMs(text: string): number {
  return Math.max(900, Math.min(4200, 700 + text.length * 62));
}

function clamp(v: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, v));
}

export type BuildResult = {
  plan: DrawingPlan;
  timeline: Timeline;
};

export function buildProject(
  transformation: TransformationRecord,
  options: { seed?: number | null; variant?: string; cta?: string } = {},
): BuildResult {
  const seed = normalizeSeed(options.seed);
  const variant = getVariant(options.variant ?? "curious");
  const rng = mulberry32(seed);

  const glyph = getGlyph(transformation.glyphKey);
  const subject = getSubject(transformation.subjectKey);
  if (!glyph || !subject) {
    throw new Error(
      `Registry miss: ${!glyph ? transformation.glyphKey : transformation.subjectKey}`,
    );
  }

  const glyphFlats = flattenStrokes(glyph.strokes);
  const partFlats = subject.parts.map((p) => ({
    part: p,
    flats: flattenStrokes(p.strokes),
  }));

  const allPoints: Pt[][] = [
    ...glyphFlats.map((f) => f.points),
    ...partFlats.flatMap((p) => p.flats.map((f) => f.points)),
  ];
  const rawBounds = boundsOf(allPoints);
  const rawW = Math.max(1, rawBounds.maxX - rawBounds.minX);
  const rawH = Math.max(1, rawBounds.maxY - rawBounds.minY);
  const rect = STAGE.drawRect;
  const scale = Math.min(rect.w / rawW, rect.h / rawH);
  const offsetX = rect.x + (rect.w - rawW * scale) / 2 - rawBounds.minX * scale;
  const offsetY = rect.y + (rect.h - rawH * scale) / 2 - rawBounds.minY * scale;

  const toCanvas = (points: Pt[]): Pt[] =>
    points.map((p) => ({
      x: Math.round((p.x * scale + offsetX) * 100) / 100,
      y: Math.round((p.y * scale + offsetY) * 100) / 100,
    }));

  const steps: PlanStep[] = [];
  const pushStep = (
    id: string,
    name: string,
    componentKey: string,
    kind: "glyph" | "part",
    flats: Flat[],
    voiceLine: string | null,
  ) => {
    const strokes: PlanStroke[] = flats.map((f, index) => ({
      id: `${id}-s${index + 1}`,
      stepId: id,
      points: toCanvas(f.points),
      length: Math.round(f.length * scale * 100) / 100,
      width: Math.max(3, Math.round(f.width * scale * 10) / 10),
      startMs: 0,
      endMs: 0,
      liftMs: 0,
    }));
    steps.push({
      id,
      name,
      componentKey,
      kind,
      strokes,
      inkLength: strokes.reduce((acc, s) => acc + s.length, 0),
      durationMs: 0,
      pauseMs: 0,
      voiceLine,
      startMs: 0,
      endMs: 0,
    });
  };

  pushStep(
    "step-1",
    glyph.label,
    glyph.key,
    "glyph",
    glyphFlats,
    transformation.startVoice,
  );
  subject.parts.forEach((part, index) => {
    const flat = partFlats[index];
    pushStep(
      `step-${index + 2}`,
      part.name,
      subject.key,
      "part",
      flat.flats,
      part.voice ?? `Thêm ${part.name}.`,
    );
  });

  /* ------------------------------ timing ------------------------------ */
  const rawSegments = steps.map((step) => {
    const strokeCount = step.strokes.length;
    const drawMs =
      (step.inkLength / variant.speedPxPerSec) * 1000 +
      Math.max(0, strokeCount - 1) * PEN_LIFT_MS;
    const durationMs = clamp(drawMs, 480, 4200);
    const pauseMs = clamp(variant.pauseMs * (0.75 + rng() * 0.6), 110, 900);
    return { durationMs, pauseMs };
  });

  const fixedMs = variant.hookMs + variant.revealMs + variant.ctaMs;
  const rawTotal =
    fixedMs +
    rawSegments.reduce((acc, s) => acc + s.durationMs + s.pauseMs, 0);
  const target = clamp(rawTotal, STAGE.targetMinMs, STAGE.targetMaxMs);
  const drawBudget = Math.max(
    STAGE.minDrawMs,
    target - fixedMs,
  );
  const rawDrawTotal = rawSegments.reduce(
    (acc, s) => acc + s.durationMs + s.pauseMs,
    0,
  );
  const factor = drawBudget / rawDrawTotal;

  let cursor = variant.hookMs;
  const allStrokes: PlanStroke[] = [];
  steps.forEach((step, index) => {
    const scaled = {
      durationMs: Math.max(240, rawSegments[index].durationMs * factor),
      pauseMs: Math.max(80, rawSegments[index].pauseMs * factor),
    };
    step.durationMs = Math.round(scaled.durationMs);
    step.pauseMs = Math.round(scaled.pauseMs);
    step.startMs = Math.round(cursor);

    const liftTotal = Math.max(0, step.strokes.length - 1) * PEN_LIFT_MS;
    const drawable = Math.max(120, step.durationMs - liftTotal);
    let t = step.startMs;
    step.strokes.forEach((stroke, sIndex) => {
      const share =
        step.inkLength === 0
          ? 1 / step.strokes.length
          : stroke.length / step.inkLength;
      const dur = Math.max(60, drawable * share);
      stroke.startMs = Math.round(t);
      stroke.endMs = Math.round(t + dur);
      stroke.liftMs =
        sIndex < step.strokes.length - 1 ? PEN_LIFT_MS : 0;
      t = stroke.endMs + stroke.liftMs;
      allStrokes.push(stroke);
    });
    step.endMs = step.startMs + step.durationMs;
    cursor = step.startMs + step.durationMs + step.pauseMs;
  });

  const inkStartMs = variant.hookMs;
  const inkEndMs = steps[steps.length - 1]?.endMs ?? inkStartMs;
  const revealStart = cursor;
  const ctaStart = revealStart + variant.revealMs;
  let ctaMs = variant.ctaMs;
  let totalMs = ctaStart + ctaMs;
  // Rounding can leave the video a few ms short of the 15s floor — hold the
  // CTA card a beat longer instead of shipping a 14.9s video.
  const shortfall = STAGE.targetMinMs - totalMs;
  if (shortfall > 0) {
    ctaMs += shortfall;
    totalMs += shortfall;
  }

  const plan: DrawingPlan = {
    version: 1,
    seed,
    variant: variant.key,
    canvas: { width: CANVAS.width, height: CANVAS.height },
    hook: transformation.hook,
    hookLabel: transformation.hookLabel,
    subject: transformation.subject,
    subjectLabel: transformation.subjectLabel,
    glyphKey: glyph.key,
    subjectKey: subject.key,
    components: [glyph.key, subject.key],
    steps,
    inkLength: Math.round(allStrokes.reduce((acc, s) => acc + s.length, 0)),
    bounds: {
      minX: Math.round(rawBounds.minX * scale + offsetX),
      minY: Math.round(rawBounds.minY * scale + offsetY),
      maxX: Math.round(rawBounds.maxX * scale + offsetX),
      maxY: Math.round(rawBounds.maxY * scale + offsetY),
    },
    strokeCount: allStrokes.length,
    finalFrameStrokes: allStrokes.length,
  };

  /* ----------------------------- timeline ----------------------------- */
  const segments: TimelineSegment[] = [
    {
      kind: "hook",
      label: "Hook",
      startMs: 0,
      endMs: variant.hookMs,
      voiceLine: transformation.hookVoice,
    },
  ];
  steps.forEach((step) => {
    segments.push({
      kind: "draw",
      label: step.name,
      startMs: step.startMs,
      endMs: step.startMs + step.durationMs + step.pauseMs,
      stepId: step.id,
      voiceLine: step.voiceLine,
    });
  });
  segments.push({
    kind: "reveal",
    label: "Reveal",
    startMs: revealStart,
    endMs: ctaStart,
    voiceLine: transformation.revealVoice,
  });
  segments.push({
    kind: "cta",
    label: "CTA",
    startMs: ctaStart,
    endMs: totalMs,
    voiceLine: options.cta ?? transformation.cta,
  });

  const voice: VoiceCue[] = [
    {
      id: "voice-hook",
      text: transformation.hookVoice,
      startMs: 160,
      durationMs: Math.min(estimateVoiceMs(transformation.hookVoice), variant.hookMs),
      kind: "hook",
    },
  ];
  steps.forEach((step) => {
    if (!step.voiceLine) return;
    voice.push({
      id: `voice-${step.id}`,
      text: step.voiceLine,
      startMs: step.startMs + 90,
      durationMs: estimateVoiceMs(step.voiceLine),
      kind: "step",
    });
  });
  voice.push({
    id: "voice-reveal",
    text: transformation.revealVoice,
    startMs: revealStart + 220,
    durationMs: estimateVoiceMs(transformation.revealVoice),
    kind: "reveal",
  });
  const ctaText = options.cta ?? transformation.cta;
  voice.push({
    id: "voice-cta",
    text: ctaText,
    startMs: ctaStart + 140,
    durationMs: estimateVoiceMs(ctaText),
    kind: "cta",
  });

  const sfx: SfxCue[] = [
    { key: "sfx:hook-pop", label: "Hook pop", startMs: 0 },
    { key: "sfx:pen-down", label: "Pen down", startMs: inkStartMs },
    ...steps.map((step) => ({
      key: "sfx:stroke",
      label: `Stroke · ${step.name}`,
      startMs: step.startMs,
    })),
    { key: "sfx:reveal", label: "Reveal chime", startMs: revealStart },
    { key: "sfx:cta", label: "CTA tap", startMs: ctaStart },
  ];

  const timeline: Timeline = {
    fps: FPS,
    width: CANVAS.width,
    height: CANVAS.height,
    totalMs: Math.round(totalMs),
    frameCount: Math.ceil((totalMs / 1000) * FPS),
    hookMs: variant.hookMs,
    inkStartMs,
    inkEndMs,
    revealMs: variant.revealMs,
    ctaMs: Math.round(ctaMs),
    segments,
    voice,
    sfx,
    speedPxPerSec: Math.round(
      plan.inkLength / Math.max(0.001, (inkEndMs - inkStartMs) / 1000),
    ),
  };

  return { plan, timeline };
}

export { estimateVoiceMs };
