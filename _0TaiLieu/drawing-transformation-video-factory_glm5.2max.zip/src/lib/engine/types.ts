export type Pt = { x: number; y: number };

export type CanvasSpec = { width: number; height: number };

export const CANVAS: CanvasSpec = { width: 1080, height: 1920 };
export const FPS = 30;

export type PlanStroke = {
  id: string;
  stepId: string;
  points: Pt[];
  length: number;
  width: number;
  /** Absolute window (ms) in which this stroke is drawn — pen follows geometry. */
  startMs: number;
  endMs: number;
  /** Pen-lift pause (ms) after this stroke before the next one starts. */
  liftMs: number;
};

export type PlanStep = {
  id: string;
  name: string;
  componentKey: string;
  kind: "glyph" | "part";
  strokes: PlanStroke[];
  inkLength: number;
  durationMs: number;
  pauseMs: number;
  voiceLine: string | null;
  startMs: number;
  endMs: number;
};

export type DrawingPlan = {
  version: number;
  seed: number;
  variant: string;
  canvas: CanvasSpec;
  hook: string;
  hookLabel: string;
  subject: string;
  subjectLabel: string;
  glyphKey: string;
  subjectKey: string;
  components: string[];
  steps: PlanStep[];
  inkLength: number;
  bounds: { minX: number; minY: number; maxX: number; maxY: number };
  strokeCount: number;
  finalFrameStrokes: number;
};

export type ValidationIssue = {
  code: string;
  message: string;
  stepId?: string;
  componentKey?: string;
};

export type ValidationCheck = {
  id: string;
  label: string;
  pass: boolean;
  detail: string;
};

export type ValidationReport = {
  pass: boolean;
  errors: ValidationIssue[];
  warnings: ValidationIssue[];
  checks: ValidationCheck[];
  checkedAt: string;
  stepCount: number;
  strokeCount: number;
  inkLength: number;
};

export type VoiceCue = {
  id: string;
  text: string;
  startMs: number;
  durationMs: number;
  kind: "hook" | "step" | "reveal" | "cta";
};

export type SfxCue = {
  key: string;
  label: string;
  startMs: number;
};

export type TimelineSegment = {
  kind: "hook" | "draw" | "reveal" | "cta";
  label: string;
  startMs: number;
  endMs: number;
  stepId?: string;
  voiceLine?: string | null;
};

export type Timeline = {
  fps: number;
  width: number;
  height: number;
  totalMs: number;
  frameCount: number;
  hookMs: number;
  inkStartMs: number;
  inkEndMs: number;
  revealMs: number;
  ctaMs: number;
  segments: TimelineSegment[];
  voice: VoiceCue[];
  sfx: SfxCue[];
  speedPxPerSec: number;
};

export type VariantKey = "curious" | "challenge" | "direct";

export type VariantSpec = {
  key: VariantKey;
  label: string;
  description: string;
  hookMs: number;
  speedPxPerSec: number;
  pauseMs: number;
  revealMs: number;
  ctaMs: number;
  penWobble: number;
  hookTitle: string;
};

export const VARIANTS: VariantSpec[] = [
  {
    key: "curious",
    label: "Curious hook",
    description: "Hook dài, vẽ chậm, reveal muộn — tối ưu curiosity.",
    hookMs: 2600,
    speedPxPerSec: 780,
    pauseMs: 420,
    revealMs: 2400,
    ctaMs: 2800,
    penWobble: 1.4,
    hookTitle: "điều gì đang chờ?",
  },
  {
    key: "challenge",
    label: "Challenge hook",
    description: "Thử thách người xem đoán trước khi reveal.",
    hookMs: 2100,
    speedPxPerSec: 1050,
    pauseMs: 300,
    revealMs: 1900,
    ctaMs: 2300,
    penWobble: 1.1,
    hookTitle: "bạn đoán được không?",
  },
  {
    key: "direct",
    label: "Direct hook",
    description: "Vào thẳng, vẽ nhanh, CTA ngắn.",
    hookMs: 1600,
    speedPxPerSec: 1500,
    pauseMs: 200,
    revealMs: 1500,
    ctaMs: 1900,
    penWobble: 0.8,
    hookTitle: "xem tới cuối nhé",
  },
];

export function getVariant(key: string): VariantSpec {
  return VARIANTS.find((v) => v.key === key) ?? VARIANTS[0];
}

export type GenerationCost = {
  renderMs: number;
  voiceChars: number;
  estCostUsd: number;
};

export type TransformationScores = {
  curiosity: number;
  simplicity: number;
  feasibility: number;
  visual: number;
  retention: number;
  total: number;
};
