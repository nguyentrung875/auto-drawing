import { getGlyph } from "@/lib/registry/glyphs";
import { SUBJECTS, getSubject } from "@/lib/registry/subjects";
import type { TransformationScores } from "@/lib/engine/types";

export type TransformationRecord = {
  slug: string;
  hook: string;
  hookLabel: string;
  hookCategory: string;
  glyphKey: string;
  subject: string;
  subjectKey: string;
  subjectLabel: string;
  language: string;
  style: string;
  title: string;
  hookVoice: string;
  startVoice: string;
  revealVoice: string;
  cta: string;
  tags: string[];
  scores: TransformationScores;
  difficulty: number;
};

export const DEFAULT_CTA = "Xem thêm ở bio.";

type Overrides = {
  tags?: string[];
  revealVoice?: string;
  cta?: string;
  difficulty?: number;
  /** curiosity bonus */
  curiosity?: number;
};

const OVERRIDES: Record<string, Overrides> = {
  "subject:bear": { tags: ["classic", "animal", "viral-format"], difficulty: 1 },
  "subject:panda": { tags: ["animal", "cute"], difficulty: 1 },
  "subject:swan": { tags: ["animal", "elegant"], difficulty: 2 },
  "subject:butterfly": { tags: ["animal", "symmetry"], difficulty: 2 },
  "subject:whale": { tags: ["animal", "ocean"], difficulty: 2 },
  "subject:snail": { tags: ["animal", "slow-reveal"], difficulty: 2 },
  "subject:cat": { tags: ["animal", "pet"], difficulty: 1 },
  "subject:owl": { tags: ["animal", "night"], difficulty: 2 },
  "subject:rocket": { tags: ["object", "kids"], difficulty: 1 },
  "subject:heart": { tags: ["emotion", "love"], difficulty: 1 },
  "subject:sun": { tags: ["kawaii", "easy"], difficulty: 1 },
  "subject:mug": { tags: ["object", "cozy"], difficulty: 1 },
  "subject:mountains": { tags: ["scene", "landscape"], difficulty: 2 },
  "subject:magnifier": { tags: ["combination", "surprise"], difficulty: 2 },
};

function hookVoiceFor(hook: string, category: string): string {
  switch (category) {
    case "number":
      return `Số ${hook} này sẽ biến thành cái gì nhỉ?`;
    case "letter":
      return `Chữ ${hook} này sẽ biến thành gì?`;
    case "symbol":
      return `Ký hiệu ${hook} này sẽ biến thành gì?`;
    case "combination":
      return `${hook} sẽ biến thành gì đây?`;
    default:
      return `Một ${hook} đơn giản sẽ biến thành gì?`;
  }
}

function startVoiceFor(hookLabel: string): string {
  const lower = hookLabel.toLowerCase();
  return `Bắt đầu với ${lower}.`;
}

function clampScore(v: number): number {
  return Math.max(1, Math.min(10, Math.round(v)));
}

function scoreFor(
  subjectKey: string,
  category: string,
  partCount: number,
  strokeCount: number,
  override?: Overrides,
): TransformationScores {
  const curiosityBase =
    category === "number"
      ? 9
      : category === "letter"
        ? 8.4
        : category === "combination"
          ? 8.8
          : category === "symbol"
            ? 8
            : 7;
  const curiosity = clampScore(curiosityBase + (override?.curiosity ?? 0));
  const simplicity = clampScore(10 - (partCount - 4) * 0.7);
  const feasibility = clampScore(
    strokeCount < 14 ? 9.5 : strokeCount < 20 ? 8.5 : 7.2,
  );
  const visual = clampScore(
    Math.min(9.6, 5.4 + strokeCount * 0.22 + partCount * 0.15),
  );
  const retention = clampScore(
    curiosity * 0.4 + visual * 0.3 + simplicity * 0.3,
  );
  return {
    curiosity,
    simplicity,
    feasibility,
    visual,
    retention,
    total: Math.round(
      curiosity * 0.3 + simplicity * 0.15 + feasibility * 0.2 + visual * 0.15 + retention * 0.2,
    ),
  };
}

function buildRecord(subjectKey: string): TransformationRecord | null {
  const subject = getSubject(subjectKey);
  if (!subject) return null;
  const glyph = getGlyph(subject.glyphKey);
  if (!glyph) return null;
  const override = OVERRIDES[subjectKey] ?? {};
  const partCount = subject.parts.length;
  const strokeCount =
    glyph.strokes.length +
    subject.parts.reduce((acc, p) => acc + p.strokes.length, 0);
  const hookVoice = hookVoiceFor(glyph.hook, glyph.category);
  const startVoice = startVoiceFor(glyph.label);
  const revealVoice = override.revealVoice ?? `Đó là ${subject.label.toLowerCase()}!`;
  const cta = override.cta ?? DEFAULT_CTA;
  const hookLabel = glyph.label;
  return {
    slug: `${glyph.hook}-${subject.label}`
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-|-$/g, ""),
    hook: glyph.hook,
    hookLabel,
    hookCategory: glyph.category,
    glyphKey: glyph.key,
    subject: subject.label,
    subjectKey: subject.key,
    subjectLabel: subject.label,
    language: "vi",
    style: "cute_simple",
    title: `${glyph.hook} → ${subject.label}`,
    hookVoice,
    startVoice,
    revealVoice,
    cta,
    tags: override.tags ?? [glyph.category, "library"],
    scores: scoreFor(subjectKey, glyph.category, partCount, strokeCount, override),
    difficulty: override.difficulty ?? Math.max(1, Math.ceil(partCount / 3)),
  };
}

export const TRANSFORMATIONS: TransformationRecord[] = SUBJECTS.map((s) =>
  buildRecord(s.key),
).filter((r): r is TransformationRecord => r !== null);

export const TRANSFORMATION_MAP: Record<string, TransformationRecord> =
  Object.fromEntries(TRANSFORMATIONS.map((t) => [t.slug, t]));

export function getTransformation(slug: string): TransformationRecord | undefined {
  return TRANSFORMATION_MAP[slug];
}

export function findTransformationByInput(
  input: string,
): TransformationRecord | undefined {
  const raw = input.trim().toLowerCase();
  if (!raw) return undefined;
  const bySlug = TRANSFORMATION_MAP[raw];
  if (bySlug) return bySlug;
  const arrowSplit = raw.split(/\s*(?:->|→|=>)\s*/);
  if (arrowSplit.length === 2) {
    const [hook, subject] = arrowSplit;
    const hookMatch = TRANSFORMATIONS.find(
      (t) =>
        t.hook.toLowerCase() === hook.trim() &&
        (t.subject.toLowerCase() === subject.trim() ||
          t.subjectKey === `subject:${subject.trim()}`),
    );
    if (hookMatch) return hookMatch;
  }
  const bySubject = TRANSFORMATIONS.find(
    (t) =>
      t.subject.toLowerCase() === raw ||
      t.subjectKey === `subject:${raw}` ||
      t.slug.includes(raw),
  );
  if (bySubject) return bySubject;
  return TRANSFORMATIONS.find((t) => t.hook.toLowerCase() === raw);
}

export const CATEGORIES = [
  { key: "all", label: "Tất cả" },
  { key: "number", label: "Số 0–9" },
  { key: "letter", label: "Chữ A–Z" },
  { key: "symbol", label: "Ký hiệu" },
  { key: "geometry", label: "Hình học" },
  { key: "combination", label: "Kết hợp" },
];
