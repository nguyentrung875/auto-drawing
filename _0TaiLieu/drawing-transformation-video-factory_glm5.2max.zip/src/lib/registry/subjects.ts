import {
  arc,
  circle,
  ellipse,
  line,
  poly,
  wave,
  type StrokeDef,
} from "@/lib/geometry/path";

/**
 * Subject registry. A subject is always drawn ON TOP of a hook glyph and is
 * authored in the same coordinate space as that glyph, which is what makes
 * "hook -> progressive drawing -> reveal" a single continuous geometry
 * (FR-002, FR-006, FR-007).
 */
export type SubjectPart = {
  id: string;
  /** Vietnamese label used in the timeline UI. */
  name: string;
  voice?: string;
  strokes: StrokeDef[];
};

export type SubjectDef = {
  key: string;
  label: string;
  glyphKey: string;
  parts: SubjectPart[];
};

const W = 24;

const s = (d: string, w = W): StrokeDef => ({ d, w });
const dot = (cx: number, cy: number, r: number): StrokeDef => ({
  d: circle(cx, cy, r),
  w: r * 2.4,
});

export const SUBJECTS: SubjectDef[] = [
  /* ------------------------------- numbers ------------------------------ */
  {
    key: "subject:bear",
    label: "Gấu",
    glyphKey: "glyph:8",
    parts: [
      {
        id: "ears",
        name: "hai cái tai",
        voice: "Thêm hai cái tai tròn.",
        strokes: [s(circle(320, 175, 85)), s(circle(680, 175, 85))],
      },
      {
        id: "inner-ears",
        name: "lòng tai",
        strokes: [s(circle(320, 175, 40)), s(circle(680, 175, 40))],
      },
      {
        id: "eyes",
        name: "đôi mắt",
        voice: "Vẽ đôi mắt sáng.",
        strokes: [dot(428, 300, 20), dot(572, 300, 20)],
      },
      {
        id: "snout",
        name: "mõm",
        voice: "Thêm cái mõm to.",
        strokes: [s(ellipse(500, 410, 82, 64))],
      },
      {
        id: "nose",
        name: "mũi",
        strokes: [s(ellipse(500, 388, 34, 24), 40)],
      },
      {
        id: "mouth",
        name: "nụ cười",
        voice: "Vẽ nụ cười.",
        strokes: [s(arc(500, 428, 58, 48, 25, 155))],
      },
      {
        id: "arms",
        name: "hai cánh tay",
        voice: "Thêm hai cánh tay đang vẫy.",
        strokes: [s(arc(275, 660, 105, 175, 110, 250)), s(arc(725, 660, 105, 175, -70, 70))],
      },
      {
        id: "feet",
        name: "bàn chân",
        strokes: [s(ellipse(390, 895, 78, 48)), s(ellipse(610, 895, 78, 48))],
      },
    ],
  },
  {
    key: "subject:panda",
    label: "Gấu trúc",
    glyphKey: "glyph:0",
    parts: [
      {
        id: "ears",
        name: "hai cái tai",
        voice: "Thêm hai cái tai đen.",
        strokes: [s(circle(295, 205, 88)), s(circle(705, 205, 88))],
      },
      {
        id: "patches",
        name: "vùng mắt",
        voice: "Vẽ hai vùng mắt to.",
        strokes: [s(ellipse(395, 430, 72, 92)), s(ellipse(605, 430, 72, 92))],
      },
      {
        id: "eyes",
        name: "đôi mắt",
        strokes: [dot(395, 430, 22), dot(605, 430, 22)],
      },
      {
        id: "nose",
        name: "mũi",
        strokes: [s(ellipse(500, 590, 46, 34), 40)],
      },
      {
        id: "mouth",
        name: "miệng",
        voice: "Thêm nụ cười hiền.",
        strokes: [s(arc(500, 618, 58, 48, 20, 160))],
      },
      {
        id: "arms",
        name: "hai tay",
        voice: "Vẽ hai tay ôm bụng.",
        strokes: [s(arc(255, 615, 105, 165, 115, 245)), s(arc(745, 615, 105, 165, -65, 65))],
      },
    ],
  },
  {
    key: "subject:rocket",
    label: "Tên lửa",
    glyphKey: "glyph:1",
    parts: [
      {
        id: "body",
        name: "thân tên lửa",
        voice: "Nối thành thân tên lửa.",
        strokes: [
          s(poly([[510, 195], [625, 345], [625, 690], [395, 690], [395, 345], [510, 195]])),
        ],
      },
      {
        id: "fin",
        name: "cánh bên phải",
        voice: "Thêm cánh tên lửa.",
        strokes: [s(line(680, 310, 510, 195))],
      },
      {
        id: "window",
        name: "ô cửa sổ",
        voice: "Vẽ ô cửa sổ tròn.",
        strokes: [s(circle(510, 430, 62)), s(circle(510, 430, 34))],
      },
      {
        id: "flame",
        name: "ngọn lửa",
        voice: "Bùng cháy!",
        strokes: [
          s(poly([[440, 690], [510, 910], [580, 690]])),
          s(poly([[475, 690], [510, 790], [545, 690]]), 20),
        ],
      },
      {
        id: "stars",
        name: "những ngôi sao",
        voice: "Thêm vài ngôi sao.",
        strokes: [
          s(line(200, 250, 200, 300), 18),
          s(line(175, 275, 225, 275), 18),
          s(line(820, 380, 820, 430), 18),
          s(line(795, 405, 845, 405), 18),
        ],
      },
    ],
  },
  {
    key: "subject:swan",
    label: "Thiên nga",
    glyphKey: "glyph:2",
    parts: [
      {
        id: "head",
        name: "đầu thiên nga",
        voice: "Uốn thành cái đầu.",
        strokes: [s(circle(748, 320, 62))],
      },
      {
        id: "beak",
        name: "mỏ",
        voice: "Thêm cái mỏ nhọn.",
        strokes: [s(poly([[803, 318], [892, 298], [805, 352]]))],
      },
      {
        id: "eye",
        name: "mắt",
        strokes: [dot(765, 302, 15)],
      },
      {
        id: "wing",
        name: "cánh",
        voice: "Vẽ cái cánh.",
        strokes: [
          s(arc(470, 610, 195, 120, 180, 360)),
          s(arc(470, 610, 125, 70, 180, 360)),
        ],
      },
      {
        id: "water",
        name: "mặt nước",
        voice: "Thả xuống mặt nước.",
        strokes: [s(wave(150, 880, 900, 880, 24, 3))],
      },
    ],
  },
  {
    key: "subject:camel",
    label: "Lạc đà",
    glyphKey: "glyph:3",
    parts: [
      {
        id: "neck",
        name: "cổ",
        voice: "Kéo dài cái cổ lên.",
        strokes: [s("M 655 330 C 740 300 780 260 790 190")],
      },
      {
        id: "head",
        name: "đầu",
        voice: "Vẽ cái đầu.",
        strokes: [s(ellipse(820, 165, 85, 60))],
      },
      {
        id: "eye",
        name: "mắt",
        strokes: [dot(845, 150, 13)],
      },
      {
        id: "legs",
        name: "bốn cái chân",
        voice: "Thêm bốn cái chân.",
        strokes: [
          s(line(340, 690, 340, 940)),
          s(line(430, 760, 430, 940)),
          s(line(560, 760, 560, 940)),
          s(line(640, 700, 640, 940)),
        ],
      },
      {
        id: "tail",
        name: "đuôi",
        strokes: [s("M 300 700 C 250 730 230 770 240 800", 18),
        ],
      },
      {
        id: "ground",
        name: "bãi cát",
        voice: "Đặt chân lên bãi cát.",
        strokes: [s(line(180, 950, 880, 950))],
      },
    ],
  },
  {
    key: "subject:sailboat",
    label: "Thuyền buồm",
    glyphKey: "glyph:4",
    parts: [
      {
        id: "sail",
        name: "cánh buồm",
        voice: "Nối thành cánh buồm.",
        strokes: [s(poly([[660, 200], [660, 630], [280, 630]]))],
      },
      {
        id: "hull",
        name: "thân thuyền",
        voice: "Vẽ thân thuyền.",
        strokes: [s(poly([[190, 650], [800, 650], [700, 800], [290, 800], [190, 650]]))],
      },
      {
        id: "flag",
        name: "lá cờ",
        strokes: [s(poly([[660, 200], [760, 230], [660, 260]]))],
      },
      {
        id: "water",
        name: "sóng nước",
        voice: "Thả thuyền xuống nước.",
        strokes: [s(wave(120, 880, 900, 880, 28, 3))],
      },
      {
        id: "sun",
        name: "mặt trời",
        strokes: [s(circle(880, 180, 80)), dot(880, 180, 16)],
      },
    ],
  },
  {
    key: "subject:hen",
    label: "Gà mẹ",
    glyphKey: "glyph:5",
    parts: [
      {
        id: "head",
        name: "cái đầu",
        voice: "Vòng tròn thành cái đầu.",
        strokes: [s(circle(700, 290, 105))],
      },
      {
        id: "comb",
        name: "mào gà",
        voice: "Thêm cái mào đỏ.",
        strokes: [s(poly([[660, 195], [680, 118], [722, 186], [752, 108], [782, 188]]))],
      },
      {
        id: "beak",
        name: "mỏ",
        strokes: [s(poly([[800, 292], [882, 272], [802, 325]]))],
      },
      {
        id: "eye",
        name: "mắt",
        strokes: [dot(700, 268, 15)],
      },
      {
        id: "wing",
        name: "cánh",
        voice: "Vẽ cái cánh.",
        strokes: [s(ellipse(470, 505, 120, 88))],
      },
      {
        id: "legs",
        name: "hai chân",
        voice: "Thêm hai cái chân.",
        strokes: [
          s(line(420, 720, 420, 870)),
          s(line(370, 870, 470, 870)),
          s(line(540, 720, 540, 870)),
          s(line(490, 870, 590, 870)),
        ],
      },
      {
        id: "ground",
        name: "mặt đất",
        strokes: [s(line(250, 890, 870, 890))],
      },
    ],
  },
  {
    key: "subject:mouse",
    label: "Chuột",
    glyphKey: "glyph:6",
    parts: [
      {
        id: "ear",
        name: "tai",
        voice: "Thêm cái tai to.",
        strokes: [s(circle(740, 270, 108)), s(circle(740, 270, 58), 18)],
      },
      {
        id: "eye",
        name: "mắt",
        strokes: [dot(620, 470, 18)],
      },
      {
        id: "nose",
        name: "mũi",
        voice: "Chấm cái mũi nhọn.",
        strokes: [dot(655, 205, 24)],
      },
      {
        id: "whiskers",
        name: "râu",
        voice: "Vẽ vài sợi râu.",
        strokes: [
          s(line(700, 215, 840, 185), 14),
          s(line(700, 235, 845, 250), 14),
        ],
      },
      {
        id: "feet",
        name: "bàn chân",
        strokes: [s(ellipse(520, 885, 62, 36)), s(ellipse(640, 885, 62, 36))],
      },
    ],
  },
  {
    key: "subject:shark",
    label: "Cá mập",
    glyphKey: "glyph:7",
    parts: [
      {
        id: "body",
        name: "thân cá mập",
        voice: "Nối thành thân cá mập.",
        strokes: [s("M 715 250 C 820 430 700 720 470 815 C 300 700 250 430 300 250")],
      },
      {
        id: "fin",
        name: "vây lưng",
        voice: "Đứng lên một cái vây.",
        strokes: [s(poly([[520, 250], [565, 118], [645, 250]]))],
      },
      {
        id: "tail",
        name: "đuôi",
        voice: "Vẽ cái đuôi.",
        strokes: [s(poly([[470, 815], [368, 908], [505, 945]]))],
      },
      {
        id: "eye",
        name: "mắt",
        strokes: [dot(625, 385, 23)],
      },
      {
        id: "teeth",
        name: "răng",
        voice: "Răng chắc khoẻ!",
        strokes: [
          s(poly([[700, 470], [662, 505], [630, 470], [596, 505], [566, 470]]), 16),
        ],
      },
      {
        id: "bubbles",
        name: "bong bóng",
        strokes: [s(circle(830, 170, 24), 16), s(circle(880, 110, 15), 14)],
      },
    ],
  },
  {
    key: "subject:whale",
    label: "Cá voi",
    glyphKey: "glyph:9",
    parts: [
      {
        id: "tail",
        name: "đuôi cá voi",
        voice: "Bẹt ra thành cái đuôi.",
        strokes: [s(poly([[470, 790], [355, 900], [520, 882], [565, 962], [645, 858]]))],
      },
      {
        id: "eye",
        name: "mắt",
        strokes: [dot(392, 302, 22)],
      },
      {
        id: "mouth",
        name: "miệng",
        voice: "Vẽ nụ cười to.",
        strokes: [s(arc(430, 435, 122, 82, 25, 120))],
      },
      {
        id: "fin",
        name: "vây",
        voice: "Thêm cái vây.",
        strokes: [s(poly([[520, 560], [615, 655], [520, 665]]))],
      },
      {
        id: "spout",
        name: "phun nước",
        voice: "Phun nước lên trời!",
        strokes: [
          s("M 500 152 C 480 92 420 82 380 58", 18),
          s("M 512 152 C 532 92 592 82 632 58", 18),
        ],
      },
      {
        id: "bubbles",
        name: "bong bóng",
        strokes: [s(circle(770, 175, 26), 16), s(circle(830, 105, 16), 14)],
      },
    ],
  },

  /* ------------------------------- letters ------------------------------ */
  {
    key: "subject:tent",
    label: "Lều cắm trại",
    glyphKey: "glyph:A",
    parts: [
      {
        id: "door",
        name: "cửa lều",
        voice: "Mở cái cửa lều.",
        strokes: [s(poly([[500, 430], [590, 815], [410, 815], [500, 430]]))],
      },
      {
        id: "ground",
        name: "mặt đất",
        voice: "Đặt lều trên đất.",
        strokes: [s(line(120, 815, 900, 815))],
      },
      {
        id: "flag",
        name: "lá cờ",
        strokes: [
          s(line(500, 190, 500, 110)),
          s(poly([[500, 110], [610, 140], [500, 172]])),
        ],
      },
      {
        id: "stars",
        name: "trời đêm",
        voice: "Thêm sao trên trời.",
        strokes: [
          s(line(180, 250, 180, 300), 18),
          s(line(155, 275, 205, 275), 18),
          s(line(820, 320, 820, 370), 18),
          s(line(795, 345, 845, 345), 18),
        ],
      },
    ],
  },
  {
    key: "subject:butterfly",
    label: "Bươm bướm",
    glyphKey: "glyph:B",
    parts: [
      {
        id: "left-wing",
        name: "cánh trái",
        voice: "Thêm cánh bên trái.",
        strokes: [
          s("M 330 190 C 0 200 0 450 330 455"),
          s("M 330 455 C 0 465 0 805 330 815"),
        ],
      },
      {
        id: "body",
        name: "thân",
        voice: "Nắn lại cái thân.",
        strokes: [s(ellipse(330, 505, 30, 330))],
      },
      {
        id: "antennae",
        name: "râu",
        voice: "Vẽ hai cái râu.",
        strokes: [
          s("M 315 180 C 275 110 215 88 175 88", 16),
          s("M 345 180 C 385 110 445 88 485 88", 16),
        ],
      },
      {
        id: "dots",
        name: "chấm trên cánh",
        strokes: [dot(150, 320, 26), dot(150, 635, 26), dot(510, 320, 26), dot(510, 635, 26)],
      },
    ],
  },
  {
    key: "subject:moon",
    label: "Mặt trăng",
    glyphKey: "glyph:C",
    parts: [
      {
        id: "eye",
        name: "mắt",
        voice: "Mắt nhắm lại nhé.",
        strokes: [s(arc(430, 430, 60, 40, 200, 340))],
      },
      {
        id: "mouth",
        name: "nụ cười",
        voice: "Nụ cười dịu dàng.",
        strokes: [s(arc(420, 600, 70, 50, 20, 160))],
      },
      {
        id: "craters",
        name: "hố thiên thạch",
        strokes: [s(circle(600, 620, 45), 18), s(circle(660, 480, 28), 16)],
      },
      {
        id: "stars",
        name: "những ngôi sao",
        voice: "Rắc vài ngôi sao.",
        strokes: [
          s(line(820, 250, 820, 320), 18),
          s(line(790, 285, 850, 285), 18),
          s(line(900, 520, 900, 580), 18),
          s(line(872, 550, 928, 550), 18),
        ],
      },
      {
        id: "cloud",
        name: "đám mây",
        voice: "Một đám mây trôi qua.",
        strokes: [s(arc(180, 800, 130, 60, 180, 360))],
      },
    ],
  },
  {
    key: "subject:fish",
    label: "Cá",
    glyphKey: "glyph:D",
    parts: [
      {
        id: "tail",
        name: "đuôi cá",
        voice: "Đập đuôi lên nào.",
        strokes: [s(poly([[340, 440], [148, 336], [192, 612], [340, 680]]))],
      },
      {
        id: "eye",
        name: "mắt",
        strokes: [dot(590, 375, 24)],
      },
      {
        id: "mouth",
        name: "miệng",
        strokes: [s(arc(690, 590, 60, 40, 195, 335))],
      },
      {
        id: "fin",
        name: "vây lưng",
        voice: "Thêm cái vây.",
        strokes: [s(poly([[520, 470], [560, 325], [645, 470]]))],
      },
      {
        id: "scales",
        name: "vảy cá",
        strokes: [
          s(arc(470, 560, 55, 40, 180, 360), 16),
          s(arc(580, 600, 55, 40, 180, 360), 16),
        ],
      },
      {
        id: "bubbles",
        name: "bong bóng",
        strokes: [s(circle(790, 250, 26), 16), s(circle(850, 180, 17), 14)],
      },
    ],
  },
  {
    key: "subject:mountains",
    label: "Núi tuyết",
    glyphKey: "glyph:M",
    parts: [
      {
        id: "snow-left",
        name: "tuyết đỉnh trái",
        voice: "Phủ tuyết lên đỉnh núi.",
        strokes: [
          s(poly([[160, 262], [240, 250], [310, 335], [265, 302], [222, 352], [182, 305], [160, 262]]), 18),
        ],
      },
      {
        id: "snow-right",
        name: "tuyết đỉnh phải",
        strokes: [
          s(poly([[840, 262], [760, 250], [690, 335], [735, 302], [778, 352], [818, 305], [840, 262]]), 18),
        ],
      },
      {
        id: "sun",
        name: "mặt trời",
        strokes: [s(circle(840, 170, 82)), dot(840, 170, 18)],
      },
      {
        id: "trees",
        name: "rừng thông",
        voice: "Trồng vài cây thông.",
        strokes: [
          s(poly([[140, 815], [185, 690], [230, 815]])),
          s(poly([[770, 815], [815, 690], [860, 815]])),
        ],
      },
      {
        id: "birds",
        name: "chim bay",
        strokes: [
          s(arc(330, 260, 45, 30, 195, 345), 14),
          s(arc(450, 210, 45, 30, 195, 345), 14),
        ],
      },
    ],
  },
  {
    key: "subject:owl",
    label: "Cú mèo",
    glyphKey: "glyph:O",
    parts: [
      {
        id: "tufts",
        name: "bộ lông tai",
        voice: "Thêm hai chùm lông tai.",
        strokes: [
          s(poly([[305, 245], [272, 118], [385, 192]])),
          s(poly([[695, 245], [728, 118], [615, 192]])),
        ],
      },
      {
        id: "eyes",
        name: "đôi mắt to",
        voice: "Đôi mắt to tròn.",
        strokes: [s(circle(400, 430, 86)), s(circle(600, 430, 86))],
      },
      {
        id: "pupils",
        name: "con ngươi",
        strokes: [dot(400, 430, 30), dot(600, 430, 30)],
      },
      {
        id: "beak",
        name: "mỏ",
        strokes: [s(poly([[500, 505], [542, 565], [500, 625], [458, 565], [500, 505]]))],
      },
      {
        id: "wings",
        name: "cánh",
        voice: "Vẽ hai cánh.",
        strokes: [
          s(arc(230, 560, 100, 190, 110, 250)),
          s(arc(770, 560, 100, 190, -70, 70)),
        ],
      },
      {
        id: "branch",
        name: "cành cây",
        voice: "Đậu lên cành cây.",
        strokes: [s(line(140, 880, 900, 880)), s(line(240, 880, 200, 940), 16), s(line(780, 880, 820, 940), 16)],
      },
    ],
  },
  {
    key: "subject:cat",
    label: "Mèo",
    glyphKey: "glyph:Q",
    parts: [
      {
        id: "ears",
        name: "hai cái tai",
        voice: "Thêm hai cái tai nhọn.",
        strokes: [
          s(poly([[332, 332], [300, 140], [472, 256]])),
          s(poly([[668, 332], [700, 140], [528, 256]])),
        ],
      },
      {
        id: "eyes",
        name: "đôi mắt",
        strokes: [dot(410, 440, 20), dot(590, 440, 20)],
      },
      {
        id: "nose",
        name: "mũi",
        strokes: [s(poly([[484, 528], [516, 528], [500, 556], [484, 528]]), 20)],
      },
      {
        id: "mouth",
        name: "miệng",
        voice: "Meo meo!",
        strokes: [
          s(arc(455, 580, 45, 38, 190, 350), 16),
          s(arc(545, 580, 45, 38, 190, 350), 16),
        ],
      },
      {
        id: "whiskers",
        name: "râu",
        voice: "Vẽ bộ râu.",
        strokes: [
          s(line(300, 520, 130, 480), 12),
          s(line(300, 560, 130, 560), 12),
          s(line(700, 520, 870, 480), 12),
          s(line(700, 560, 870, 560), 12),
        ],
      },
    ],
  },
  {
    key: "subject:snake",
    label: "Con rắn",
    glyphKey: "glyph:S",
    parts: [
      {
        id: "head",
        name: "đầu rắn",
        voice: "Nâng lên thành cái đầu.",
        strokes: [s(ellipse(735, 282, 82, 58))],
      },
      {
        id: "eye",
        name: "mắt",
        strokes: [dot(750, 265, 14)],
      },
      {
        id: "tongue",
        name: "lưỡi",
        voice: "Thè cái lưỡi ra.",
        strokes: [s(poly([[810, 300], [890, 282], [918, 306], [890, 326]]), 14)],
      },
      {
        id: "tail",
        name: "đuôi",
        voice: "Cuộn cái đuôi.",
        strokes: [s(arc(285, 780, 70, 70, 90, 400))],
      },
      {
        id: "spots",
        name: "vảy",
        strokes: [dot(500, 500, 20), dot(400, 420, 16), dot(600, 640, 16)],
      },
    ],
  },
  {
    key: "subject:mushroom",
    label: "Cây nấm",
    glyphKey: "glyph:T",
    parts: [
      {
        id: "cap",
        name: "mũ nấm",
        voice: "Phình to thành mũ nấm.",
        strokes: [s(arc(500, 240, 360, 215, 180, 360))],
      },
      {
        id: "spots",
        name: "chấm nấm",
        voice: "Thêm vài chấm trắng.",
        strokes: [
          s(circle(380, 150, 42), 18),
          s(circle(560, 112, 32), 16),
          s(circle(650, 195, 26), 14),
        ],
      },
      {
        id: "stem",
        name: "thân nấm",
        strokes: [s(line(410, 240, 410, 792)), s(line(590, 240, 590, 792))],
      },
      {
        id: "grass",
        name: "bãi cỏ",
        voice: "Mọc lên từ bãi cỏ.",
        strokes: [
          s(line(180, 815, 880, 815)),
          s(line(280, 815, 260, 900), 14),
          s(line(720, 815, 740, 900), 14),
        ],
      },
    ],
  },
  {
    key: "subject:mug",
    label: "Cốc cà phê",
    glyphKey: "glyph:U",
    parts: [
      {
        id: "handle",
        name: "quai cốc",
        voice: "Gắn cái quai vào.",
        strokes: [s("M 700 380 C 890 385 890 645 700 620")],
      },
      {
        id: "coffee",
        name: "cà phê",
        voice: "Đổ cà phê vào.",
        strokes: [s("M 312 300 C 420 350 580 350 688 300", 18)],
      },
      {
        id: "steam",
        name: "hơi nóng",
        voice: "Hơi nóng bốc lên.",
        strokes: [
          s("M 420 170 C 398 118 442 96 420 40", 16),
          s("M 580 170 C 558 118 602 96 580 40", 16),
        ],
      },
      {
        id: "saucer",
        name: "đĩa lót",
        strokes: [s(line(200, 860, 800, 860)), s(arc(500, 860, 300, 60, 0, 180), 16)],
      },
    ],
  },
  {
    key: "subject:heart",
    label: "Trái tim",
    glyphKey: "glyph:V",
    parts: [
      {
        id: "left-lobe",
        name: "nửa trái",
        voice: "Vòng lên nửa trái.",
        strokes: [s(circle(365, 340, 152))],
      },
      {
        id: "right-lobe",
        name: "nửa phải",
        voice: "Và nửa phải.",
        strokes: [s(circle(635, 340, 152))],
      },
      {
        id: "shine",
        name: "ánh sáng",
        strokes: [s(arc(340, 330, 80, 80, 200, 320), 16)],
      },
      {
        id: "sparks",
        name: "tia lấp lánh",
        voice: "Lấp lánh lên nào!",
        strokes: [
          s(line(180, 620, 180, 700), 18),
          s(line(140, 660, 220, 660), 18),
          s(line(860, 500, 860, 580), 18),
          s(line(820, 540, 900, 540), 18),
        ],
      },
    ],
  },
  {
    key: "subject:tree",
    label: "Cây táo",
    glyphKey: "glyph:Y",
    parts: [
      {
        id: "crown",
        name: "tán lá",
        voice: "Xòe ra thành tán lá.",
        strokes: [s(circle(500, 330, 268))],
      },
      {
        id: "trunk",
        name: "thân cây",
        voice: "Dày thêm cái thân.",
        strokes: [s(line(440, 560, 430, 838)), s(line(560, 560, 570, 838))],
      },
      {
        id: "apples",
        name: "quả táo",
        voice: "Thêm mấy quả táo đỏ.",
        strokes: [dot(398, 300, 30), dot(610, 250, 30), dot(520, 420, 30)],
      },
      {
        id: "ground",
        name: "mặt đất",
        strokes: [s(line(180, 860, 880, 860))],
      },
      {
        id: "grass",
        name: "bãi cỏ",
        strokes: [
          s(line(250, 860, 230, 930), 14),
          s(line(760, 860, 780, 930), 14),
        ],
      },
    ],
  },

  /* ------------------------------- symbols ------------------------------ */
  {
    key: "subject:snail",
    label: "Ốc sên",
    glyphKey: "glyph:@",
    parts: [
      {
        id: "body",
        name: "thân ốc",
        voice: "Kéo dài cái thân ra.",
        strokes: [s("M 940 700 C 900 800 700 840 300 840")],
      },
      {
        id: "head",
        name: "cái đầu",
        voice: "Nâng đầu lên.",
        strokes: [s(circle(250, 760, 62))],
      },
      {
        id: "antennae",
        name: "hai cái râu",
        voice: "Thêm hai cái râu.",
        strokes: [
          s(line(230, 706, 196, 610), 16),
          s(line(272, 706, 310, 612), 16),
        ],
      },
      {
        id: "eye",
        name: "mắt",
        strokes: [dot(235, 748, 15)],
      },
      {
        id: "slime",
        name: "vệt bò",
        voice: "Bò chậm thôi.",
        strokes: [s(wave(120, 920, 900, 920, 16, 3), 14)],
      },
    ],
  },
  {
    key: "subject:flower",
    label: "Bông hoa",
    glyphKey: "glyph:plus",
    parts: [
      {
        id: "petals",
        name: "bốn cánh hoa",
        voice: "Nở ra bốn cánh hoa.",
        strokes: [
          s(ellipse(500, 302, 132, 108)),
          s(ellipse(500, 698, 132, 108)),
          s(ellipse(302, 500, 108, 132)),
          s(ellipse(698, 500, 108, 132)),
        ],
      },
      {
        id: "center",
        name: "nhị hoa",
        strokes: [s(circle(500, 500, 88)), dot(500, 500, 22)],
      },
      {
        id: "stem",
        name: "cành hoa",
        voice: "Cắm xuống cành.",
        strokes: [s(line(500, 810, 500, 960))],
      },
      {
        id: "leaves",
        name: "hai chiếc lá",
        voice: "Thêm hai chiếc lá.",
        strokes: [
          s(ellipse(380, 890, 105, 48)),
          s(ellipse(620, 900, 105, 48)),
        ],
      },
    ],
  },
  {
    key: "subject:bow",
    label: "Chiếc nơ",
    glyphKey: "glyph:cross",
    parts: [
      {
        id: "left-loop",
        name: "nơ trái",
        voice: "Thắt một bên nơ.",
        strokes: [s("M 472 478 C 300 350 128 380 150 500 C 128 620 300 650 472 522")],
      },
      {
        id: "right-loop",
        name: "nơ phải",
        voice: "Và bên kia.",
        strokes: [s("M 528 478 C 700 350 872 380 850 500 C 872 620 700 650 528 522")],
      },
      {
        id: "knot",
        name: "nút thắt",
        strokes: [s(circle(500, 500, 62))],
      },
      {
        id: "tails",
        name: "dải nơ",
        voice: "Thả hai dải nơ xuống.",
        strokes: [
          s(poly([[468, 548], [400, 700], [452, 700]])),
          s(poly([[532, 548], [600, 700], [548, 700]])),
        ],
      },
    ],
  },
  {
    key: "subject:waffle",
    label: "Bánh waffle",
    glyphKey: "glyph:hash",
    parts: [
      {
        id: "border",
        name: "viền bánh",
        voice: "Nướng vàng viền bánh.",
        strokes: [s(poly([[240, 240], [760, 240], [760, 760], [240, 760], [240, 240]]))],
      },
      {
        id: "butter",
        name: "cục bơ",
        voice: "Thả một cục bơ.",
        strokes: [s(poly([[440, 440], [566, 440], [566, 566], [440, 566], [440, 440]]))],
      },
      {
        id: "syrup",
        name: "mật ong",
        voice: "Rưới mật ong nóng.",
        strokes: [
          s("M 260 780 C 300 850 340 800 380 880 C 420 800 470 890 510 820 C 550 900 600 810 640 880 C 680 810 720 850 740 780"),
        ],
      },
      {
        id: "berries",
        name: "quả mâm xôi",
        strokes: [dot(320, 340, 26), dot(690, 330, 26), dot(310, 690, 26), dot(690, 690, 26)],
      },
    ],
  },

  /* ------------------------------ geometry ------------------------------ */
  {
    key: "subject:sun",
    label: "Mặt trời",
    glyphKey: "glyph:circle",
    parts: [
      {
        id: "rays",
        name: "tia nắng",
        voice: "Tỏa những tia nắng.",
        strokes: [
          s(line(840, 500, 960, 500), 22),
          s(line(120, 500, 240, 500), 22),
          s(line(500, 840, 500, 960), 22),
          s(line(500, 40, 500, 160), 22),
          s(line(740, 740, 826, 826), 22),
          s(line(174, 174, 260, 260), 22),
          s(line(740, 260, 826, 174), 22),
          s(line(174, 826, 260, 740), 22),
        ],
      },
      {
        id: "eyes",
        name: "đôi mắt",
        voice: "Vẽ đôi mắt tỉnh táo.",
        strokes: [dot(420, 450, 22), dot(580, 450, 22)],
      },
      {
        id: "smile",
        name: "nụ cười",
        voice: "Cười lên nào!",
        strokes: [s(arc(500, 570, 110, 82, 25, 155))],
      },
      {
        id: "blush",
        name: "má hồng",
        strokes: [
          s(arc(340, 560, 60, 40, 180, 360), 14),
          s(arc(660, 560, 60, 40, 180, 360), 14),
        ],
      },
    ],
  },
  {
    key: "subject:partyhat",
    label: "Mũ tiệc",
    glyphKey: "glyph:triangle",
    parts: [
      {
        id: "pompom",
        name: "quả cầu lông",
        voice: "Gắn quả cầu ở đỉnh.",
        strokes: [s(circle(500, 178, 58))],
      },
      {
        id: "stripes",
        name: "sọc mũ",
        voice: "Kẻ vài sọc màu.",
        strokes: [
          s(line(318, 480, 682, 480), 18),
          s(line(382, 640, 618, 640), 18),
          s(line(440, 730, 560, 730), 18),
        ],
      },
      {
        id: "dots",
        name: "chấm bi",
        strokes: [dot(400, 560, 18), dot(580, 560, 18), dot(500, 400, 18)],
      },
      {
        id: "confetti",
        name: "pháo giấy",
        voice: "Bắn pháo giấy lên!",
        strokes: [
          s(line(120, 300, 120, 360), 16),
          s(line(90, 330, 150, 330), 16),
          s(line(880, 350, 880, 410), 16),
          s(line(850, 380, 910, 380), 16),
        ],
      },
    ],
  },
  {
    key: "subject:robot",
    label: "Robot",
    glyphKey: "glyph:square",
    parts: [
      {
        id: "antenna",
        name: "ăng-ten",
        voice: "Cắm ăng-ten lên đầu.",
        strokes: [s(line(500, 225, 500, 120)), s(circle(500, 92, 34))],
      },
      {
        id: "eyes",
        name: "đôi mắt",
        voice: "Bật đôi mắt lên.",
        strokes: [s(circle(400, 430, 62)), s(circle(600, 430, 62)), dot(400, 430, 22), dot(600, 430, 22)],
      },
      {
        id: "mouth",
        name: "miệng",
        voice: "Nói vài tiếng bíp bíp.",
        strokes: [
          s(line(380, 620, 620, 620)),
          s(line(420, 600, 420, 640), 14),
          s(line(500, 600, 500, 640), 14),
          s(line(580, 600, 580, 640), 14),
        ],
      },
      {
        id: "ears",
        name: "hai bên tai",
        strokes: [
          s(line(225, 430, 148, 430)),
          s(line(148, 388, 148, 472)),
          s(line(775, 430, 852, 430)),
          s(line(852, 388, 852, 472)),
        ],
      },
      {
        id: "body",
        name: "thân robot",
        voice: "Lắp thêm thân dưới.",
        strokes: [
          s(line(400, 775, 380, 940)),
          s(line(600, 775, 620, 940)),
          s(line(330, 940, 670, 940)),
        ],
      },
    ],
  },
  {
    key: "subject:lollipop",
    label: "Kẹo mút",
    glyphKey: "glyph:spiral",
    parts: [
      {
        id: "stick-sides",
        name: "que kẹo",
        voice: "Nắn lại cái que.",
        strokes: [s(line(462, 760, 462, 950)), s(line(538, 760, 538, 950))],
      },
      {
        id: "stripes",
        name: "sọc kẹo",
        voice: "Quay vòng sọc kẹo.",
        strokes: [
          s("M 300 380 C 420 300 580 300 700 380", 20),
          s("M 280 560 C 400 640 600 640 720 560", 20),
        ],
      },
      {
        id: "ribbon",
        name: "dải nơ",
        voice: "Thắt cái nơ nhỏ.",
        strokes: [
          s(poly([[500, 780], [392, 748], [420, 856]])),
          s(poly([[500, 780], [608, 748], [580, 856]])),
        ],
      },
      {
        id: "shine",
        name: "vệt bóng",
        strokes: [s(arc(360, 330, 90, 90, 200, 320), 16)],
      },
    ],
  },
  {
    key: "subject:starfish",
    label: "Sao biển",
    glyphKey: "glyph:star",
    parts: [
      {
        id: "inner-star",
        name: "sao bên trong",
        voice: "Vẽ ngôi sao bên trong.",
        strokes: [s(arc(500, 500, 150, 150, 0, 360))],
      },
      {
        id: "eyes",
        name: "đôi mắt",
        strokes: [dot(440, 470, 22), dot(560, 470, 22)],
      },
      {
        id: "smile",
        name: "nụ cười",
        voice: "Cười tíu tít.",
        strokes: [s(arc(500, 560, 80, 60, 25, 155))],
      },
      {
        id: "bubbles",
        name: "bong bóng biển",
        voice: "Nổi lên dưới đáy biển.",
        strokes: [s(circle(150, 220, 30), 16), s(circle(880, 300, 22), 14), s(circle(190, 800, 24), 14)],
      },
    ],
  },
  {
    key: "subject:sea",
    label: "Biển xanh",
    glyphKey: "glyph:wave",
    parts: [
      {
        id: "boat",
        name: "chiếc thuyền",
        voice: "Thả một chiếc thuyền.",
        strokes: [
          s(poly([[330, 480], [330, 300], [470, 460]])),
          s(poly([[280, 470], [520, 470], [470, 570], [330, 570], [280, 470]])),
        ],
      },
      {
        id: "sun",
        name: "mặt trời",
        strokes: [s(circle(180, 180, 82)), dot(180, 180, 18)],
      },
      {
        id: "birds",
        name: "chim biển",
        strokes: [
          s(arc(600, 200, 48, 32, 195, 345), 14),
          s(arc(720, 250, 48, 32, 195, 345), 14),
        ],
      },
      {
        id: "fish",
        name: "cá bơi",
        voice: "Có cá đang bơi dưới nước.",
        strokes: [
          s(poly([[300, 720], [390, 690], [390, 750]])),
          s(ellipse(300, 720, 90, 40)),
        ],
      },
    ],
  },
  {
    key: "subject:pencil",
    label: "Bút chì",
    glyphKey: "glyph:line",
    parts: [
      {
        id: "body",
        name: "thân bút",
        voice: "Nắn thành thân bút chì.",
        strokes: [s(line(215, 430, 700, 430)), s(line(215, 570, 700, 570))],
      },
      {
        id: "eraser",
        name: "cục gôm",
        voice: "Gắn cục gôm ở đuôi.",
        strokes: [s(ellipse(150, 500, 70, 70)), s(line(215, 430, 215, 570))],
      },
      {
        id: "tip",
        name: "mũi bút",
        voice: "Gọt nhọn đầu bút.",
        strokes: [s(poly([[700, 430], [880, 500], [700, 570]]))],
      },
      {
        id: "lead",
        name: "chì",
        strokes: [s(poly([[792, 478], [880, 500], [792, 522]]), 30)],
      },
      {
        id: "shine",
        name: "vệt sáng",
        strokes: [s(line(280, 470, 620, 470), 12)],
      },
    ],
  },

  /* ---------------------------- combinations ---------------------------- */
  {
    key: "subject:magnifier",
    label: "Kính lúp",
    glyphKey: "glyph:O-bar",
    parts: [
      {
        id: "grip",
        name: "cán kính",
        voice: "Làm dày cái cán.",
        strokes: [
          s(line(568, 622, 830, 878)),
          s(line(626, 570, 888, 826)),
        ],
      },
      {
        id: "shine",
        name: "vệt sáng",
        voice: "Kính lóe sáng.",
        strokes: [s(arc(420, 420, 178, 178, 200, 305), 18)],
      },
      {
        id: "sparkle",
        name: "tia sáng",
        voice: "Tìm thấy rồi!",
        strokes: [
          s(line(800, 170, 800, 260), 18),
          s(line(755, 215, 845, 215), 18),
          s(line(880, 260, 880, 320), 14),
          s(line(850, 290, 910, 290), 14),
        ],
      },
      {
        id: "ant",
        name: "chú kiến",
        voice: "Phóng to chú kiến.",
        strokes: [
          dot(420, 430, 26),
          dot(420, 500, 18),
          dot(420, 550, 14),
          s(line(395, 500, 350, 545), 14),
          s(line(445, 500, 490, 545), 14),
        ],
      },
    ],
  },
  {
    key: "subject:candy",
    label: "Kẹo mút xoắn",
    glyphKey: "glyph:circle-stick",
    parts: [
      {
        id: "stick-sides",
        name: "que kẹo",
        voice: "Nắn lại que kẹo.",
        strokes: [s(line(468, 600, 468, 900)), s(line(532, 600, 532, 900))],
      },
      {
        id: "swirl",
        name: "sọc xoắn",
        voice: "Xoay vòng sọc kẹo.",
        strokes: [
          s("M 320 240 C 420 350 580 350 680 240", 20),
          s("M 300 420 C 420 500 580 500 700 420", 20),
        ],
      },
      {
        id: "ribbon",
        name: "nơ ruy băng",
        voice: "Thắt nơ thật xinh.",
        strokes: [
          s(poly([[500, 860], [392, 828], [420, 936]])),
          s(poly([[500, 860], [608, 828], [580, 936]])),
        ],
      },
    ],
  },
];

export const SUBJECT_MAP: Record<string, SubjectDef> = Object.fromEntries(
  SUBJECTS.map((s) => [s.key, s]),
);

export function getSubject(key: string): SubjectDef | undefined {
  return SUBJECT_MAP[key];
}
