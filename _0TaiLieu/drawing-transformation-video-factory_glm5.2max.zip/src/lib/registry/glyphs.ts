import {
  arc,
  circle,
  ellipse,
  line,
  poly,
  spiral,
  star,
  wave,
  type StrokeDef,
} from "@/lib/geometry/path";

/**
 * Registry of hook glyphs. Everything lives in a 0..1000 coordinate space that
 * the planner later fits into the 1080x1920 canvas (FR-004).
 */
export type GlyphDef = {
  key: string;
  label: string;
  /** Human readable hook, e.g. "8" or "O + |" */
  hook: string;
  category: "number" | "letter" | "symbol" | "geometry" | "combination";
  strokes: StrokeDef[];
};

const W = 26;

const s = (d: string, w = W): StrokeDef => ({ d, w });

export const GLYPHS: GlyphDef[] = [
  /* ------------------------------ numbers ------------------------------ */
  {
    key: "glyph:0",
    label: "Số 0",
    hook: "0",
    category: "number",
    strokes: [s(ellipse(500, 500, 250, 320))],
  },
  {
    key: "glyph:1",
    label: "Số 1",
    hook: "1",
    category: "number",
    strokes: [s(poly([[340, 310], [510, 195], [510, 815]]))],
  },
  {
    key: "glyph:2",
    label: "Số 2",
    hook: "2",
    category: "number",
    strokes: [
      s(
        "M 300 350 C 300 210 700 200 700 380 C 700 510 320 610 300 810 L 750 810",
      ),
    ],
  },
  {
    key: "glyph:3",
    label: "Số 3",
    hook: "3",
    category: "number",
    strokes: [
      s(
        "M 540 250 C 540 170 900 175 900 350 C 900 465 660 480 630 505 C 665 535 900 555 900 675 C 900 850 540 855 535 745",
      ),
    ],
  },
  {
    key: "glyph:4",
    label: "Số 4",
    hook: "4",
    category: "number",
    strokes: [
      s(line(280, 630, 660, 200)),
      s(line(660, 200, 660, 815)),
      s(line(280, 630, 755, 630)),
    ],
  },
  {
    key: "glyph:5",
    label: "Số 5",
    hook: "5",
    category: "number",
    strokes: [
      s(
        "M 700 235 L 340 235 L 305 505 C 365 455 700 455 700 665 C 700 835 305 835 300 700",
      ),
    ],
  },
  {
    key: "glyph:6",
    label: "Số 6",
    hook: "6",
    category: "number",
    strokes: [
      s(
        "M 655 210 C 420 365 300 520 300 660 C 300 790 405 845 520 845 C 640 845 705 755 705 660 C 705 555 625 490 520 490 C 400 490 320 560 320 660",
      ),
    ],
  },
  {
    key: "glyph:7",
    label: "Số 7",
    hook: "7",
    category: "number",
    strokes: [s(poly([[300, 250], [715, 250], [470, 815]]))],
  },
  {
    key: "glyph:8",
    label: "Số 8",
    hook: "8",
    category: "number",
    strokes: [s(circle(500, 330, 178)), s(circle(500, 660, 232))],
  },
  {
    key: "glyph:9",
    label: "Số 9",
    hook: "9",
    category: "number",
    strokes: [
      s(circle(500, 350, 190)),
      s("M 690 400 C 705 560 640 700 470 790"),
    ],
  },

  /* ------------------------------ letters ------------------------------ */
  {
    key: "glyph:A",
    label: "Chữ A",
    hook: "A",
    category: "letter",
    strokes: [
      s(poly([[255, 815], [500, 190], [745, 815]])),
      s(line(355, 610, 645, 610)),
    ],
  },
  {
    key: "glyph:B",
    label: "Chữ B",
    hook: "B",
    category: "letter",
    strokes: [
      s(line(330, 190, 330, 815)),
      s("M 330 190 C 660 200 660 450 330 455"),
      s("M 330 455 C 710 465 710 805 330 815"),
    ],
  },
  {
    key: "glyph:C",
    label: "Chữ C",
    hook: "C",
    category: "letter",
    strokes: [s(arc(500, 500, 275, 315, 35, 325))],
  },
  {
    key: "glyph:D",
    label: "Chữ D",
    hook: "D",
    category: "letter",
    strokes: [
      s(line(330, 190, 330, 815)),
      s("M 330 190 C 690 225 690 780 330 815"),
    ],
  },
  {
    key: "glyph:M",
    label: "Chữ M",
    hook: "M",
    category: "letter",
    strokes: [s(poly([[240, 815], [240, 250], [500, 630], [760, 250], [760, 815]]))],
  },
  {
    key: "glyph:O",
    label: "Chữ O",
    hook: "O",
    category: "letter",
    strokes: [s(ellipse(500, 500, 275, 310))],
  },
  {
    key: "glyph:Q",
    label: "Chữ Q",
    hook: "Q",
    category: "letter",
    strokes: [s(ellipse(500, 480, 275, 295)), s(line(640, 655, 850, 880))],
  },
  {
    key: "glyph:S",
    label: "Chữ S",
    hook: "S",
    category: "letter",
    strokes: [
      s(
        "M 710 300 C 710 200 320 185 320 340 C 320 470 710 505 710 660 C 710 840 285 835 285 700",
      ),
    ],
  },
  {
    key: "glyph:T",
    label: "Chữ T",
    hook: "T",
    category: "letter",
    strokes: [s(line(250, 240, 750, 240)), s(line(500, 240, 500, 815))],
  },
  {
    key: "glyph:U",
    label: "Chữ U",
    hook: "U",
    category: "letter",
    strokes: [s("M 300 195 L 300 600 C 300 790 700 790 700 600 L 700 195")],
  },
  {
    key: "glyph:V",
    label: "Chữ V",
    hook: "V",
    category: "letter",
    strokes: [s(poly([[255, 195], [500, 820], [745, 195]]))],
  },
  {
    key: "glyph:Y",
    label: "Chữ Y",
    hook: "Y",
    category: "letter",
    strokes: [
      s(poly([[270, 205], [500, 520], [730, 205]])),
      s(line(500, 520, 500, 815)),
    ],
  },

  /* ------------------------------ symbols ------------------------------ */
  {
    key: "glyph:@",
    label: "Ký hiệu @",
    hook: "@",
    category: "symbol",
    strokes: [
      s(spiral(545, 470, 1.75, 250)),
      s("M 795 470 L 795 690 C 795 800 700 835 590 835"),
    ],
  },
  {
    key: "glyph:plus",
    label: "Dấu cộng",
    hook: "+",
    category: "symbol",
    strokes: [s(line(500, 200, 500, 800)), s(line(200, 500, 800, 500))],
  },
  {
    key: "glyph:cross",
    label: "Dấu nhân",
    hook: "×",
    category: "symbol",
    strokes: [s(line(275, 275, 725, 725)), s(line(725, 275, 275, 725))],
  },
  {
    key: "glyph:hash",
    label: "Dấu #",
    hook: "#",
    category: "symbol",
    strokes: [
      s(line(370, 215, 330, 790)),
      s(line(650, 215, 610, 790)),
      s(line(240, 385, 770, 350)),
      s(line(225, 625, 765, 590)),
    ],
  },

  /* ------------------------------ geometry ----------------------------- */
  {
    key: "glyph:circle",
    label: "Hình tròn",
    hook: "circle",
    category: "geometry",
    strokes: [s(circle(500, 500, 300), 30)],
  },
  {
    key: "glyph:triangle",
    label: "Hình tam giác",
    hook: "triangle",
    category: "geometry",
    strokes: [s(poly([[500, 185], [820, 790], [180, 790], [500, 185]]))],
  },
  {
    key: "glyph:square",
    label: "Hình vuông",
    hook: "square",
    category: "geometry",
    strokes: [s(poly([[225, 225], [775, 225], [775, 775], [225, 775], [225, 225]]))],
  },
  {
    key: "glyph:line",
    label: "Đường thẳng",
    hook: "line",
    category: "geometry",
    strokes: [s(line(175, 500, 825, 500), 32)],
  },
  {
    key: "glyph:spiral",
    label: "Đường xoắn",
    hook: "spiral",
    category: "geometry",
    strokes: [s(spiral(500, 500, 3, 300))],
  },
  {
    key: "glyph:wave",
    label: "Đường sóng",
    hook: "wave",
    category: "geometry",
    strokes: [s(wave(140, 500, 860, 500, 120, 2), 30)],
  },
  {
    key: "glyph:star",
    label: "Hình sao",
    hook: "star",
    category: "geometry",
    strokes: [s(star(500, 500, 320, 140, 5))],
  },

  /* ---------------------------- combinations --------------------------- */
  {
    key: "glyph:O-bar",
    label: "O + |",
    hook: "O + |",
    category: "combination",
    strokes: [
      s(circle(420, 420, 250)),
      s(line(595, 595, 860, 860)),
    ],
  },
  {
    key: "glyph:circle-stick",
    label: "O + —",
    hook: "O + —",
    category: "combination",
    strokes: [
      s(circle(500, 330, 230), 30),
      s(line(500, 560, 500, 880), 30),
    ],
  },
];

export const GLYPH_MAP: Record<string, GlyphDef> = Object.fromEntries(
  GLYPHS.map((g) => [g.key, g]),
);

export function getGlyph(key: string): GlyphDef | undefined {
  return GLYPH_MAP[key];
}
