import { GLYPHS } from "./glyphs";
import { SUBJECTS } from "./subjects";

export type RegistryEntry = {
  key: string;
  kind: "glyph" | "subject";
  label: string;
  glyphKey: string | null;
  strokeCount: number;
  partCount: number;
};

/**
 * FR-004 — the controlled vocabulary. A generated concept may only reference
 * keys that exist here; the validator enforces it.
 */
export function listRegistryComponents(): RegistryEntry[] {
  const glyphs: RegistryEntry[] = GLYPHS.map((g) => ({
    key: g.key,
    kind: "glyph" as const,
    label: `${g.hook} · ${g.label}`,
    glyphKey: g.key,
    strokeCount: g.strokes.length,
    partCount: 0,
  }));
  const subjects: RegistryEntry[] = SUBJECTS.map((s) => ({
    key: s.key,
    kind: "subject" as const,
    label: s.label,
    glyphKey: s.glyphKey,
    strokeCount: s.parts.reduce((acc, p) => acc + p.strokes.length, 0),
    partCount: s.parts.length,
  }));
  return [...glyphs, ...subjects];
}

export function registrySize(): { glyphs: number; subjects: number } {
  return { glyphs: GLYPHS.length, subjects: SUBJECTS.length };
}
