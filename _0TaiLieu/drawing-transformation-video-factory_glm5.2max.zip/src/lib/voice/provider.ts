/**
 * Voice provider abstraction (NFR-003). TTS is pluggable: today it is either a
 * hosted provider (when a key exists) or the browser's speech engine. The
 * product logic only ever deals with text cues + timings.
 */
export type ProviderInfo = {
  key: "openai" | "elevenlabs" | "browser";
  label: string;
  voice: string;
  configurable: boolean;
};

export function detectProvider(): ProviderInfo {
  if (process.env.OPENAI_API_KEY) {
    return {
      key: "openai",
      label: "OpenAI TTS",
      voice: process.env.OPENAI_TTS_VOICE ?? "alloy",
      configurable: true,
    };
  }
  if (process.env.ELEVENLABS_API_KEY) {
    return {
      key: "elevenlabs",
      label: "ElevenLabs",
      voice: process.env.ELEVENLABS_VOICE_ID ?? "21m00Tcm4TlvDq8ikWAM",
      configurable: true,
    };
  }
  return {
    key: "browser",
    label: "Browser SpeechSynthesis (vi-VN)",
    voice: "vi-VN",
    configurable: false,
  };
}

export type SynthResult = { audio: ArrayBuffer; mimeType: string };

export async function synthesize(
  text: string,
  info: ProviderInfo,
): Promise<SynthResult | null> {
  if (info.key === "openai") {
    const response = await fetch("https://api.openai.com/v1/audio/speech", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: process.env.OPENAI_TTS_MODEL ?? "gpt-4o-mini-tts",
        voice: info.voice,
        input: text,
        response_format: "mp3",
        instructions:
          "Giọng nữ tiếng Việt thân thiện, tốc độ vừa phải, kể chuyện dạng short video.",
      }),
    });
    if (!response.ok) return null;
    return {
      audio: await response.arrayBuffer(),
      mimeType: "audio/mpeg",
    };
  }
  if (info.key === "elevenlabs") {
    const response = await fetch(
      `https://api.elevenlabs.io/v1/text-to-speech/${info.voice}`,
      {
        method: "POST",
        headers: {
          "xi-api-key": process.env.ELEVENLABS_API_KEY ?? "",
          "Content-Type": "application/json",
          Accept: "audio/mpeg",
        },
        body: JSON.stringify({
          text,
          model_id: "eleven_multilingual_v2",
        }),
      },
    );
    if (!response.ok) return null;
    return {
      audio: await response.arrayBuffer(),
      mimeType: "audio/mpeg",
    };
  }
  return null;
}
