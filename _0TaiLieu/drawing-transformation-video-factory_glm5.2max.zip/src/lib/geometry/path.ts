/**
 * Deterministic SVG path engine.
 *
 * Everything the factory draws is expressed as an SVG path string. This module
 * flattens those paths into dense polylines so that:
 *  - the pen tip can follow the real geometry (FR-006),
 *  - the final frame is built from the very same geometry (FR-007),
 *  - validation can reason about lengths and bounds (FR-005).
 */

export type Pt = { x: number; y: number };

export type StrokeDef = {
  /** SVG path data. Multiple subpaths are allowed and become separate strokes. */
  d: string;
  /** Stroke width in the 0..1000 registry space. */
  w: number;
};

const KAPPA = 0.5522847498;

/* ------------------------------------------------------------------ *
 * Path helpers used by the registry (drawing DSL)
 * ------------------------------------------------------------------ */

function n(value: number): string {
  return Math.round(value * 100) / 100 + "";
}

export function poly(points: Array<[number, number]>): string {
  if (points.length === 0) return "";
  let d = `M ${n(points[0][0])} ${n(points[0][1])}`;
  for (let i = 1; i < points.length; i += 1) {
    d += ` L ${n(points[i][0])} ${n(points[i][1])}`;
  }
  return d;
}

export function line(x1: number, y1: number, x2: number, y2: number): string {
  return `M ${n(x1)} ${n(y1)} L ${n(x2)} ${n(y2)}`;
}

export function circle(cx: number, cy: number, r: number): string {
  return ellipse(cx, cy, r, r);
}

export function ellipse(
  cx: number,
  cy: number,
  rx: number,
  ry: number,
): string {
  const ox = rx * KAPPA;
  const oy = ry * KAPPA;
  return [
    `M ${n(cx - rx)} ${n(cy)}`,
    `C ${n(cx - rx)} ${n(cy - oy)} ${n(cx - ox)} ${n(cy - ry)} ${n(cx)} ${n(cy - ry)}`,
    `C ${n(cx + ox)} ${n(cy - ry)} ${n(cx + rx)} ${n(cy - oy)} ${n(cx + rx)} ${n(cy)}`,
    `C ${n(cx + rx)} ${n(cy + oy)} ${n(cx + ox)} ${n(cy + ry)} ${n(cx)} ${n(cy + ry)}`,
    `C ${n(cx - ox)} ${n(cy + ry)} ${n(cx - rx)} ${n(cy + oy)} ${n(cx - rx)} ${n(cy)}`,
    "Z",
  ].join(" ");
}

export function cubic(
  p0: [number, number],
  p1: [number, number],
  p2: [number, number],
  p3: [number, number],
): string {
  return `M ${n(p0[0])} ${n(p0[1])} C ${n(p1[0])} ${n(p1[1])} ${n(p2[0])} ${n(p2[1])} ${n(p3[0])} ${n(p3[1])}`;
}

export function arc(
  cx: number,
  cy: number,
  rx: number,
  ry: number,
  startDeg: number,
  endDeg: number,
  steps = 24,
): string {
  const pts: Array<[number, number]> = [];
  for (let i = 0; i <= steps; i += 1) {
    const a = ((startDeg + ((endDeg - startDeg) * i) / steps) * Math.PI) / 180;
    pts.push([cx + rx * Math.cos(a), cy + ry * Math.sin(a)]);
  }
  return poly(pts);
}

export function star(
  cx: number,
  cy: number,
  outer: number,
  inner: number,
  points = 5,
  rotation = -90,
): string {
  const pts: Array<[number, number]> = [];
  for (let i = 0; i < points * 2; i += 1) {
    const r = i % 2 === 0 ? outer : inner;
    const a = ((rotation + (180 * i) / points) * Math.PI) / 180;
    pts.push([cx + r * Math.cos(a), cy + r * Math.sin(a)]);
  }
  return poly(pts) + " Z";
}

export function spiral(
  cx: number,
  cy: number,
  turns: number,
  rMax: number,
  steps = 160,
): string {
  const pts: Array<[number, number]> = [];
  for (let i = 0; i <= steps; i += 1) {
    const t = i / steps;
    const a = turns * Math.PI * 2 * t;
    const r = rMax * t;
    pts.push([cx + r * Math.cos(a), cy + r * Math.sin(a)]);
  }
  return poly(pts);
}

export function wave(
  x1: number,
  y1: number,
  x2: number,
  y2: number,
  amplitude: number,
  periods = 2,
): string {
  const pts: Array<[number, number]> = [];
  const steps = 96;
  for (let i = 0; i <= steps; i += 1) {
    const t = i / steps;
    const x = x1 + (x2 - x1) * t;
    const y =
      y1 + (y2 - y1) * t + Math.sin(t * Math.PI * 2 * periods) * amplitude;
    pts.push([x, y]);
  }
  return poly(pts);
}

/* ------------------------------------------------------------------ *
 * Parser / flattener
 * ------------------------------------------------------------------ */

type Token = { cmd: string; args: number[] };

function tokenize(d: string): Token[] {
  const tokens: Token[] = [];
  const re = /([MmLlHhVvCcSsQqTtAaZz])|(-?\d*\.?\d+(?:[eE][-+]?\d+)?)/g;
  let match: RegExpExecArray | null;
  let current: Token | null = null;
  while ((match = re.exec(d)) !== null) {
    if (match[1]) {
      if (current) tokens.push(current);
      current = { cmd: match[1], args: [] };
      if (match[1] === "Z" || match[1] === "z") {
        tokens.push(current);
        current = null;
      }
    } else if (current) {
      current.args.push(parseFloat(match[0]));
    }
  }
  if (current) tokens.push(current);
  return tokens;
}

function dist(a: Pt, b: Pt): number {
  return Math.hypot(a.x - b.x, a.y - b.y);
}

function cubicAt(t: number, p0: Pt, p1: Pt, p2: Pt, p3: Pt): Pt {
  const u = 1 - t;
  return {
    x:
      u * u * u * p0.x +
      3 * u * u * t * p1.x +
      3 * u * t * t * p2.x +
      t * t * t * p3.x,
    y:
      u * u * u * p0.y +
      3 * u * u * t * p1.y +
      3 * u * t * t * p2.y +
      t * t * t * p3.y,
  };
}

function quadAt(t: number, p0: Pt, p1: Pt, p2: Pt): Pt {
  const u = 1 - t;
  return {
    x: u * u * p0.x + 2 * u * t * p1.x + t * t * p2.x,
    y: u * u * p0.y + 2 * u * t * p1.y + t * t * p2.y,
  };
}

function pushCubic(
  out: Pt[],
  p0: Pt,
  p1: Pt,
  p2: Pt,
  p3: Pt,
  resolution: number,
) {
  const approx =
    dist(p0, p1) + dist(p1, p2) + dist(p2, p3) + dist(p0, p3);
  const steps = Math.max(
    4,
    Math.min(96, Math.ceil(approx / resolution)),
  );
  for (let i = 1; i <= steps; i += 1) {
    out.push(cubicAt(i / steps, p0, p1, p2, p3));
  }
}

function pushQuad(out: Pt[], p0: Pt, p1: Pt, p2: Pt, resolution: number) {
  const approx = dist(p0, p1) + dist(p1, p2) + dist(p0, p2);
  const steps = Math.max(3, Math.min(64, Math.ceil(approx / resolution)));
  for (let i = 1; i <= steps; i += 1) {
    out.push(quadAt(i / steps, p0, p1, p2));
  }
}

function arcPoints(
  out: Pt[],
  r0: Pt,
  rx: number,
  ry: number,
  rotationDeg: number,
  largeArc: boolean,
  sweep: boolean,
  r1: Pt,
) {
  if (rx === 0 || ry === 0 || (r0.x === r1.x && r0.y === r1.y)) {
    out.push({ ...r1 });
    return;
  }
  const phi = (rotationDeg * Math.PI) / 180;
  const cosPhi = Math.cos(phi);
  const sinPhi = Math.sin(phi);
  const dx = (r0.x - r1.x) / 2;
  const dy = (r0.y - r1.y) / 2;
  const x1p = cosPhi * dx + sinPhi * dy;
  const y1p = -sinPhi * dx + cosPhi * dy;
  const rx2 = Math.abs(rx);
  const ry2 = Math.abs(ry);
  const lambda =
    (x1p * x1p) / (rx2 * rx2) + (y1p * y1p) / (ry2 * ry2);
  let rxA = rx2;
  let ryA = ry2;
  if (lambda > 1) {
    const s = Math.sqrt(lambda);
    rxA = rx2 * s;
    ryA = ry2 * s;
  }
  const sign = largeArc !== sweep ? 1 : -1;
  const num = rxA * rxA * ryA * ryA - rxA * rxA * y1p * y1p - ryA * ryA * x1p * x1p;
  const den = rxA * rxA * y1p * y1p + ryA * ryA * x1p * x1p;
  const co = sign * Math.sqrt(Math.max(0, num / den));
  const cxp = (co * rxA * y1p) / ryA;
  const cyp = (-co * ryA * x1p) / rxA;
  const cx = cosPhi * cxp - sinPhi * cyp + (r0.x + r1.x) / 2;
  const cy = sinPhi * cxp + cosPhi * cyp + (r0.y + r1.y) / 2;
  const angle = (ux: number, uy: number, vx: number, vy: number) => {
    const dot = ux * vx + uy * vy;
    const len = Math.hypot(ux, uy) * Math.hypot(vx, vy);
    let a = Math.acos(Math.max(-1, Math.min(1, dot / (len || 1))));
    if (ux * vy - uy * vx < 0) a = -a;
    return a;
  };
  const startAngle = angle(
    1,
    0,
    (x1p - cxp) / rxA,
    (y1p - cyp) / ryA,
  );
  let sweepAngle = angle(
    (x1p - cxp) / rxA,
    (y1p - cyp) / ryA,
    (-x1p - cxp) / rxA,
    (-y1p - cyp) / ryA,
  );
  if (!sweep && sweepAngle > 0) sweepAngle -= Math.PI * 2;
  if (sweep && sweepAngle < 0) sweepAngle += Math.PI * 2;
  const steps = Math.max(
    6,
    Math.min(160, Math.ceil((Math.abs(sweepAngle) * Math.max(rxA, ryA)) / 4)),
  );
  for (let i = 1; i <= steps; i += 1) {
    const t = startAngle + (sweepAngle * i) / steps;
    out.push({
      x: cx + rxA * Math.cos(t) * cosPhi - ryA * Math.sin(t) * sinPhi,
      y: cy + rxA * Math.cos(t) * sinPhi + ryA * Math.sin(t) * cosPhi,
    });
  }
}

export type FlattenedStroke = {
  points: Pt[];
  length: number;
  closed: boolean;
};

/**
 * Flatten a path string into sub-polylines. A path with two `M` commands
 * returns two entries so the planner can animate a pen lift between them.
 */
export function flattenPath(
  d: string,
  resolution = 3,
): FlattenedStroke[] {
  const tokens = tokenize(d);
  const result: FlattenedStroke[] = [];
  let current: Pt[] = [];
  let cur: Pt = { x: 0, y: 0 };
  let start: Pt = { x: 0, y: 0 };
  let lastCubicCtrl: Pt | null = null;
  let lastQuadCtrl: Pt | null = null;

  const flush = () => {
    if (current.length > 1) {
      const closed =
        current.length > 2 &&
        dist(current[0], current[current.length - 1]) < resolution * 1.5;
      result.push({
        points: current,
        length: polylineLength(current),
        closed,
      });
    }
    current = [];
  };

  for (const token of tokens) {
    const { cmd } = token;
    const a = token.args;
    switch (cmd) {
      case "M":
        flush();
        cur = { x: a[0], y: a[1] };
        start = { ...cur };
        current = [cur];
        break;
      case "m":
        flush();
        cur = { x: cur.x + a[0], y: cur.y + a[1] };
        start = { ...cur };
        current = [cur];
        break;
      case "L":
        cur = { x: a[0], y: a[1] };
        current.push(cur);
        break;
      case "l":
        cur = { x: cur.x + a[0], y: cur.y + a[1] };
        current.push(cur);
        break;
      case "H":
        cur = { x: a[0], y: cur.y };
        current.push(cur);
        break;
      case "h":
        cur = { x: cur.x + a[0], y: cur.y };
        current.push(cur);
        break;
      case "V":
        cur = { x: cur.x, y: a[0] };
        current.push(cur);
        break;
      case "v":
        cur = { x: cur.x, y: cur.y + a[0] };
        current.push(cur);
        break;
      case "C":
        for (let i = 0; i + 5 < a.length + 1; i += 6) {
          const p1 = { x: a[i], y: a[i + 1] };
          const p2 = { x: a[i + 2], y: a[i + 3] };
          const p3 = { x: a[i + 4], y: a[i + 5] };
          pushCubic(current, cur, p1, p2, p3, resolution);
          cur = p3;
          lastCubicCtrl = p2;
        }
        break;
      case "c":
        for (let i = 0; i + 5 < a.length + 1; i += 6) {
          const p1 = { x: cur.x + a[i], y: cur.y + a[i + 1] };
          const p2 = { x: cur.x + a[i + 2], y: cur.y + a[i + 3] };
          const p3 = { x: cur.x + a[i + 4], y: cur.y + a[i + 5] };
          pushCubic(current, cur, p1, p2, p3, resolution);
          cur = p3;
          lastCubicCtrl = p2;
        }
        break;
      case "S": {
        for (let i = 0; i + 3 < a.length + 1; i += 4) {
          const p1 = lastCubicCtrl
            ? { x: 2 * cur.x - lastCubicCtrl.x, y: 2 * cur.y - lastCubicCtrl.y }
            : { ...cur };
          const p2 = { x: a[i], y: a[i + 1] };
          const p3 = { x: a[i + 2], y: a[i + 3] };
          pushCubic(current, cur, p1, p2, p3, resolution);
          cur = p3;
          lastCubicCtrl = p2;
        }
        break;
      }
      case "s": {
        for (let i = 0; i + 3 < a.length + 1; i += 4) {
          const p1 = lastCubicCtrl
            ? { x: 2 * cur.x - lastCubicCtrl.x, y: 2 * cur.y - lastCubicCtrl.y }
            : { ...cur };
          const p2 = { x: cur.x + a[i], y: cur.y + a[i + 1] };
          const p3 = { x: cur.x + a[i + 2], y: cur.y + a[i + 3] };
          pushCubic(current, cur, p1, p2, p3, resolution);
          cur = p3;
          lastCubicCtrl = p2;
        }
        break;
      }
      case "Q":
        for (let i = 0; i + 3 < a.length + 1; i += 4) {
          const p1 = { x: a[i], y: a[i + 1] };
          const p2 = { x: a[i + 2], y: a[i + 3] };
          pushQuad(current, cur, p1, p2, resolution);
          cur = p2;
          lastQuadCtrl = p1;
        }
        break;
      case "q":
        for (let i = 0; i + 3 < a.length + 1; i += 4) {
          const p1 = { x: cur.x + a[i], y: cur.y + a[i + 1] };
          const p2 = { x: cur.x + a[i + 2], y: cur.y + a[i + 3] };
          pushQuad(current, cur, p1, p2, resolution);
          cur = p2;
          lastQuadCtrl = p1;
        }
        break;
      case "T": {
        for (let i = 0; i + 1 < a.length + 1; i += 2) {
          const p1: Pt = lastQuadCtrl
            ? { x: 2 * cur.x - lastQuadCtrl.x, y: 2 * cur.y - lastQuadCtrl.y }
            : { ...cur };
          const p2: Pt = { x: a[i], y: a[i + 1] };
          pushQuad(current, cur, p1, p2, resolution);
          cur = p2;
          lastQuadCtrl = p1;
        }
        break;
      }
      case "t": {
        for (let i = 0; i + 1 < a.length + 1; i += 2) {
          const p1: Pt = lastQuadCtrl
            ? { x: 2 * cur.x - lastQuadCtrl.x, y: 2 * cur.y - lastQuadCtrl.y }
            : { ...cur };
          const p2: Pt = { x: cur.x + a[i], y: cur.y + a[i + 1] };
          pushQuad(current, cur, p1, p2, resolution);
          cur = p2;
          lastQuadCtrl = p1;
        }
        break;
      }
      case "A":
        for (let i = 0; i + 6 < a.length + 1; i += 7) {
          const to = { x: a[i + 5], y: a[i + 6] };
          arcPoints(current, cur, a[i], a[i + 1], a[i + 2], a[i + 3] !== 0, a[i + 4] !== 0, to);
          cur = to;
        }
        break;
      case "a":
        for (let i = 0; i + 6 < a.length + 1; i += 7) {
          const to = { x: cur.x + a[i + 5], y: cur.y + a[i + 6] };
          arcPoints(current, cur, a[i], a[i + 1], a[i + 2], a[i + 3] !== 0, a[i + 4] !== 0, to);
          cur = to;
        }
        break;
      case "Z":
      case "z":
        if (current.length > 0) current.push({ ...start });
        cur = { ...start };
        break;
      default:
        break;
    }
  }
  flush();
  return result;
}

export function polylineLength(points: Pt[]): number {
  let total = 0;
  for (let i = 1; i < points.length; i += 1) {
    total += dist(points[i - 1], points[i]);
  }
  return total;
}

export function boundsOf(polylines: Pt[][]): {
  minX: number;
  minY: number;
  maxX: number;
  maxY: number;
} {
  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;
  for (const pts of polylines) {
    for (const p of pts) {
      if (p.x < minX) minX = p.x;
      if (p.y < minY) minY = p.y;
      if (p.x > maxX) maxX = p.x;
      if (p.y > maxY) maxY = p.y;
    }
  }
  if (!Number.isFinite(minX)) return { minX: 0, minY: 0, maxX: 0, maxY: 0 };
  return { minX, minY, maxX, maxY };
}

export function transformPoint(
  p: Pt,
  scale: number,
  offsetX: number,
  offsetY: number,
): Pt {
  return { x: p.x * scale + offsetX, y: p.y * scale + offsetY };
}

export function pointAtLength(
  points: Pt[],
  target: number,
): { point: Pt; index: number } {
  if (points.length === 0) return { point: { x: 0, y: 0 }, index: 0 };
  if (target <= 0) return { point: points[0], index: 0 };
  let acc = 0;
  for (let i = 1; i < points.length; i += 1) {
    const seg = dist(points[i - 1], points[i]);
    if (acc + seg >= target) {
      const t = seg === 0 ? 0 : (target - acc) / seg;
      return {
        point: {
          x: points[i - 1].x + (points[i].x - points[i - 1].x) * t,
          y: points[i - 1].y + (points[i].y - points[i - 1].y) * t,
        },
        index: i,
      };
    }
    acc += seg;
  }
  return { point: points[points.length - 1], index: points.length - 1 };
}
