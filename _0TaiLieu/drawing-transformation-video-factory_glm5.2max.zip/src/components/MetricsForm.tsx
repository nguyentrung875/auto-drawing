"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

const FIELDS: Array<{ key: string; label: string; suffix?: string }> = [
  { key: "views", label: "Views" },
  { key: "retention3s", label: "Retention 3s", suffix: "%" },
  { key: "completionRate", label: "Completion", suffix: "%" },
  { key: "replayRate", label: "Replay", suffix: "%" },
  { key: "shareRate", label: "Share", suffix: "%" },
  { key: "saveRate", label: "Save", suffix: "%" },
  { key: "ctr", label: "Affiliate CTR", suffix: "%" },
  { key: "conversions", label: "Conversions" },
  { key: "revenueMicros", label: "Revenue", suffix: "µ" },
];

export function MetricsForm({
  projectId,
  initial,
}: {
  projectId: number;
  initial?: Record<string, number | string>;
}) {
  const router = useRouter();
  const [values, setValues] = useState<Record<string, string>>(() => {
    const base: Record<string, string> = { platform: "tiktok" };
    for (const field of FIELDS) {
      base[field.key] = String(initial?.[field.key] ?? 0);
    }
    return base;
  });
  const [status, setStatus] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    setBusy(true);
    setStatus(null);
    try {
      const response = await fetch("/api/metrics", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ projectId, ...values }),
      });
      const data = (await response.json()) as { ok: boolean; error?: string };
      setStatus(data.ok ? "Đã lưu performance data." : (data.error ?? "Lỗi"));
      if (data.ok) router.refresh();
    } catch (error) {
      setStatus(error instanceof Error ? error.message : "Lỗi mạng");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="rounded-3xl border border-white/10 bg-white/[0.04] p-5">
      <h3 className="text-sm font-semibold text-white">Performance data</h3>
      <p className="mt-1 text-xs text-slate-400">
        Gắn số liệu thực tế vào project để chạy learning loop.
      </p>
      <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-3">
        <label className="col-span-2 sm:col-span-1">
          <span className="mb-1 block text-[11px] uppercase tracking-wider text-slate-500">
            Platform
          </span>
          <select
            value={values.platform}
            onChange={(event) =>
              setValues((prev) => ({ ...prev, platform: event.target.value }))
            }
            className="w-full rounded-lg border border-white/10 bg-[#0f1219] px-2 py-2 text-xs text-white"
          >
            {["tiktok", "youtube", "instagram", "facebook"].map((platform) => (
              <option key={platform} value={platform}>
                {platform}
              </option>
            ))}
          </select>
        </label>
        {FIELDS.map((field) => (
          <label key={field.key}>
            <span className="mb-1 block text-[11px] uppercase tracking-wider text-slate-500">
              {field.label}
            </span>
            <input
              type="number"
              value={values[field.key]}
              onChange={(event) =>
                setValues((prev) => ({ ...prev, [field.key]: event.target.value }))
              }
              className="w-full rounded-lg border border-white/10 bg-[#0f1219] px-2 py-2 text-xs text-white"
            />
          </label>
        ))}
      </div>
      <button
        type="button"
        onClick={() => void submit()}
        disabled={busy}
        className="mt-4 w-full rounded-xl border border-white/15 bg-white/5 px-4 py-2 text-xs font-bold text-white transition hover:border-orange-400/50 disabled:opacity-50"
      >
        {busy ? "Đang lưu…" : "Lưu performance"}
      </button>
      {status ? <p className="mt-3 text-xs text-emerald-300">{status}</p> : null}
    </div>
  );
}
