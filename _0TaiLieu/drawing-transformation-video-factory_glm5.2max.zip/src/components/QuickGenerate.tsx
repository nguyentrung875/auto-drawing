"use client";

import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { VARIANTS } from "@/lib/engine/types";

const EXAMPLES = ["8 → Bear", "0 → Panda", "S → Snake", "@ → Ốc sên", "V → Trái tim"];

export function QuickGenerate() {
  const router = useRouter();
  const [input, setInput] = useState("8 → Bear");
  const [seed, setSeed] = useState(12345);
  const [variant, setVariant] = useState("curious");
  const [cta, setCta] = useState("Xem thêm ở bio.");
  const [error, setError] = useState<string | null>(null);
  const [pending, startTransition] = useTransition();
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    setError(null);
    setBusy(true);
    try {
      const response = await fetch("/api/projects", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ slug: input, seed, variant, cta }),
      });
      const data = (await response.json()) as {
        ok: boolean;
        projectId?: number;
        error?: string;
      };
      if (!data.ok || !data.projectId) {
        setError(data.error ?? "Không tạo được project");
        setBusy(false);
        return;
      }
      startTransition(() => router.push(`/studio/${data.projectId}`));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Lỗi mạng");
      setBusy(false);
    }
  };

  const working = busy || pending;

  return (
    <div className="rounded-3xl border border-white/10 bg-white/[0.04] p-6 shadow-[0_20px_60px_rgba(0,0,0,0.35)]">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-semibold text-white">Tạo video từ concept</h2>
          <p className="mt-1 text-sm text-slate-400">
            Nhập subject hoặc dạng <span className="font-mono text-slate-300">hook → subject</span>
          </p>
        </div>
        <span className="rounded-full border border-orange-400/30 bg-orange-400/10 px-3 py-1 text-xs font-semibold text-orange-300">
          J1 · J2
        </span>
      </div>

      <div className="mt-5 grid gap-3 md:grid-cols-[2fr_1fr]">
        <input
          value={input}
          onChange={(event) => setInput(event.target.value)}
          onKeyDown={(event) => {
            if (event.key === "Enter" && !working) void submit();
          }}
          placeholder="8 → Bear"
          className="w-full rounded-xl border border-white/10 bg-[#0f1219] px-4 py-3 text-base text-white outline-none focus:border-orange-400/60"
        />
        <div className="flex gap-2">
          <label className="flex-1">
            <span className="mb-1 block text-[11px] uppercase tracking-wider text-slate-500">Seed</span>
            <input
              type="number"
              value={seed}
              onChange={(event) => setSeed(Number(event.target.value))}
              className="w-full rounded-xl border border-white/10 bg-[#0f1219] px-3 py-3 text-sm text-white outline-none focus:border-orange-400/60"
            />
          </label>
          <label className="flex-1">
            <span className="mb-1 block text-[11px] uppercase tracking-wider text-slate-500">Variant</span>
            <select
              value={variant}
              onChange={(event) => setVariant(event.target.value)}
              className="w-full rounded-xl border border-white/10 bg-[#0f1219] px-3 py-3 text-sm text-white outline-none focus:border-orange-400/60"
            >
              {VARIANTS.map((item) => (
                <option key={item.key} value={item.key}>
                  {item.label}
                </option>
              ))}
            </select>
          </label>
        </div>
      </div>

      <label className="mt-3 block">
        <span className="mb-1 block text-[11px] uppercase tracking-wider text-slate-500">
          CTA (không hard-code trong renderer)
        </span>
        <input
          value={cta}
          onChange={(event) => setCta(event.target.value)}
          className="w-full rounded-xl border border-white/10 bg-[#0f1219] px-4 py-2.5 text-sm text-white outline-none focus:border-orange-400/60"
        />
      </label>

      <div className="mt-4 flex flex-wrap items-center gap-2">
        {EXAMPLES.map((example) => (
          <button
            key={example}
            type="button"
            onClick={() => setInput(example)}
            className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-slate-300 transition hover:border-orange-400/40 hover:text-white"
          >
            {example}
          </button>
        ))}
      </div>

      {error ? (
        <p className="mt-4 rounded-xl border border-rose-500/30 bg-rose-500/10 px-4 py-2 text-sm text-rose-200">
          {error}
        </p>
      ) : null}

      <button
        type="button"
        onClick={() => void submit()}
        disabled={working}
        className="mt-5 w-full rounded-xl bg-gradient-to-r from-orange-400 to-rose-500 px-5 py-3 text-sm font-bold text-white transition hover:brightness-110 disabled:opacity-60"
      >
        {working ? "Đang tạo drawing plan…" : "Generate → Validate → Preview"}
      </button>
    </div>
  );
}
