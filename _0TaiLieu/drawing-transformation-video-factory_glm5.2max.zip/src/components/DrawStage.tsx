"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import type { DrawingPlan, Timeline } from "@/lib/engine/types";
import { createFrameRenderer } from "@/lib/render/renderer";
import { capturePoster, downloadBlob, exportMp4 } from "@/lib/render/export";

type Props = {
  projectId: number;
  plan: DrawingPlan;
  timeline: Timeline;
  ctaText: string;
  variant: string;
};

const SEGMENT_COLORS: Record<string, string> = {
  hook: "bg-sky-400/70",
  draw: "bg-orange-400/70",
  reveal: "bg-emerald-400/70",
  cta: "bg-fuchsia-400/70",
};

function formatTime(ms: number): string {
  const total = ms / 1000;
  return `${total.toFixed(1)}s`;
}

export function DrawStage({ projectId, plan, timeline, ctaText, variant }: Props) {
  const router = useRouter();
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const rafRef = useRef<number | null>(null);
  const clockRef = useRef<{ wall: number; offset: number } | null>(null);
  const spokenRef = useRef<Set<string>>(new Set());
  const [timeMs, setTimeMs] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [voiceOn, setVoiceOn] = useState(true);
  const [exporting, setExporting] = useState(false);
  const [progress, setProgress] = useState<{ value: number; stage: string } | null>(null);
  const [result, setResult] = useState<string | null>(null);
  const [voiceNote, setVoiceNote] = useState<string | null>(null);

  const renderer = useMemo(
    () => createFrameRenderer(plan, timeline, { ctaText }),
    [plan, timeline, ctaText],
  );

  const paint = useCallback(
    (t: number) => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;
      renderer.render(ctx, t);
    },
    [renderer],
  );

  useEffect(() => {
    paint(timeMs);
  }, [paint, timeMs]);

  const speak = useCallback((text: string) => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = "vi-VN";
    utterance.rate = 1.06;
    utterance.pitch = 1.05;
    window.speechSynthesis.speak(utterance);
  }, []);

  useEffect(() => {
    if (!playing) return;
    clockRef.current = { wall: performance.now(), offset: timeMs };
    const loop = () => {
      const clock = clockRef.current;
      if (!clock) return;
      const elapsed = clock.offset + (performance.now() - clock.wall);
      if (elapsed >= timeline.totalMs) {
        setTimeMs(timeline.totalMs);
        paint(timeline.totalMs);
        setPlaying(false);
        return;
      }
      setTimeMs(elapsed);
      if (voiceOn) {
        for (const cue of timeline.voice) {
          if (elapsed >= cue.startMs && elapsed < cue.startMs + 180) {
            if (!spokenRef.current.has(cue.id)) {
              spokenRef.current.add(cue.id);
              speak(cue.text);
            }
          }
        }
      }
      rafRef.current = requestAnimationFrame(loop);
    };
    rafRef.current = requestAnimationFrame(loop);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [playing, voiceOn, paint, speak, timeline]);

  useEffect(() => {
    if (!playing && typeof window !== "undefined" && "speechSynthesis" in window) {
      window.speechSynthesis.cancel();
    }
  }, [playing]);

  const seek = (value: number) => {
    spokenRef.current = new Set();
    setTimeMs(value);
    paint(value);
  };

  const togglePlay = () => {
    if (playing) {
      setPlaying(false);
      return;
    }
    if (timeMs >= timeline.totalMs) {
      spokenRef.current = new Set();
      setTimeMs(0);
    }
    setPlaying(true);
  };

  const runExport = async () => {
    setExporting(true);
    setResult(null);
    setProgress({ value: 0, stage: "Preparing" });
    try {
      const poster = capturePoster(plan, timeline, {
        ctaText,
        timeMs: timeline.inkEndMs,
        width: 480,
      });
      const output = await exportMp4({
        plan,
        timeline,
        ctaText,
        onProgress: (value, stage) => setProgress({ value, stage }),
      });
      downloadBlob(output.blob, output.fileName);
      setProgress({ value: 1, stage: "Logging render" });
      await fetch(`/api/projects/${projectId}/render`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          format: output.blob.type.includes("webm") ? "webm" : "mp4",
          encoder: output.encoder,
          status: "ok",
          width: output.width,
          height: output.height,
          fps: output.fps,
          durationMs: output.durationMs,
          sizeBytes: output.sizeBytes,
          renderMs: output.renderMs,
          hasVoice: voiceOn,
          notes: variant,
          poster,
        }),
      });
      setResult(
        `${output.fileName} · ${(output.sizeBytes / 1024 / 1024).toFixed(2)} MB · ${output.frames} frames · ${output.encoder}`,
      );
      router.refresh();
    } catch (error) {
      setResult(error instanceof Error ? `Lỗi export: ${error.message}` : "Lỗi export");
    } finally {
      setExporting(false);
      setProgress(null);
    }
  };

  useEffect(() => {
    const check = async () => {
      try {
        const response = await fetch("/api/voice", { cache: "no-store" });
        const data = (await response.json()) as {
          ok: boolean;
          provider?: { label: string };
          message?: string;
        };
        if (!data.ok) {
          setVoiceNote(data.message ?? "Dùng SpeechSynthesis của trình duyệt.");
        } else {
          setVoiceNote(`Voice provider: ${data.provider?.label}`);
        }
      } catch {
        setVoiceNote("Không kiểm tra được voice provider.");
      }
    };
    void check();
  }, []);

  const frame = Math.round((timeMs / 1000) * timeline.fps);

  return (
    <div className="space-y-4">
      <div className="rounded-3xl border border-white/10 bg-white/[0.04] p-4">
        <div className="mx-auto w-full max-w-[340px]">
          <canvas
            ref={canvasRef}
            width={renderer.width}
            height={renderer.height}
            className="w-full rounded-2xl border border-white/10 shadow-[0_18px_50px_rgba(0,0,0,0.5)]"
          />
        </div>

        <div className="mt-4 space-y-3">
          <input
            type="range"
            min={0}
            max={timeline.totalMs}
            step={33}
            value={Math.round(timeMs)}
            onChange={(event) => seek(Number(event.target.value))}
            className="w-full accent-orange-400"
          />
          <div className="flex h-2 w-full overflow-hidden rounded-full border border-white/10">
            {timeline.segments.map((segment, index) => (
              <div
                key={`${segment.kind}-${index}`}
                title={`${segment.label} · ${formatTime(segment.endMs - segment.startMs)}`}
                className={SEGMENT_COLORS[segment.kind] ?? "bg-slate-500"}
                style={{
                  width: `${((segment.endMs - segment.startMs) / timeline.totalMs) * 100}%`,
                }}
              />
            ))}
          </div>
          <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400">
            <button
              type="button"
              onClick={togglePlay}
              className="rounded-lg bg-gradient-to-r from-orange-400 to-rose-500 px-4 py-2 text-sm font-bold text-white"
            >
              {playing ? "Pause" : "Play"}
            </button>
            <button
              type="button"
              onClick={() => seek(0)}
              className="rounded-lg border border-white/15 bg-white/5 px-3 py-2 font-semibold text-slate-100"
            >
              ↺ Hook
            </button>
            <button
              type="button"
              onClick={() => seek(timeline.inkEndMs)}
              className="rounded-lg border border-white/15 bg-white/5 px-3 py-2 font-semibold text-slate-100"
            >
              Reveal
            </button>
            <button
              type="button"
              onClick={() => {
                setVoiceOn((value) => !value);
                if (typeof window !== "undefined" && "speechSynthesis" in window) {
                  window.speechSynthesis.cancel();
                }
              }}
              className={`rounded-lg border px-3 py-2 font-semibold ${
                voiceOn
                  ? "border-emerald-400/40 bg-emerald-400/10 text-emerald-200"
                  : "border-white/15 bg-white/5 text-slate-400"
              }`}
            >
              {voiceOn ? "Voice ON" : "Voice OFF"}
            </button>
            <span className="font-mono">
              {formatTime(timeMs)} / {formatTime(timeline.totalMs)} · frame {frame}/
              {timeline.frameCount}
            </span>
          </div>
        </div>
      </div>

      <div className="rounded-3xl border border-white/10 bg-white/[0.04] p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-semibold text-white">Export final.mp4</h3>
            <p className="mt-1 text-xs text-slate-400">
              1080×1920 · {timeline.fps} fps · H.264 · frame-exact từ cùng renderer
              với preview.
            </p>
          </div>
          <button
            type="button"
            onClick={() => void runExport()}
            disabled={exporting}
            className="rounded-xl bg-white px-5 py-2.5 text-sm font-bold text-slate-900 transition hover:bg-slate-200 disabled:opacity-60"
          >
            {exporting ? "Đang render…" : "Export MP4"}
          </button>
        </div>

        {progress ? (
          <div className="mt-4">
            <div className="h-2 overflow-hidden rounded-full bg-white/10">
              <div
                className="h-full bg-gradient-to-r from-orange-400 to-rose-500 transition-all"
                style={{ width: `${Math.round(progress.value * 100)}%` }}
              />
            </div>
            <p className="mt-2 text-xs text-slate-400">{progress.stage}</p>
          </div>
        ) : null}

        {result ? (
          <p className="mt-4 rounded-xl border border-emerald-400/30 bg-emerald-400/10 px-3 py-2 font-mono text-[11px] text-emerald-200">
            {result}
          </p>
        ) : null}

        {voiceNote ? (
          <p className="mt-3 text-[11px] text-slate-500">{voiceNote}</p>
        ) : null}
      </div>
    </div>
  );
}
