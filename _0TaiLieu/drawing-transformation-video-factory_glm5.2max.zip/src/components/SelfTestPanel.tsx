"use client";

import { useState } from "react";

type SelfTest = {
  ok: boolean;
  registry: { glyphs: number; subjects: number };
  transformations: number;
  combinations: number;
  passRate: number;
  durationMs: number;
  failures: Array<{ slug: string; variant: string; errors: string[] }>;
  byCategory: Array<{ category: string; count: number }>;
};

export function SelfTestPanel() {
  const [result, setResult] = useState<SelfTest | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const run = async () => {
    setBusy(true);
    setError(null);
    try {
      const response = await fetch("/api/selftest", { cache: "no-store" });
      setResult((await response.json()) as SelfTest);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Lỗi self-test");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="rounded-3xl border border-white/10 bg-white/[0.04] p-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h3 className="text-base font-semibold text-white">Pipeline self-test</h3>
          <p className="mt-1 text-sm text-slate-400">
            Sinh plan + validate cho toàn bộ library × 3 variants.
          </p>
        </div>
        <button
          type="button"
          onClick={() => void run()}
          disabled={busy}
          className="rounded-xl border border-white/15 bg-white/5 px-4 py-2 text-sm font-semibold text-slate-100 transition hover:border-orange-400/50 disabled:opacity-50"
        >
          {busy ? "Đang chạy…" : "Chạy self-test"}
        </button>
      </div>

      {error ? <p className="mt-4 text-sm text-rose-300">{error}</p> : null}

      {result ? (
        <div className="mt-5 space-y-4">
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            {[
              { label: "Transformations", value: result.transformations },
              { label: "Combinations", value: result.combinations },
              { label: "Pass rate", value: `${result.passRate}%` },
              { label: "Thời gian test", value: `${result.durationMs}ms` },
            ].map((item) => (
              <div
                key={item.label}
                className="rounded-2xl border border-white/10 bg-[#0f1219] p-3"
              >
                <p className="text-[11px] uppercase tracking-wider text-slate-500">
                  {item.label}
                </p>
                <p className="mt-1 text-xl font-bold text-white">{item.value}</p>
              </div>
            ))}
          </div>
          <div className="flex flex-wrap gap-2">
            {result.byCategory.map((item) => (
              <span
                key={item.category}
                className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-slate-300"
              >
                {item.category}: {item.count}
              </span>
            ))}
            <span className="rounded-full border border-white/10 bg-white/5 px-3 py-1 text-xs text-slate-300">
              registry: {result.registry.glyphs} glyphs / {result.registry.subjects} subjects
            </span>
          </div>
          {result.failures.length > 0 ? (
            <ul className="space-y-1 text-xs text-rose-300">
              {result.failures.slice(0, 6).map((failure) => (
                <li key={`${failure.slug}-${failure.variant}`}>
                  {failure.slug} [{failure.variant}] → {failure.errors.join(", ")}
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-sm font-semibold text-emerald-300">
              ✓ Toàn bộ transformation sinh drawing plan hợp lệ.
            </p>
          )}
        </div>
      ) : null}
    </div>
  );
}
