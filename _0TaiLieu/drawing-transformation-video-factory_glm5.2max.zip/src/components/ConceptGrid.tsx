"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import type { TransformationRecord } from "@/lib/library/transformations";

const CATEGORY_LABEL: Record<string, string> = {
  number: "số",
  letter: "chữ",
  symbol: "ký hiệu",
  geometry: "hình học",
  combination: "kết hợp",
};

export function ConceptGrid({ items }: { items: TransformationRecord[] }) {
  const router = useRouter();
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const generate = async (slug: string) => {
    setBusy(slug);
    setError(null);
    try {
      const response = await fetch("/api/projects", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ slug, seed: 12345, variant: "curious" }),
      });
      const data = (await response.json()) as { ok: boolean; projectId?: number; error?: string };
      if (!data.ok || !data.projectId) {
        setError(data.error ?? "Không tạo được project");
        setBusy(null);
        return;
      }
      router.push(`/studio/${data.projectId}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Lỗi mạng");
      setBusy(null);
    }
  };

  if (items.length === 0) {
    return (
      <p className="rounded-2xl border border-white/10 bg-white/[0.03] p-6 text-sm text-slate-400">
        Không có transformation nào trong category này.
      </p>
    );
  }

  return (
    <div className="space-y-4">
      {error ? (
        <p className="rounded-xl border border-rose-500/30 bg-rose-500/10 px-4 py-2 text-sm text-rose-200">
          {error}
        </p>
      ) : null}
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
        {items.map((item) => (
          <article
            key={item.slug}
            className="flex flex-col rounded-3xl border border-white/10 bg-white/[0.04] p-5 transition hover:border-orange-400/40"
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <span className="grid h-12 w-12 place-items-center rounded-2xl border border-white/10 bg-[#0f1219] text-lg font-black text-orange-300">
                  {item.hook}
                </span>
                <div>
                  <p className="text-base font-bold text-white">{item.subject}</p>
                  <p className="text-[11px] uppercase tracking-wider text-slate-500">
                    {CATEGORY_LABEL[item.hookCategory] ?? item.hookCategory}
                  </p>
                </div>
              </div>
              <span className="rounded-full border border-white/10 bg-white/5 px-2.5 py-1 text-[11px] font-bold text-slate-200">
                {item.scores.total}/10
              </span>
            </div>

            <p className="mt-3 line-clamp-2 text-xs text-slate-400">“{item.hookVoice}”</p>

            <dl className="mt-3 grid grid-cols-3 gap-2 text-[11px]">
              {(
                [
                  ["curiosity", item.scores.curiosity],
                  ["feasible", item.scores.feasibility],
                  ["retention", item.scores.retention],
                ] as Array<[string, number]>
              ).map(([key, value]) => (
                <div key={key} className="rounded-xl border border-white/10 bg-[#0f1219] p-2">
                  <dt className="text-slate-500">{key}</dt>
                  <dd className="text-sm font-bold text-white">{value}</dd>
                </div>
              ))}
            </dl>

            <div className="mt-3 flex flex-wrap gap-1.5">
              {item.tags.map((tag) => (
                <span
                  key={tag}
                  className="rounded-full border border-white/10 bg-white/5 px-2 py-0.5 text-[10px] text-slate-400"
                >
                  {tag}
                </span>
              ))}
            </div>

            <button
              type="button"
              onClick={() => void generate(item.slug)}
              disabled={busy !== null}
              className="mt-4 rounded-xl bg-gradient-to-r from-orange-400 to-rose-500 px-4 py-2.5 text-xs font-bold text-white transition hover:brightness-110 disabled:opacity-60"
            >
              {busy === item.slug ? "Đang tạo plan…" : "Generate video"}
            </button>
          </article>
        ))}
      </div>
    </div>
  );
}
