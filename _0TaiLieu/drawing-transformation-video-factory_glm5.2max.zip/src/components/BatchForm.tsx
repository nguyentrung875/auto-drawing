"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { CATEGORIES } from "@/lib/library/transformations";
import { VARIANTS } from "@/lib/engine/types";

export function BatchForm() {
  const router = useRouter();
  const [name, setName] = useState("Cute animals · tuần này");
  const [size, setSize] = useState(20);
  const [category, setCategory] = useState("all");
  const [seed, setSeed] = useState(12345);
  const [variant, setVariant] = useState("curious");
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState<string | null>(null);

  const submit = async () => {
    setBusy(true);
    setStatus("Đang sinh batch: concept → plan → validate…");
    try {
      const response = await fetch("/api/batches", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, size, category, seed, variant }),
      });
      const data = (await response.json()) as {
        ok: boolean;
        batchId?: number;
        sizeCreated?: number;
        error?: string;
      };
      if (!data.ok || !data.batchId) {
        setStatus(data.error ?? "Không tạo được batch");
        setBusy(false);
        return;
      }
      router.push(`/batches/${data.batchId}`);
    } catch (error) {
      setStatus(error instanceof Error ? error.message : "Lỗi mạng");
      setBusy(false);
    }
  };

  return (
    <div className="rounded-3xl border border-white/10 bg-white/[0.04] p-6">
      <h2 className="text-base font-semibold text-white">Batch production</h2>
      <p className="mt-1 text-sm text-slate-400">
        Sinh nhiều project trong một request. Mỗi project được validate riêng —
        chỉ những project đạt mới đáng để review.
      </p>
      <div className="mt-5 grid gap-3 sm:grid-cols-2">
        <label className="sm:col-span-2">
          <span className="mb-1 block text-[11px] uppercase tracking-wider text-slate-500">
            Tên batch
          </span>
          <input
            value={name}
            onChange={(event) => setName(event.target.value)}
            className="w-full rounded-xl border border-white/10 bg-[#0f1219] px-3 py-2.5 text-sm text-white"
          />
        </label>
        <label>
          <span className="mb-1 block text-[11px] uppercase tracking-wider text-slate-500">
            Số video (1–100)
          </span>
          <input
            type="number"
            min={1}
            max={100}
            value={size}
            onChange={(event) => setSize(Number(event.target.value))}
            className="w-full rounded-xl border border-white/10 bg-[#0f1219] px-3 py-2.5 text-sm text-white"
          />
        </label>
        <label>
          <span className="mb-1 block text-[11px] uppercase tracking-wider text-slate-500">
            Category
          </span>
          <select
            value={category}
            onChange={(event) => setCategory(event.target.value)}
            className="w-full rounded-xl border border-white/10 bg-[#0f1219] px-3 py-2.5 text-sm text-white"
          >
            {CATEGORIES.map((item) => (
              <option key={item.key} value={item.key}>
                {item.label}
              </option>
            ))}
          </select>
        </label>
        <label>
          <span className="mb-1 block text-[11px] uppercase tracking-wider text-slate-500">
            Seed
          </span>
          <input
            type="number"
            value={seed}
            onChange={(event) => setSeed(Number(event.target.value))}
            className="w-full rounded-xl border border-white/10 bg-[#0f1219] px-3 py-2.5 text-sm text-white"
          />
        </label>
        <label>
          <span className="mb-1 block text-[11px] uppercase tracking-wider text-slate-500">
            Variant
          </span>
          <select
            value={variant}
            onChange={(event) => setVariant(event.target.value)}
            className="w-full rounded-xl border border-white/10 bg-[#0f1219] px-3 py-2.5 text-sm text-white"
          >
            {VARIANTS.map((item) => (
              <option key={item.key} value={item.key}>
                {item.label}
              </option>
            ))}
          </select>
        </label>
      </div>
      <button
        type="button"
        onClick={() => void submit()}
        disabled={busy}
        className="mt-5 w-full rounded-xl bg-gradient-to-r from-orange-400 to-rose-500 px-5 py-3 text-sm font-bold text-white transition hover:brightness-110 disabled:opacity-60"
      >
        {busy ? "Đang chạy batch…" : `Generate ${size} projects`}
      </button>
      {status ? <p className="mt-3 text-xs text-slate-400">{status}</p> : null}
    </div>
  );
}
