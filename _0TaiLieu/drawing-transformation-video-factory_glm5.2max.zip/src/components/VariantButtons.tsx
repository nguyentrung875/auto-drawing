"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { VARIANTS } from "@/lib/engine/types";

export function VariantButtons({
  slug,
  seed,
  activeVariant,
  cta,
}: {
  slug: string;
  seed: number;
  activeVariant: string;
  cta: string;
}) {
  const router = useRouter();
  const [busy, setBusy] = useState<string | null>(null);

  const create = async (variant: string) => {
    setBusy(variant);
    try {
      const response = await fetch("/api/projects", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ slug, seed, variant, cta }),
      });
      const data = (await response.json()) as { ok: boolean; projectId?: number };
      if (data.ok && data.projectId) {
        router.push(`/studio/${data.projectId}`);
      }
    } finally {
      setBusy(null);
    }
  };

  return (
    <div className="flex flex-wrap gap-2">
      {VARIANTS.map((variant) => (
        <button
          key={variant.key}
          type="button"
          title={variant.description}
          onClick={() => void create(variant.key)}
          disabled={busy !== null}
          className={`rounded-lg border px-3 py-1.5 text-xs font-semibold transition disabled:opacity-50 ${
            variant.key === activeVariant
              ? "border-orange-400/60 bg-orange-400/15 text-orange-200"
              : "border-white/15 bg-white/5 text-slate-300 hover:border-orange-400/40"
          }`}
        >
          {busy === variant.key ? "…" : variant.label}
        </button>
      ))}
    </div>
  );
}
