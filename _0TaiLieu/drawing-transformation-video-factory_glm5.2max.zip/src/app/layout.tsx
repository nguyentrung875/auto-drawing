import type { Metadata } from "next";
import type { ReactNode } from "react";
import Link from "next/link";
import "./globals.css";

export const metadata: Metadata = {
  title: "Drawing Transformation Video Factory",
  description:
    "Biến hook đơn giản (số, chữ, ký hiệu) thành video short-form có quá trình vẽ xác định — tự động và lặp lại được.",
};

const NAV = [
  { href: "/", label: "Dashboard" },
  { href: "/concepts", label: "Transformation Library" },
  { href: "/batches", label: "Batch Factory" },
  { href: "/analytics", label: "Performance" },
];

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="vi">
      <body className="min-h-screen bg-[#0b0d12] text-slate-100 antialiased">
        <div className="pointer-events-none fixed inset-0 bg-[radial-gradient(circle_at_20%_0%,rgba(239,106,60,0.16),transparent_55%),radial-gradient(circle_at_85%_10%,rgba(56,189,248,0.12),transparent_50%)]" />
        <div className="relative">
          <header className="border-b border-white/10 bg-[#0b0d12]/80 backdrop-blur">
            <div className="mx-auto flex max-w-7xl flex-wrap items-center gap-x-8 gap-y-3 px-6 py-4">
              <Link href="/" className="flex items-center gap-3">
                <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-orange-400 to-rose-500 text-lg font-black text-white">
                  8
                </span>
                <span className="text-sm font-semibold uppercase tracking-[0.22em] text-slate-200">
                  Drawing Factory
                </span>
              </Link>
              <nav className="flex flex-wrap items-center gap-1 text-sm">
                {NAV.map((item) => (
                  <Link
                    key={item.href}
                    href={item.href}
                    className="rounded-lg px-3 py-1.5 text-slate-300 transition hover:bg-white/10 hover:text-white"
                  >
                    {item.label}
                  </Link>
                ))}
              </nav>
              <span className="ml-auto hidden rounded-full border border-emerald-400/30 bg-emerald-400/10 px-3 py-1 text-xs font-semibold text-emerald-300 md:block">
                deterministic drawing · vi voice · 1080×1920
              </span>
            </div>
          </header>
          {children}
          <footer className="mx-auto max-w-7xl px-6 py-10 text-xs text-slate-500">
            Transformation → Drawing Definition → Validated Drawing → Rendered
            Video. AI tạo ý tưởng, drawing system quyết định nét vẽ, renderer
            quyết định cách trình bày.
          </footer>
        </div>
      </body>
    </html>
  );
}
