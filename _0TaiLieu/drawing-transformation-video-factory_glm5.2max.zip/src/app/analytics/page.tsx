import Link from "next/link";
import { getFactoryStats, listPerformance } from "@/lib/server/projects";
import { TRANSFORMATIONS } from "@/lib/library/transformations";

export const dynamic = "force-dynamic";

const QUESTIONS = [
  "Transformation dạng số/chữ có tạo retention tốt hơn hook khác không?",
  "Video bao nhiêu giây có completion rate tốt nhất?",
  "Voice tiếng Việt có làm tăng retention không?",
  "Người xem thích tốc độ vẽ nhanh hay chậm?",
  "Reveal nên xảy ra ở giây thứ bao nhiêu?",
  "CTA có làm giảm completion rate không?",
  "Loại transformation nào tạo nhiều replay nhất?",
  "Transformation nào gắn được với affiliate tốt nhất?",
];

export default async function AnalyticsPage() {
  const [stats, performance] = await Promise.all([
    getFactoryStats(),
    listPerformance(20),
  ]);
  const top = [...TRANSFORMATIONS].sort((a, b) => b.scores.total - a.scores.total).slice(0, 10);
  const totalViews = performance.reduce((acc, row) => acc + row.metrics.views, 0);
  const totalConversions = performance.reduce((acc, row) => acc + row.metrics.conversions, 0);

  return (
    <main className="mx-auto max-w-7xl px-6 py-10">
      <p className="text-xs font-semibold uppercase tracking-[0.3em] text-orange-300">
        Measurable content
      </p>
      <h1 className="mt-3 text-3xl font-black text-white">Performance & learning loop</h1>
      <p className="mt-2 max-w-2xl text-sm text-slate-400">
        Watch-through potential là <span className="text-white">hypothesis</span>, không
        phải lời hứa kỹ thuật. Số liệu thực tế mới quyết định concept nào nên
        tạo tiếp.
      </p>

      <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
        {[
          { label: "Generation success", value: `${stats.validationPassRate}%` },
          { label: "Render fail", value: `${stats.projects === 0 ? 0 : Math.round((stats.invalid / stats.projects) * 100)}%` },
          { label: "Avg duration", value: `${(stats.avgDurationMs / 1000).toFixed(1)}s` },
          { label: "Avg cost / video", value: `$${stats.avgCostUsd.toFixed(5)}` },
          { label: "Views đã ghi", value: totalViews.toLocaleString("vi-VN") },
          { label: "Conversions", value: String(totalConversions) },
        ].map((item) => (
          <div
            key={item.label}
            className="rounded-2xl border border-white/10 bg-white/[0.04] p-4"
          >
            <p className="text-[11px] uppercase tracking-wider text-slate-500">
              {item.label}
            </p>
            <p className="mt-1 text-2xl font-black text-white">{item.value}</p>
          </div>
        ))}
      </div>

      <section className="mt-8 grid gap-6 lg:grid-cols-[1.4fr_1fr]">
        <div className="overflow-hidden rounded-3xl border border-white/10 bg-white/[0.04]">
          <div className="px-5 py-4">
            <h2 className="text-sm font-semibold text-white">
              Concept → Video → Performance
            </h2>
            <p className="mt-1 text-xs text-slate-500">
              {performance.length} project đã có số liệu. Nhập số liệu trong trang
              studio của từng project.
            </p>
          </div>
          {performance.length === 0 ? (
            <p className="px-5 pb-6 text-sm text-slate-400">
              Chưa có performance data. Xuất bản vài video rồi quay lại đây.
            </p>
          ) : (
            <table className="w-full text-left text-sm">
              <thead className="bg-white/5 text-[11px] uppercase tracking-wider text-slate-400">
                <tr>
                  <th className="px-4 py-3">Concept</th>
                  <th className="px-4 py-3">Views</th>
                  <th className="px-4 py-3">3s</th>
                  <th className="px-4 py-3">Complete</th>
                  <th className="px-4 py-3">CTR</th>
                  <th className="px-4 py-3">Platform</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {performance.map((row) => (
                  <tr key={row.metrics.id} className="hover:bg-white/[0.03]">
                    <td className="px-4 py-3">
                      <Link
                        href={`/studio/${row.projectId}`}
                        className="text-xs font-semibold text-white hover:text-orange-300"
                      >
                        <span className="text-orange-300">{row.hook}</span> → {row.subject}
                      </Link>
                      <span className="ml-2 text-[11px] text-slate-500">
                        {row.variant} · seed {row.seed}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-xs text-slate-300">
                      {row.metrics.views.toLocaleString("vi-VN")}
                    </td>
                    <td className="px-4 py-3 text-xs text-slate-300">
                      {row.metrics.retention3s}%
                    </td>
                    <td className="px-4 py-3 text-xs text-slate-300">
                      {row.metrics.completionRate}%
                    </td>
                    <td className="px-4 py-3 text-xs text-slate-300">{row.metrics.ctr}%</td>
                    <td className="px-4 py-3 text-xs text-slate-500">
                      {row.metrics.platform}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        <div className="space-y-6">
          <div className="rounded-3xl border border-white/10 bg-white/[0.04] p-5">
            <h2 className="text-sm font-semibold text-white">
              Concept ranking (hypothesis)
            </h2>
            <ol className="mt-3 space-y-2">
              {top.map((item, index) => (
                <li key={item.slug} className="flex items-center gap-3 text-xs">
                  <span className="w-5 text-slate-500">{index + 1}</span>
                  <span className="flex-1 text-slate-200">
                    <span className="font-bold text-orange-300">{item.hook}</span> →{" "}
                    {item.subject}
                  </span>
                  <span className="font-mono text-slate-400">{item.scores.total}</span>
                </li>
              ))}
            </ol>
          </div>

          <div className="rounded-3xl border border-white/10 bg-white/[0.04] p-5">
            <h2 className="text-sm font-semibold text-white">Open questions</h2>
            <ul className="mt-3 space-y-2 text-xs text-slate-400">
              {QUESTIONS.map((question) => (
                <li key={question} className="flex gap-2">
                  <span className="text-orange-400">?</span>
                  <span>{question}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>
    </main>
  );
}
