import { NextResponse } from "next/server";
import { TRANSFORMATIONS } from "@/lib/library/transformations";
import { registrySize } from "@/lib/registry";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const category = url.searchParams.get("category");
  const rows = TRANSFORMATIONS.filter(
    (t) => !category || category === "all" || t.hookCategory === category,
  );
  return NextResponse.json({
    ok: true,
    registry: registrySize(),
    total: TRANSFORMATIONS.length,
    transformations: rows,
  });
}
