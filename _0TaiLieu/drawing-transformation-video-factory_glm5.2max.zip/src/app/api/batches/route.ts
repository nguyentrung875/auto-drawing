import { NextResponse } from "next/server";
import { createBatch, listBatches } from "@/lib/server/projects";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await listBatches();
  return NextResponse.json({ ok: true, batches: rows });
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as {
      name?: string;
      size?: number;
      category?: string;
      seed?: number;
      variant?: string;
    };
    const size = Number(body.size ?? 10);
    if (!Number.isFinite(size) || size < 1) {
      return NextResponse.json({ ok: false, error: "size không hợp lệ" }, { status: 400 });
    }
    const result = await createBatch({
      name: body.name?.trim() || `Batch ${new Date().toISOString().slice(0, 16)}`,
      size,
      category: body.category ?? "all",
      seed: body.seed,
      variant: body.variant ?? "curious",
    });
    return NextResponse.json({
      ok: true,
      batchId: result.batch.id,
      sizeCreated: result.batch.sizeCreated,
      items: result.items.map((item) => ({
        hook: item.hook,
        subject: item.subject,
        status: item.status,
      })),
    });
  } catch (error) {
    return NextResponse.json(
      { ok: false, error: error instanceof Error ? error.message : "Lỗi batch" },
      { status: 400 },
    );
  }
}
