import { NextResponse } from "next/server";
import { getProject } from "@/lib/server/projects";

export const dynamic = "force-dynamic";

export async function GET(
  _request: Request,
  context: { params: Promise<{ id: string }> },
) {
  const { id } = await context.params;
  const projectId = Number(id);
  if (!Number.isFinite(projectId)) {
    return NextResponse.json({ ok: false, error: "id không hợp lệ" }, { status: 400 });
  }
  const row = await getProject(projectId);
  if (!row) {
    return NextResponse.json({ ok: false, error: "Không tìm thấy project" }, { status: 404 });
  }
  return NextResponse.json({ ok: true, project: row });
}
