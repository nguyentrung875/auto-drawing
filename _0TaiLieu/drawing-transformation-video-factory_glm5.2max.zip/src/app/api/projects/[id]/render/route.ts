import { NextResponse } from "next/server";
import { getProject, recordRender, updateProjectPoster } from "@/lib/server/projects";

export const dynamic = "force-dynamic";

/** Observability endpoint (NFR-005): every export is logged with cost + duration. */
export async function POST(
  request: Request,
  context: { params: Promise<{ id: string }> },
) {
  const { id } = await context.params;
  const projectId = Number(id);
  if (!Number.isFinite(projectId)) {
    return NextResponse.json({ ok: false, error: "id không hợp lệ" }, { status: 400 });
  }
  const existing = await getProject(projectId);
  if (!existing) {
    return NextResponse.json({ ok: false, error: "Không tìm thấy project" }, { status: 404 });
  }
  try {
    const body = (await request.json()) as {
      format?: string;
      encoder?: string;
      status?: string;
      width?: number;
      height?: number;
      fps?: number;
      durationMs?: number;
      sizeBytes?: number;
      renderMs?: number;
      hasVoice?: boolean;
      notes?: string;
      poster?: string;
    };
    const render = await recordRender({
      projectId,
      format: body.format ?? "mp4",
      encoder: body.encoder ?? "unknown",
      status: body.status ?? "ok",
      width: body.width ?? existing.project.plan.canvas.width,
      height: body.height ?? existing.project.plan.canvas.height,
      fps: body.fps ?? existing.project.timeline.fps,
      durationMs: Math.round(body.durationMs ?? existing.project.timeline.totalMs),
      sizeBytes: Math.round(body.sizeBytes ?? 0),
      renderMs: Math.round(body.renderMs ?? 0),
      hasVoice: body.hasVoice ? 1 : 0,
      notes: body.notes ?? null,
      poster: body.poster ?? null,
    });
    if (body.poster) {
      await updateProjectPoster(projectId, body.poster);
    }
    return NextResponse.json({ ok: true, render });
  } catch (error) {
    return NextResponse.json(
      { ok: false, error: error instanceof Error ? error.message : "Lỗi render log" },
      { status: 400 },
    );
  }
}
