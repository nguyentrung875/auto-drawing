import { NextResponse } from "next/server";
import { createProject, listProjects } from "@/lib/server/projects";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const limit = Number(url.searchParams.get("limit") ?? 40);
  const rows = await listProjects(Number.isFinite(limit) ? limit : 40);
  return NextResponse.json({ ok: true, projects: rows });
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as {
      slug?: string;
      seed?: number;
      variant?: string;
      cta?: string;
    };
    if (!body.slug) {
      return NextResponse.json(
        { ok: false, error: "Thiếu slug / concept input." },
        { status: 400 },
      );
    }
    const created = await createProject({
      slug: body.slug,
      seed: body.seed,
      variant: body.variant,
      cta: body.cta,
    });
    return NextResponse.json({
      ok: true,
      projectId: created.project.id,
      status: created.project.status,
      validation: created.generated.validation,
    });
  } catch (error) {
    return NextResponse.json(
      { ok: false, error: error instanceof Error ? error.message : "Lỗi không xác định" },
      { status: 400 },
    );
  }
}
