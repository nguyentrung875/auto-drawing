import { createHash } from "node:crypto";
import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { voiceAssets } from "@/db/schema";
import { detectProvider, synthesize } from "@/lib/voice/provider";

export const dynamic = "force-dynamic";

/**
 * Voice caching endpoint (NFR-004): same concept + same voice text reuses the
 * same audio instead of paying the provider again.
 */
export async function GET() {
  return NextResponse.json({ ok: true, provider: detectProvider() });
}

export async function POST(request: Request) {
  const body = (await request.json().catch(() => ({}))) as {
    text?: string;
    voice?: string;
  };
  const text = (body.text ?? "").trim();
  if (!text) {
    return NextResponse.json({ ok: false, error: "Thiếu text" }, { status: 400 });
  }
  const info = detectProvider();
  if (!info.configurable) {
    return NextResponse.json(
      {
        ok: false,
        reason: "no-provider",
        provider: info,
        message:
          "Chưa cấu hình TTS provider. Preview sẽ dùng SpeechSynthesis của trình duyệt (vi-VN).",
      },
      { status: 501 },
    );
  }

  const cacheKey = createHash("sha256")
    .update(`${info.key}:${info.voice}:${text}`)
    .digest("hex");

  const cached = await db
    .select()
    .from(voiceAssets)
    .where(eq(voiceAssets.cacheKey, cacheKey))
    .limit(1);
  if (cached.length > 0) {
    return NextResponse.json({
      ok: true,
      cached: true,
      mimeType: cached[0].mimeType,
      audioBase64: cached[0].audioBase64,
    });
  }

  const result = await synthesize(text, info);
  if (!result) {
    return NextResponse.json(
      { ok: false, error: "Provider trả về lỗi", provider: info },
      { status: 502 },
    );
  }
  const audioBase64 = Buffer.from(result.audio).toString("base64");
  await db
    .insert(voiceAssets)
    .values({
      cacheKey,
      provider: info.key,
      voice: info.voice,
      text,
      mimeType: result.mimeType,
      audioBase64,
      bytes: audioBase64.length,
    })
    .onConflictDoNothing();

  return NextResponse.json({
    ok: true,
    cached: false,
    mimeType: result.mimeType,
    audioBase64,
  });
}
