import { NextResponse } from "next/server";
import { generateProject } from "@/lib/engine";
import { TRANSFORMATIONS } from "@/lib/library/transformations";
import { registrySize } from "@/lib/registry";
import { VARIANTS } from "@/lib/engine/types";

export const dynamic = "force-dynamic";

/**
 * Registry + pipeline self-test. Proves that every library transformation can
 * be planned, validated and timed without touching a renderer.
 */
export async function GET() {
  const started = Date.now();
  const rows: Array<{
    slug: string;
    title: string;
    category: string;
    variant: string;
    pass: boolean;
    steps: number;
    strokes: number;
    durationMs: number;
    errors: string[];
    warnings: number;
    score: number;
  }> = [];

  for (const transformation of TRANSFORMATIONS) {
    for (const variant of VARIANTS) {
      const generated = generateProject(transformation, {
        seed: 12345,
        variant: variant.key,
      });
      rows.push({
        slug: transformation.slug,
        title: transformation.title,
        category: transformation.hookCategory,
        variant: variant.key,
        pass: generated.validation.pass,
        steps: generated.plan.steps.length,
        strokes: generated.plan.strokeCount,
        durationMs: generated.timeline.totalMs,
        errors: generated.validation.errors.map((e) => e.code),
        warnings: generated.validation.warnings.length,
        score: transformation.scores.total,
      });
    }
  }

  const failures = rows.filter((r) => !r.pass);
  return NextResponse.json({
    ok: failures.length === 0,
    registry: registrySize(),
    transformations: TRANSFORMATIONS.length,
    combinations: rows.length,
    passRate:
      rows.length === 0
        ? 0
        : Math.round(((rows.length - failures.length) / rows.length) * 1000) / 10,
    durationMs: Date.now() - started,
    failures,
    sample: rows.slice(0, 12),
    byCategory: Object.entries(
      rows.reduce<Record<string, number>>((acc, row) => {
        acc[row.category] = (acc[row.category] ?? 0) + 1;
        return acc;
      }, {}),
    ).map(([category, count]) => ({ category, count: count / VARIANTS.length })),
  });
}
