import { NextResponse } from "next/server";
import { listPerformance, upsertMetrics } from "@/lib/server/projects";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await listPerformance();
  return NextResponse.json({ ok: true, metrics: rows });
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as Record<string, unknown>;
    const projectId = Number(body.projectId);
    if (!Number.isFinite(projectId)) {
      return NextResponse.json({ ok: false, error: "projectId không hợp lệ" }, { status: 400 });
    }
    const num = (key: string, fallback = 0) => {
      const value = Number(body[key]);
      return Number.isFinite(value) ? value : fallback;
    };
    const row = await upsertMetrics({
      projectId,
      platform: String(body.platform ?? "tiktok"),
      views: Math.round(num("views")),
      retention3s: num("retention3s"),
      avgWatchMs: Math.round(num("avgWatchMs")),
      completionRate: num("completionRate"),
      replayRate: num("replayRate"),
      shareRate: num("shareRate"),
      saveRate: num("saveRate"),
      ctr: num("ctr"),
      conversions: Math.round(num("conversions")),
      revenueMicros: Math.round(num("revenueMicros")),
      notes: body.notes ? String(body.notes) : null,
    });
    return NextResponse.json({ ok: true, metrics: row });
  } catch (error) {
    return NextResponse.json(
      { ok: false, error: error instanceof Error ? error.message : "Lỗi metrics" },
      { status: 400 },
    );
  }
}
