import Link from "next/link";
import { ConceptGrid } from "@/components/ConceptGrid";
import { CATEGORIES, TRANSFORMATIONS } from "@/lib/library/transformations";
import { registrySize } from "@/lib/registry";

export const dynamic = "force-dynamic";

export default async function ConceptsPage({
  searchParams,
}: {
  searchParams: Promise<{ category?: string }>;
}) {
  const { category } = await searchParams;
  const active = category ?? "all";
  const items = TRANSFORMATIONS.filter(
    (item) => active === "all" || item.hookCategory === active,
  );
  const registry = registrySize();

  return (
    <main className="mx-auto max-w-7xl px-6 py-10">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.3em] text-orange-300">
            Registry-first
          </p>
          <h1 className="mt-3 text-3xl font-black text-white">Transformation Library</h1>
          <p className="mt-2 max-w-2xl text-sm text-slate-400">
            {TRANSFORMATIONS.length} transformation từ {registry.glyphs} glyph và{" "}
            {registry.subjects} subject component. Concept chỉ được tham chiếu tới
            component tồn tại trong registry — LLM không tự sinh SVG.
          </p>
        </div>
        <Link
          href="/batches"
          className="rounded-xl border border-white/15 bg-white/5 px-4 py-2 text-xs font-semibold text-slate-100 hover:border-orange-400/50"
        >
          Batch production →
        </Link>
      </div>

      <nav className="mt-6 flex flex-wrap gap-2">
        {CATEGORIES.map((item) => {
          const count =
            item.key === "all"
              ? TRANSFORMATIONS.length
              : TRANSFORMATIONS.filter((t) => t.hookCategory === item.key).length;
          const isActive = active === item.key;
          return (
            <Link
              key={item.key}
              href={item.key === "all" ? "/concepts" : `/concepts?category=${item.key}`}
              className={`rounded-full border px-4 py-1.5 text-xs font-semibold transition ${
                isActive
                  ? "border-orange-400/60 bg-orange-400/15 text-orange-200"
                  : "border-white/10 bg-white/5 text-slate-300 hover:border-orange-400/40"
              }`}
            >
              {item.label}
              <span className="ml-2 text-slate-500">{count}</span>
            </Link>
          );
        })}
      </nav>

      <div className="mt-6">
        <ConceptGrid items={items} />
      </div>
    </main>
  );
}
