import Link from "next/link";
import { notFound } from "next/navigation";
import { DrawStage } from "@/components/DrawStage";
import { MetricsForm } from "@/components/MetricsForm";
import { VariantButtons } from "@/components/VariantButtons";
import { getProject } from "@/lib/server/projects";

export const dynamic = "force-dynamic";

export default async function StudioPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const projectId = Number(id);
  if (!Number.isFinite(projectId)) notFound();
  const data = await getProject(projectId);
  if (!data) notFound();

  const { project, transformation, renders, metrics } = data;
  const { plan, timeline, validation, voiceCues, cost } = project;

  return (
    <main className="mx-auto max-w-7xl px-6 py-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <Link href="/concepts" className="text-xs text-slate-400 hover:text-orange-300">
            ← Transformation library
          </Link>
          <h1 className="mt-2 text-3xl font-black text-white">
            <span className="text-orange-300">{transformation.hook}</span> →{" "}
            {transformation.subject}
          </h1>
          <p className="mt-1 text-sm text-slate-400">
            {transformation.hookLabel} · {transformation.style} · {transformation.language} ·
            project #{project.id} · seed {project.seed} · v{project.version} · variant{" "}
            {project.variant}
          </p>
        </div>
        <div className="flex flex-col items-end gap-2">
          <span
            className={`rounded-full px-4 py-1.5 text-xs font-bold ${
              validation.pass
                ? "border border-emerald-400/30 bg-emerald-400/10 text-emerald-300"
                : "border border-rose-400/30 bg-rose-400/10 text-rose-300"
            }`}
          >
            {validation.pass ? "VALIDATED · production ready" : "INVALID · blocked"}
          </span>
          <VariantButtons
            slug={transformation.slug}
            seed={project.seed}
            activeVariant={project.variant}
            cta={transformation.cta}
          />
        </div>
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-[minmax(0,420px)_1fr]">
        <DrawStage
          projectId={project.id}
          plan={plan}
          timeline={timeline}
          ctaText={transformation.cta}
          variant={project.variant}
        />

        <div className="space-y-6">
          {/* validation */}
          <section className="rounded-3xl border border-white/10 bg-white/[0.04] p-5">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-semibold text-white">
                Quality gate · FR-005 / FR-017
              </h2>
              <span className="font-mono text-xs text-slate-400">
                {validation.checks.filter((c) => c.pass).length}/{validation.checks.length} checks
              </span>
            </div>
            <ul className="mt-4 grid gap-2 sm:grid-cols-2">
              {validation.checks.map((check) => (
                <li
                  key={check.id}
                  className={`rounded-xl border px-3 py-2 text-xs ${
                    check.pass
                      ? "border-emerald-400/20 bg-emerald-400/5 text-emerald-100"
                      : "border-rose-400/30 bg-rose-400/10 text-rose-100"
                  }`}
                >
                  <span className="font-semibold">
                    {check.pass ? "✓" : "✕"} {check.label}
                  </span>
                  <span className="mt-0.5 block text-[11px] opacity-70">{check.detail}</span>
                </li>
              ))}
            </ul>
            {validation.warnings.length > 0 ? (
              <ul className="mt-3 space-y-1 text-[11px] text-amber-200">
                {validation.warnings.map((warning) => (
                  <li key={warning.code}>
                    ⚠ {warning.code}: {warning.message}
                  </li>
                ))}
              </ul>
            ) : null}
          </section>

          {/* drawing sequence */}
          <section className="rounded-3xl border border-white/10 bg-white/[0.04] p-5">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-semibold text-white">Drawing sequence</h2>
              <span className="font-mono text-xs text-slate-400">
                {plan.steps.length} steps · {plan.strokeCount} strokes ·{" "}
                {Math.round(plan.inkLength)} px ink
              </span>
            </div>
            <ol className="mt-4 space-y-2">
              {plan.steps.map((step, index) => (
                <li
                  key={step.id}
                  className="rounded-xl border border-white/10 bg-[#0f1219] px-3 py-2"
                >
                  <div className="flex flex-wrap items-center gap-2 text-xs">
                    <span className="grid h-6 w-6 place-items-center rounded-lg bg-orange-400/15 font-bold text-orange-300">
                      {index + 1}
                    </span>
                    <span className="font-semibold text-white">{step.name}</span>
                    <span className="text-slate-500">{step.componentKey}</span>
                    <span className="ml-auto font-mono text-[11px] text-slate-500">
                      {(step.startMs / 1000).toFixed(1)}s →{" "}
                      {((step.startMs + step.durationMs) / 1000).toFixed(1)}s ·{" "}
                      {step.strokes.length} nét
                    </span>
                  </div>
                  {step.voiceLine ? (
                    <p className="mt-1 pl-8 text-[11px] text-slate-400">
                      🎙 “{step.voiceLine}”
                    </p>
                  ) : null}
                </li>
              ))}
            </ol>
          </section>

          {/* timeline + voice */}
          <section className="grid gap-6 md:grid-cols-2">
            <div className="rounded-3xl border border-white/10 bg-white/[0.04] p-5">
              <h2 className="text-sm font-semibold text-white">Timeline</h2>
              <ul className="mt-3 space-y-1.5 text-[11px]">
                {timeline.segments.map((segment, index) => (
                  <li key={index} className="flex items-center justify-between gap-2">
                    <span className="font-mono uppercase text-slate-400">
                      {segment.kind}
                    </span>
                    <span className="flex-1 truncate px-2 text-slate-300">
                      {segment.label}
                    </span>
                    <span className="font-mono text-slate-500">
                      {(segment.startMs / 1000).toFixed(1)}–
                      {(segment.endMs / 1000).toFixed(1)}s
                    </span>
                  </li>
                ))}
              </ul>
              <p className="mt-3 text-[11px] text-slate-500">
                SFX cues: {timeline.sfx.length} · speed{" "}
                {timeline.speedPxPerSec} px/s · {timeline.frameCount} frames
              </p>
            </div>

            <div className="rounded-3xl border border-white/10 bg-white/[0.04] p-5">
              <h2 className="text-sm font-semibold text-white">Voiceover (vi)</h2>
              <ul className="mt-3 space-y-1.5 text-[11px]">
                {voiceCues.map((cue) => (
                  <li key={cue.id} className="flex gap-2">
                    <span className="font-mono text-slate-500">
                      {(cue.startMs / 1000).toFixed(1)}s
                    </span>
                    <span className="text-slate-300">“{cue.text}”</span>
                  </li>
                ))}
              </ul>
              <p className="mt-3 text-[11px] text-slate-500">
                {cost.voiceChars} ký tự · CTA: “{transformation.cta}”
              </p>
            </div>
          </section>

          {/* metadata + render log */}
          <section className="grid gap-6 md:grid-cols-2">
            <div className="rounded-3xl border border-white/10 bg-white/[0.04] p-5">
              <h2 className="text-sm font-semibold text-white">Generation metadata</h2>
              <dl className="mt-3 grid grid-cols-2 gap-y-2 text-[11px]">
                {[
                  ["project", `#${project.id}`],
                  ["transformation", transformation.slug],
                  ["components", plan.components.join(" + ")],
                  ["seed", String(plan.seed)],
                  ["version", `v${plan.version}`],
                  ["variant", plan.variant],
                  ["canvas", `${plan.canvas.width}×${plan.canvas.height}`],
                  ["bounds", `${plan.bounds.minX},${plan.bounds.minY}→${plan.bounds.maxX},${plan.bounds.maxY}`],
                  ["generation", `${project.generationMs} ms`],
                  ["est cost", `$${cost.estCostUsd.toFixed(5)}`],
                  ["created", new Date(project.createdAt).toISOString().slice(0, 19)],
                  ["batch", project.batchId ? `#${project.batchId}` : "—"],
                ].map(([key, value]) => (
                  <div key={key} className="flex flex-col">
                    <dt className="text-slate-500">{key}</dt>
                    <dd className="font-mono text-slate-200">{value}</dd>
                  </div>
                ))}
              </dl>
            </div>

            <div className="rounded-3xl border border-white/10 bg-white/[0.04] p-5">
              <h2 className="text-sm font-semibold text-white">Render log</h2>
              {renders.length === 0 ? (
                <p className="mt-3 text-xs text-slate-400">
                  Chưa có render nào. Bấm “Export MP4” để render và ghi log.
                </p>
              ) : (
                <ul className="mt-3 space-y-2 text-[11px]">
                  {renders.map((render) => (
                    <li
                      key={render.id}
                      className="rounded-xl border border-white/10 bg-[#0f1219] px-3 py-2"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-mono text-slate-300">
                          {render.format.toUpperCase()} · {render.encoder}
                        </span>
                        <span className="text-slate-500">
                          {(render.sizeBytes / 1024 / 1024).toFixed(2)} MB
                        </span>
                      </div>
                      <p className="mt-1 text-slate-500">
                        {render.width}×{render.height} · {render.fps}fps ·{" "}
                        {(render.durationMs / 1000).toFixed(1)}s · render{" "}
                        {render.renderMs}ms · {new Date(render.createdAt).toISOString().slice(11, 19)}
                      </p>
                    </li>
                  ))}
                </ul>
              )}
              <p className="mt-3 text-[11px] text-slate-500">
                NFR-002: cùng metadata + seed ⇒ render lại cho ra đúng timeline
                này.
              </p>
            </div>
          </section>

          <MetricsForm projectId={project.id} initial={metrics[0] as never} />

          <section className="rounded-3xl border border-white/10 bg-white/[0.04] p-5">
            <h2 className="text-sm font-semibold text-white">Concept scoring</h2>
            <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-5">
              {Object.entries(transformation.scores)
                .filter(([key]) => key !== "total")
                .map(([key, value]) => (
                  <div
                    key={key}
                    className="rounded-2xl border border-white/10 bg-[#0f1219] p-3"
                  >
                    <p className="text-[10px] uppercase tracking-wider text-slate-500">
                      {key}
                    </p>
                    <p className="mt-1 text-xl font-bold text-white">{value as number}</p>
                  </div>
                ))}
            </div>
            <p className="mt-3 text-xs text-slate-400">
              Tổng {transformation.scores.total}/10 · tags:{" "}
              {transformation.tags.join(", ")} · difficulty {transformation.difficulty}
            </p>
          </section>
        </div>
      </div>
    </main>
  );
}
