import Link from "next/link";
import { BatchForm } from "@/components/BatchForm";
import { getFactoryStats, listBatches } from "@/lib/server/projects";

export const dynamic = "force-dynamic";

export default async function BatchesPage() {
  const [batches, stats] = await Promise.all([listBatches(), getFactoryStats()]);

  return (
    <main className="mx-auto max-w-7xl px-6 py-10">
      <p className="text-xs font-semibold uppercase tracking-[0.3em] text-orange-300">
        Release 3 · Factory
      </p>
      <h1 className="mt-3 text-3xl font-black text-white">Batch production</h1>
      <p className="mt-2 max-w-2xl text-sm text-slate-400">
        Một content operator cần hàng chục video mỗi ngày. Batch sinh concept →
        drawing plan → validation, và chỉ giữ lại project đạt quality gate.
      </p>

      <div className="mt-8 grid gap-6 lg:grid-cols-[minmax(0,420px)_1fr]">
        <BatchForm />

        <div className="space-y-6">
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            {[
              { label: "Projects", value: stats.projects },
              { label: "Validated", value: stats.validated },
              { label: "Batches", value: stats.batches },
              { label: "Avg duration", value: `${(stats.avgDurationMs / 1000).toFixed(1)}s` },
            ].map((item) => (
              <div
                key={item.label}
                className="rounded-2xl border border-white/10 bg-white/[0.04] p-4"
              >
                <p className="text-[11px] uppercase tracking-wider text-slate-500">
                  {item.label}
                </p>
                <p className="mt-1 text-2xl font-black text-white">{item.value}</p>
              </div>
            ))}
          </div>

          <div className="rounded-3xl border border-white/10 bg-white/[0.04] p-6">
            <h2 className="text-sm font-semibold text-white">Batch gần đây</h2>
            {batches.length === 0 ? (
              <p className="mt-3 text-sm text-slate-400">Chưa có batch nào.</p>
            ) : (
              <ul className="mt-4 divide-y divide-white/5">
                {batches.map((batch) => (
                  <li key={batch.id} className="flex items-center gap-3 py-3">
                    <div className="min-w-0 flex-1">
                      <Link
                        href={`/batches/${batch.id}`}
                        className="block truncate text-sm font-semibold text-white hover:text-orange-300"
                      >
                        {batch.name}
                      </Link>
                      <p className="text-[11px] text-slate-500">
                        #{batch.id} · {batch.sizeCreated}/{batch.sizeRequested} project ·{" "}
                        {batch.params.category} · seed {batch.params.seed} ·{" "}
                        {batch.params.variant}
                      </p>
                    </div>
                    <span className="rounded-full border border-white/10 bg-white/5 px-2.5 py-1 text-[11px] text-slate-300">
                      {new Date(batch.createdAt).toISOString().slice(5, 16).replace("T", " ")}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </div>
    </main>
  );
}
