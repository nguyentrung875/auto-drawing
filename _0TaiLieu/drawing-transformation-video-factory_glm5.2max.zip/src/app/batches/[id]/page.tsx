import Link from "next/link";
import { notFound } from "next/navigation";
import { getBatch } from "@/lib/server/projects";

export const dynamic = "force-dynamic";

export default async function BatchDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const batchId = Number(id);
  if (!Number.isFinite(batchId)) notFound();
  const data = await getBatch(batchId);
  if (!data) notFound();

  const { batch, items } = data;
  const validated = items.filter((row) => row.item.validationPass === 1).length;
  const totalDuration = items.reduce(
    (acc, row) => acc + (row.project?.timeline.totalMs ?? 0),
    0,
  );
  const totalCost = items.reduce(
    (acc, row) => acc + (row.project?.cost.estCostUsd ?? 0),
    0,
  );

  return (
    <main className="mx-auto max-w-7xl px-6 py-10">
      <Link href="/batches" className="text-xs text-slate-400 hover:text-orange-300">
        ← Batch production
      </Link>
      <div className="mt-3 flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-white">{batch.name}</h1>
          <p className="mt-1 text-sm text-slate-400">
            Batch #{batch.id} · {batch.sizeCreated}/{batch.sizeRequested} project ·
            category {batch.params.category} · seed {batch.params.seed} · variant{" "}
            {batch.params.variant}
          </p>
        </div>
        <span className="rounded-full border border-emerald-400/30 bg-emerald-400/10 px-4 py-1.5 text-xs font-bold text-emerald-300">
          {validated}/{items.length} validated
        </span>
      </div>

      <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
        {[
          { label: "Projects", value: String(items.length) },
          { label: "Tổng thời lượng", value: `${(totalDuration / 1000 / 60).toFixed(1)} phút` },
          { label: "Est cost", value: `$${totalCost.toFixed(4)}` },
          { label: "Cost / video", value: `$${(totalCost / Math.max(1, items.length)).toFixed(5)}` },
        ].map((item) => (
          <div
            key={item.label}
            className="rounded-2xl border border-white/10 bg-white/[0.04] p-4"
          >
            <p className="text-[11px] uppercase tracking-wider text-slate-500">
              {item.label}
            </p>
            <p className="mt-1 text-xl font-black text-white">{item.value}</p>
          </div>
        ))}
      </div>

      <div className="mt-8 overflow-hidden rounded-3xl border border-white/10 bg-white/[0.04]">
        <table className="w-full text-left text-sm">
          <thead className="bg-white/5 text-[11px] uppercase tracking-wider text-slate-400">
            <tr>
              <th className="px-4 py-3">#</th>
              <th className="px-4 py-3">Transformation</th>
              <th className="px-4 py-3">Project</th>
              <th className="px-4 py-3">Steps</th>
              <th className="px-4 py-3">Duration</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3" />
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {items.map((row) => (
              <tr key={row.item.id} className="hover:bg-white/[0.03]">
                <td className="px-4 py-3 font-mono text-xs text-slate-500">
                  {row.item.orderIndex + 1}
                </td>
                <td className="px-4 py-3">
                  <span className="font-bold text-orange-300">{row.item.hook}</span>
                  <span className="mx-2 text-slate-600">→</span>
                  <span className="text-white">{row.item.subject}</span>
                </td>
                <td className="px-4 py-3 font-mono text-xs text-slate-400">
                  #{row.item.projectId}
                </td>
                <td className="px-4 py-3 text-xs text-slate-400">
                  {row.project?.plan.steps.length ?? "—"}
                </td>
                <td className="px-4 py-3 text-xs text-slate-400">
                  {row.project ? `${(row.project.timeline.totalMs / 1000).toFixed(1)}s` : "—"}
                </td>
                <td className="px-4 py-3 text-xs">
                  <span
                    className={
                      row.item.validationPass === 1
                        ? "text-emerald-300"
                        : "text-rose-300"
                    }
                  >
                    {row.item.status}
                  </span>
                </td>
                <td className="px-4 py-3 text-right">
                  <Link
                    href={`/studio/${row.item.projectId}`}
                    className="rounded-lg border border-white/15 bg-white/5 px-3 py-1.5 text-[11px] font-semibold text-slate-100 hover:border-orange-400/50"
                  >
                    Review →
                  </Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </main>
  );
}
