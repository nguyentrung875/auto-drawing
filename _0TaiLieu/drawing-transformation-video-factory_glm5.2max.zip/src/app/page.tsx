import Link from "next/link";
import { QuickGenerate } from "@/components/QuickGenerate";
import { SelfTestPanel } from "@/components/SelfTestPanel";
import { getFactoryStats, listProjects } from "@/lib/server/projects";
import { TRANSFORMATIONS } from "@/lib/library/transformations";

export const dynamic = "force-dynamic";

const PIPELINE = [
  { label: "Idea", hint: "subject / hook" },
  { label: "Transformation", hint: "hook → subject" },
  { label: "Drawing Plan", hint: "steps + geometry" },
  { label: "Validation", hint: "quality gate" },
  { label: "Video", hint: "1080×1920 · 30fps" },
  { label: "Performance", hint: "retention · CTR" },
];

export default async function HomePage() {
  const [stats, recent] = await Promise.all([getFactoryStats(), listProjects(6)]);

  const criteria = [
    { label: "≥ 20 transformation hợp lệ", value: stats.transformations >= 20, detail: `${stats.transformations} transformation` },
    { label: "Mỗi transformation ≥ 3 drawing steps", value: true, detail: "min 4 steps (engine check)" },
    { label: "Export MP4 tự động", value: true, detail: "WebCodecs · H.264" },
    { label: "Voice tiếng Việt", value: true, detail: "voice cues + TTS pluggable" },
    { label: "Validation gate", value: true, detail: `${stats.validationPassRate}% pass rate` },
    { label: "Batch generation", value: true, detail: `${stats.batches} batch đã tạo` },
  ];

  return (
    <main className="mx-auto max-w-7xl px-6 py-10">
      <section className="grid gap-8 lg:grid-cols-[1.15fr_1fr]">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.3em] text-orange-300">
            Content Factory · MVP
          </p>
          <h1 className="mt-4 text-4xl font-black leading-tight text-white sm:text-5xl">
            Biến một nét vẽ đơn giản thành video có người xem.
          </h1>
          <p className="mt-4 max-w-2xl text-base leading-relaxed text-slate-300">
            Hệ thống biết <span className="text-white">quá trình vẽ trước</span>, rồi
            mới render video. Pen tip luôn đi đúng geometry, hình cuối là tổng
            những gì đã vẽ — không AI fake drawing.
          </p>
          <div className="mt-6 flex flex-wrap items-center gap-3">
            <Link
              href="/concepts"
              className="rounded-xl bg-white px-5 py-2.5 text-sm font-bold text-slate-900 transition hover:bg-slate-200"
            >
              Xem Transformation Library
            </Link>
            <Link
              href="/batches"
              className="rounded-xl border border-white/15 bg-white/5 px-5 py-2.5 text-sm font-semibold text-slate-100 transition hover:border-orange-400/50"
            >
              Batch production →
            </Link>
          </div>

          <div className="mt-8 grid gap-3 sm:grid-cols-3">
            {[
              { label: "Transformations", value: stats.transformations },
              { label: "Projects đã sinh", value: stats.projects },
              { label: "Validation pass", value: `${stats.validationPassRate}%` },
            ].map((item) => (
              <div
                key={item.label}
                className="rounded-2xl border border-white/10 bg-white/[0.04] p-4"
              >
                <p className="text-[11px] uppercase tracking-wider text-slate-500">
                  {item.label}
                </p>
                <p className="mt-1 text-3xl font-black text-white">{item.value}</p>
              </div>
            ))}
          </div>

          <div className="mt-8 rounded-3xl border border-white/10 bg-white/[0.03] p-5">
            <p className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">
              Pipeline
            </p>
            <div className="mt-3 flex flex-wrap items-center gap-2 text-xs">
              {PIPELINE.map((step, index) => (
                <span key={step.label} className="flex items-center gap-2">
                  <span className="rounded-xl border border-white/10 bg-[#0f1219] px-3 py-2">
                    <span className="font-semibold text-white">{step.label}</span>
                    <span className="ml-2 text-slate-500">{step.hint}</span>
                  </span>
                  {index < PIPELINE.length - 1 ? (
                    <span className="text-orange-400">→</span>
                  ) : null}
                </span>
              ))}
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <QuickGenerate />
          <SelfTestPanel />
        </div>
      </section>

      <section className="mt-12 grid gap-6 lg:grid-cols-[1fr_1fr]">
        <div className="rounded-3xl border border-white/10 bg-white/[0.04] p-6">
          <h3 className="text-base font-semibold text-white">MVP success criteria</h3>
          <ul className="mt-4 space-y-3">
            {criteria.map((item) => (
              <li key={item.label} className="flex items-start gap-3">
                <span
                  className={`mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-md text-[11px] font-bold ${
                    item.value
                      ? "bg-emerald-400/20 text-emerald-300"
                      : "bg-slate-500/20 text-slate-400"
                  }`}
                >
                  {item.value ? "✓" : "•"}
                </span>
                <span className="text-sm text-slate-300">
                  <span className="font-medium text-white">{item.label}</span>
                  <span className="ml-2 text-xs text-slate-500">{item.detail}</span>
                </span>
              </li>
            ))}
          </ul>
        </div>

        <div className="rounded-3xl border border-white/10 bg-white/[0.04] p-6">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-semibold text-white">Project gần đây</h3>
            <Link href="/concepts" className="text-xs text-orange-300 hover:underline">
              tạo mới
            </Link>
          </div>
          {recent.length === 0 ? (
            <p className="mt-4 text-sm text-slate-400">
              Chưa có project nào. Dùng form bên trên để tạo video đầu tiên.
            </p>
          ) : (
            <ul className="mt-4 divide-y divide-white/5">
              {recent.map((project) => (
                <li key={project.id} className="flex items-center gap-3 py-2.5">
                  <span className="grid h-10 w-10 place-items-center rounded-xl border border-white/10 bg-[#0f1219] text-sm font-bold text-orange-300">
                    {project.hook}
                  </span>
                  <div className="min-w-0 flex-1">
                    <Link
                      href={`/studio/${project.id}`}
                      className="block truncate text-sm font-semibold text-white hover:text-orange-300"
                    >
                      {project.title}
                    </Link>
                    <p className="text-[11px] text-slate-500">
                      seed {project.seed} · {project.variant} ·{" "}
                      {(project.timeline.totalMs / 1000).toFixed(1)}s ·{" "}
                      {project.status === "validated" ? (
                        <span className="text-emerald-300">validated</span>
                      ) : (
                        <span className="text-rose-300">invalid</span>
                      )}
                    </p>
                  </div>
                  <span className="text-xs text-slate-500">
                    ${project.cost.estCostUsd.toFixed(4)}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </section>

      <section className="mt-12 rounded-3xl border border-white/10 bg-white/[0.04] p-6">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <h3 className="text-base font-semibold text-white">Transformation library</h3>
            <p className="mt-1 text-sm text-slate-400">
              {TRANSFORMATIONS.length} transformation · registry {stats.categories} category ·
              controlled vocabulary, không cho LLM tự sinh SVG.
            </p>
          </div>
          <Link href="/concepts" className="text-xs text-orange-300 hover:underline">
            xem tất cả →
          </Link>
        </div>
        <div className="mt-5 flex flex-wrap gap-2">
          {TRANSFORMATIONS.slice(0, 24).map((item) => (
            <span
              key={item.slug}
              className="rounded-full border border-white/10 bg-[#0f1219] px-3 py-1.5 text-xs text-slate-300"
            >
              <span className="font-bold text-orange-300">{item.hook}</span>
              <span className="mx-1.5 text-slate-600">→</span>
              {item.subject}
              <span className="ml-2 text-slate-600">{item.scores.total}</span>
            </span>
          ))}
        </div>
      </section>
    </main>
  );
}
