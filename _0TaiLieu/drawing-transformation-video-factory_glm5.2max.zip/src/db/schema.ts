import {
  integer,
  jsonb,
  pgTable,
  real,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";
import type {
  DrawingPlan,
  Timeline,
  ValidationReport,
  VoiceCue,
} from "@/lib/engine/types";

export const transformations = pgTable(
  "transformations",
  {
    id: serial("id").primaryKey(),
    slug: text("slug").notNull(),
    hook: text("hook").notNull(),
    hookLabel: text("hook_label").notNull(),
    hookCategory: text("hook_category").notNull(),
    glyphKey: text("glyph_key").notNull(),
    subject: text("subject").notNull(),
    subjectKey: text("subject_key").notNull(),
    subjectLabel: text("subject_label").notNull(),
    language: text("language").notNull().default("vi"),
    style: text("style").notNull().default("cute_simple"),
    title: text("title").notNull(),
    hookVoice: text("hook_voice").notNull(),
    startVoice: text("start_voice").notNull(),
    revealVoice: text("reveal_voice").notNull(),
    cta: text("cta").notNull(),
    tags: jsonb("tags").$type<string[]>().notNull().default([]),
    scores: jsonb("scores")
      .$type<{
        curiosity: number;
        simplicity: number;
        feasibility: number;
        visual: number;
        retention: number;
        total: number;
      }>()
      .notNull(),
    difficulty: integer("difficulty").notNull().default(1),
    status: text("status").notNull().default("ready"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [uniqueIndex("transformations_slug_key").on(table.slug)],
);

export const registryComponents = pgTable(
  "registry_components",
  {
    id: serial("id").primaryKey(),
    key: text("key").notNull(),
    kind: text("kind").notNull(),
    label: text("label").notNull(),
    glyphKey: text("glyph_key"),
    strokeCount: integer("stroke_count").notNull().default(0),
    partCount: integer("part_count").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [uniqueIndex("registry_components_key_key").on(table.key)],
);

export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  transformationId: integer("transformation_id")
    .notNull()
    .references(() => transformations.id, { onDelete: "cascade" }),
  seed: integer("seed").notNull(),
  version: integer("version").notNull().default(1),
  variant: text("variant").notNull().default("curious"),
  status: text("status").notNull().default("validated"),
  plan: jsonb("plan").$type<DrawingPlan>().notNull(),
  timeline: jsonb("timeline").$type<Timeline>().notNull(),
  validation: jsonb("validation").$type<ValidationReport>().notNull(),
  voiceCues: jsonb("voice_cues").$type<VoiceCue[]>().notNull().default([]),
  cost: jsonb("cost")
    .$type<{ renderMs: number; voiceChars: number; estCostUsd: number }>()
    .notNull()
    .default({ renderMs: 0, voiceChars: 0, estCostUsd: 0 }),
  poster: text("poster"),
  batchId: integer("batch_id"),
  generationMs: integer("generation_ms").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const renders = pgTable("renders", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id")
    .notNull()
    .references(() => projects.id, { onDelete: "cascade" }),
  format: text("format").notNull().default("mp4"),
  encoder: text("encoder").notNull().default("webcodecs-avc"),
  status: text("status").notNull().default("ok"),
  width: integer("width").notNull(),
  height: integer("height").notNull(),
  fps: integer("fps").notNull(),
  durationMs: integer("duration_ms").notNull(),
  sizeBytes: integer("size_bytes").notNull().default(0),
  renderMs: integer("render_ms").notNull().default(0),
  hasVoice: integer("has_voice").notNull().default(0),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const batches = pgTable("batches", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  sizeRequested: integer("size_requested").notNull(),
  sizeCreated: integer("size_created").notNull().default(0),
  params: jsonb("params")
    .$type<{
      category?: string;
      seed?: number;
      variant?: string;
      speed?: string;
      language?: string;
    }>()
    .notNull()
    .default({}),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const batchItems = pgTable("batch_items", {
  id: serial("id").primaryKey(),
  batchId: integer("batch_id")
    .notNull()
    .references(() => batches.id, { onDelete: "cascade" }),
  projectId: integer("project_id").references(() => projects.id, {
    onDelete: "cascade",
  }),
  transformationId: integer("transformation_id")
    .notNull()
    .references(() => transformations.id, { onDelete: "cascade" }),
  hook: text("hook").notNull(),
  subject: text("subject").notNull(),
  status: text("status").notNull().default("planned"),
  validationPass: integer("validation_pass").notNull().default(0),
  orderIndex: integer("order_index").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const voiceAssets = pgTable(
  "voice_assets",
  {
    id: serial("id").primaryKey(),
    cacheKey: text("cache_key").notNull(),
    provider: text("provider").notNull(),
    voice: text("voice").notNull(),
    text: text("text").notNull(),
    mimeType: text("mime_type").notNull(),
    audioBase64: text("audio_base64").notNull(),
    bytes: integer("bytes").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [uniqueIndex("voice_assets_cache_key_key").on(table.cacheKey)],
);

export const performanceMetrics = pgTable(
  "performance_metrics",
  {
    id: serial("id").primaryKey(),
    projectId: integer("project_id")
      .notNull()
      .references(() => projects.id, { onDelete: "cascade" }),
    platform: text("platform").notNull().default("tiktok"),
    views: integer("views").notNull().default(0),
    retention3s: real("retention_3s").notNull().default(0),
    avgWatchMs: integer("avg_watch_ms").notNull().default(0),
    completionRate: real("completion_rate").notNull().default(0),
    replayRate: real("replay_rate").notNull().default(0),
    shareRate: real("share_rate").notNull().default(0),
    saveRate: real("save_rate").notNull().default(0),
    ctr: real("ctr").notNull().default(0),
    conversions: integer("conversions").notNull().default(0),
    revenueMicros: integer("revenue_micros").notNull().default(0),
    notes: text("notes"),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    uniqueIndex("performance_metrics_project_platform_key").on(
      table.projectId,
      table.platform,
    ),
  ],
);
