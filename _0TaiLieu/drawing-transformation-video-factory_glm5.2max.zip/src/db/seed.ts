import { sql } from "drizzle-orm";
import { db } from "@/db";
import { registryComponents, transformations } from "@/db/schema";
import { TRANSFORMATIONS } from "@/lib/library/transformations";
import { listRegistryComponents } from "@/lib/registry";

let seedPromise: Promise<void> | null = null;

async function seed(): Promise<void> {
  await db.execute(sql`select 1`);

  const registry = listRegistryComponents();
  await db
    .insert(registryComponents)
    .values(
      registry.map((entry) => ({
        key: entry.key,
        kind: entry.kind,
        label: entry.label,
        glyphKey: entry.glyphKey,
        strokeCount: entry.strokeCount,
        partCount: entry.partCount,
      })),
    )
    .onConflictDoNothing();

  await db
    .insert(transformations)
    .values(
      TRANSFORMATIONS.map((t) => ({
        slug: t.slug,
        hook: t.hook,
        hookLabel: t.hookLabel,
        hookCategory: t.hookCategory,
        glyphKey: t.glyphKey,
        subject: t.subject,
        subjectKey: t.subjectKey,
        subjectLabel: t.subjectLabel,
        language: t.language,
        style: t.style,
        title: t.title,
        hookVoice: t.hookVoice,
        startVoice: t.startVoice,
        revealVoice: t.revealVoice,
        cta: t.cta,
        tags: t.tags,
        scores: t.scores,
        difficulty: t.difficulty,
        status: "ready",
      })),
    )
    .onConflictDoNothing();
}

/** Idempotent bootstrap of the transformation library + registry mirror. */
export function ensureSeed(): Promise<void> {
  if (!seedPromise) {
    seedPromise = seed().catch((error) => {
      seedPromise = null;
      throw error;
    });
  }
  return seedPromise;
}
