import {
  pgTable,
  serial,
  text,
  integer,
  boolean,
  jsonb,
  timestamp,
  real,
  pgEnum,
} from "drizzle-orm/pg-core";

// ─── Enums ───────────────────────────────────────────────────────────────────

export const conceptStatusEnum = pgEnum("concept_status", [
  "draft",
  "validated",
  "invalid",
  "archived",
]);

export const projectStatusEnum = pgEnum("project_status", [
  "draft",
  "drawing_planned",
  "validated",
  "rendering",
  "rendered",
  "failed",
  "approved",
  "published",
]);

export const hookTypeEnum = pgEnum("hook_type", [
  "number",
  "letter",
  "symbol",
  "geometry",
  "combination",
]);

export const batchStatusEnum = pgEnum("batch_status", [
  "pending",
  "running",
  "completed",
  "failed",
  "partial",
]);

// ─── Transformation Library ───────────────────────────────────────────────────

export const transformations = pgTable("transformations", {
  id: serial("id").primaryKey(),
  hook: text("hook").notNull(),           // e.g. "8"
  subject: text("subject").notNull(),     // e.g. "bear"
  hookType: hookTypeEnum("hook_type").notNull().default("number"),
  description: text("description"),
  style: text("style").notNull().default("cute_simple"),
  language: text("language").notNull().default("vi"),

  // scoring fields
  curiosityScore: integer("curiosity_score").default(0),   // 0–10
  simplicityScore: integer("simplicity_score").default(0),
  feasibilityScore: integer("feasibility_score").default(0),
  visualScore: integer("visual_score").default(0),
  retentionScore: integer("retention_score").default(0),
  totalScore: integer("total_score").default(0),

  status: conceptStatusEnum("status").notNull().default("draft"),
  tags: text("tags").array().default([]),

  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// ─── Drawing Steps ────────────────────────────────────────────────────────────

export const drawingSteps = pgTable("drawing_steps", {
  id: serial("id").primaryKey(),
  transformationId: integer("transformation_id")
    .notNull()
    .references(() => transformations.id, { onDelete: "cascade" }),

  stepOrder: integer("step_order").notNull(),
  label: text("label").notNull(),           // e.g. "left ear"
  description: text("description"),
  svgPath: text("svg_path").notNull(),       // raw SVG path data
  svgViewBox: text("svg_viewbox").notNull().default("0 0 400 400"),
  duration: integer("duration").notNull().default(1000), // ms
  voiceLine: text("voice_line"),             // Vietnamese voice line
  isRevealStep: boolean("is_reveal_step").notNull().default(false),

  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// ─── Drawing Registry Components ──────────────────────────────────────────────

export const registryComponents = pgTable("registry_components", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  category: text("category").notNull(),  // glyph, number, letter, primitive, animal, template
  svgData: text("svg_data").notNull(),
  tags: text("tags").array().default([]),
  usageCount: integer("usage_count").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// ─── Projects ─────────────────────────────────────────────────────────────────

export const projects = pgTable("projects", {
  id: serial("id").primaryKey(),
  transformationId: integer("transformation_id")
    .notNull()
    .references(() => transformations.id),

  title: text("title").notNull(),
  seed: integer("seed").notNull().default(42),
  status: projectStatusEnum("status").notNull().default("draft"),
  version: integer("version").notNull().default(1),

  // Video config
  cta: text("cta").notNull().default("Xem thêm ở bio."),
  fps: integer("fps").notNull().default(30),
  width: integer("width").notNull().default(1080),
  height: integer("height").notNull().default(1920),
  targetDuration: integer("target_duration").notNull().default(25), // seconds

  // Metadata
  metadata: jsonb("metadata").default({}),
  validationErrors: text("validation_errors").array().default([]),
  validationPassed: boolean("validation_passed").default(false),

  // Performance tracking
  views: integer("views").default(0),
  watchTime: real("watch_time").default(0),
  completionRate: real("completion_rate").default(0),
  shareCount: integer("share_count").default(0),
  affiliateCtr: real("affiliate_ctr").default(0),

  // Cost tracking
  generationCost: real("generation_cost").default(0),
  generationDuration: integer("generation_duration").default(0), // ms
  ttsCost: real("tts_cost").default(0),

  exportPath: text("export_path"),
  publishedAt: timestamp("published_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// ─── Variants / Experiments ───────────────────────────────────────────────────

export const variants = pgTable("variants", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id")
    .notNull()
    .references(() => projects.id, { onDelete: "cascade" }),

  variantKey: text("variant_key").notNull(), // e.g. "hook_curious", "cta_v2"
  hookText: text("hook_text"),
  ctaText: text("cta_text"),
  drawingSpeed: text("drawing_speed").notNull().default("normal"), // slow, normal, fast
  revealTimingSeconds: integer("reveal_timing_seconds").default(15),
  voiceStyle: text("voice_style").default("friendly"),

  isWinner: boolean("is_winner").default(false),
  views: integer("views").default(0),
  completionRate: real("completion_rate").default(0),

  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// ─── Batches ──────────────────────────────────────────────────────────────────

export const batches = pgTable("batches", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  prompt: text("prompt"),              // e.g. "Generate 50 cute animal transformations"
  size: integer("size").notNull().default(10),
  status: batchStatusEnum("status").notNull().default("pending"),

  successCount: integer("success_count").notNull().default(0),
  failureCount: integer("failure_count").notNull().default(0),
  totalCost: real("total_cost").default(0),
  startedAt: timestamp("started_at"),
  completedAt: timestamp("completed_at"),

  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const batchItems = pgTable("batch_items", {
  id: serial("id").primaryKey(),
  batchId: integer("batch_id")
    .notNull()
    .references(() => batches.id, { onDelete: "cascade" }),
  projectId: integer("project_id").references(() => projects.id),
  transformationId: integer("transformation_id").references(() => transformations.id),

  status: text("status").notNull().default("pending"), // pending, running, success, failed
  errorMessage: text("error_message"),
  processingDuration: integer("processing_duration").default(0),

  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// ─── Affiliate ────────────────────────────────────────────────────────────────

export const affiliateLinks = pgTable("affiliate_links", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id")
    .notNull()
    .references(() => projects.id, { onDelete: "cascade" }),

  url: text("url").notNull(),
  platform: text("platform").notNull().default("amazon"), // amazon, tiktok_shop, shopee
  productName: text("product_name"),
  clicks: integer("clicks").notNull().default(0),
  conversions: integer("conversions").notNull().default(0),
  revenue: real("revenue").notNull().default(0),

  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// ─── Types ────────────────────────────────────────────────────────────────────

export type Transformation = typeof transformations.$inferSelect;
export type NewTransformation = typeof transformations.$inferInsert;
export type DrawingStep = typeof drawingSteps.$inferSelect;
export type NewDrawingStep = typeof drawingSteps.$inferInsert;
export type Project = typeof projects.$inferSelect;
export type NewProject = typeof projects.$inferInsert;
export type Variant = typeof variants.$inferSelect;
export type Batch = typeof batches.$inferSelect;
export type BatchItem = typeof batchItems.$inferSelect;
export type RegistryComponent = typeof registryComponents.$inferSelect;
export type AffiliateLink = typeof affiliateLinks.$inferSelect;
