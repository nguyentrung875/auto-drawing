import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { transformations, drawingSteps } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const transformationId = parseInt(id);

    const [transformation] = await db
      .select()
      .from(transformations)
      .where(eq(transformations.id, transformationId));

    if (!transformation) {
      return NextResponse.json({ error: "Transformation not found" }, { status: 404 });
    }

    const steps = await db
      .select()
      .from(drawingSteps)
      .where(eq(drawingSteps.transformationId, transformationId))
      .orderBy(drawingSteps.stepOrder);

    return NextResponse.json({ transformation, steps });
  } catch (error) {
    console.error("GET /api/transformations/[id] error:", error);
    return NextResponse.json({ error: "Failed to fetch transformation" }, { status: 500 });
  }
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const transformationId = parseInt(id);
    const body = await req.json();

    const [updated] = await db
      .update(transformations)
      .set({
        ...body,
        updatedAt: new Date(),
      })
      .where(eq(transformations.id, transformationId))
      .returning();

    return NextResponse.json({ transformation: updated });
  } catch (error) {
    console.error("PATCH /api/transformations/[id] error:", error);
    return NextResponse.json({ error: "Failed to update transformation" }, { status: 500 });
  }
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const transformationId = parseInt(id);

    await db
      .delete(transformations)
      .where(eq(transformations.id, transformationId));

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("DELETE /api/transformations/[id] error:", error);
    return NextResponse.json({ error: "Failed to delete transformation" }, { status: 500 });
  }
}
