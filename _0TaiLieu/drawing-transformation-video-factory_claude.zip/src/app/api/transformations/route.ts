import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { transformations, drawingSteps } from "@/db/schema";
import { eq, desc, ilike, or } from "drizzle-orm";
import { TRANSFORMATIONS } from "@/lib/drawing-library";
import { validateDrawingPlan, scoreTransformation } from "@/lib/validation";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const query = searchParams.get("q");
    const status = searchParams.get("status");
    const hookType = searchParams.get("hookType");

    let qb = db.select().from(transformations).orderBy(desc(transformations.totalScore));

    const results = await qb;

    let filtered = results;
    if (query) {
      const q = query.toLowerCase();
      filtered = filtered.filter(
        (t) =>
          t.hook.toLowerCase().includes(q) ||
          t.subject.toLowerCase().includes(q) ||
          (t.description ?? "").toLowerCase().includes(q) ||
          (t.tags ?? []).some((tag) => tag.toLowerCase().includes(q))
      );
    }
    if (status) filtered = filtered.filter((t) => t.status === status);
    if (hookType) filtered = filtered.filter((t) => t.hookType === hookType);

    return NextResponse.json({ transformations: filtered });
  } catch (error) {
    console.error("GET /api/transformations error:", error);
    return NextResponse.json({ error: "Failed to fetch transformations" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { hook, subject, hookType, description, style, language, tags, steps } = body;

    if (!hook || !subject) {
      return NextResponse.json({ error: "hook and subject are required" }, { status: 400 });
    }

    // Look up from library if steps not provided
    const libDef = TRANSFORMATIONS.find(
      (t) =>
        t.hook.toLowerCase() === hook.toLowerCase() &&
        t.subject.toLowerCase() === subject.toLowerCase()
    );

    const stepsToUse = steps ?? libDef?.steps ?? [];
    const stepsForValidation = stepsToUse.map((s: { stepOrder: number; label: string; svgPaths?: Array<{d: string}>; svgPath?: string; svgViewBox?: string; duration: number; voiceLine?: string; isRevealStep?: boolean }) => ({
      stepOrder: s.stepOrder,
      label: s.label,
      svgPath: s.svgPaths
        ? s.svgPaths.map((p: { d: string }) => p.d).join(" ")
        : s.svgPath ?? "",
      svgViewBox: s.svgViewBox ?? "0 0 400 400",
      duration: s.duration,
      voiceLine: s.voiceLine ?? "",
      isRevealStep: s.isRevealStep ?? false,
    }));

    const validation = validateDrawingPlan(stepsForValidation);

    const scores = scoreTransformation({
      hook,
      subject,
      stepsCount: stepsToUse.length,
      hasVoice: stepsToUse.some((s: { voiceLine?: string }) => s.voiceLine),
      hasReveal: stepsToUse.some((s: { isRevealStep?: boolean }) => s.isRevealStep),
    });

    const [newTransformation] = await db
      .insert(transformations)
      .values({
        hook,
        subject,
        hookType: hookType ?? libDef?.hookType ?? "number",
        description: description ?? libDef?.description ?? "",
        style: style ?? libDef?.style ?? "cute_simple",
        language: language ?? "vi",
        tags: tags ?? libDef?.tags ?? [],
        curiosityScore: scores.curiosity,
        simplicityScore: scores.simplicity,
        feasibilityScore: scores.feasibility,
        visualScore: scores.visual,
        retentionScore: scores.retention,
        totalScore: scores.total,
        status: validation.passed ? "validated" : "invalid",
      })
      .returning();

    // Insert drawing steps
    if (stepsToUse.length > 0 && newTransformation) {
      for (const step of stepsToUse) {
        const svgPath = step.svgPaths
          ? step.svgPaths.map((p: { d: string }) => p.d).join(" ")
          : step.svgPath ?? "";

        await db.insert(drawingSteps).values({
          transformationId: newTransformation.id,
          stepOrder: step.stepOrder,
          label: step.label,
          description: step.description ?? "",
          svgPath,
          svgViewBox: step.svgViewBox ?? "0 0 400 400",
          duration: step.duration ?? 1000,
          voiceLine: step.voiceLine ?? null,
          isRevealStep: step.isRevealStep ?? false,
        });
      }
    }

    return NextResponse.json({
      transformation: newTransformation,
      validation,
      scores,
    });
  } catch (error) {
    console.error("POST /api/transformations error:", error);
    return NextResponse.json({ error: "Failed to create transformation" }, { status: 500 });
  }
}
