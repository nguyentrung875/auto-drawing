import { NextResponse } from "next/server";
import { db } from "@/db";
import { transformations, drawingSteps, registryComponents } from "@/db/schema";
import { TRANSFORMATIONS } from "@/lib/drawing-library";
import { validateDrawingPlan, scoreTransformation } from "@/lib/validation";

export async function POST() {
  try {
    let seeded = 0;
    let skipped = 0;

    // Seed registry components
    const registryItems = [
      { name: "number_0", category: "number", svgData: "M 200 100 C 160 100 130 140 130 200 C 130 260 160 300 200 300 C 240 300 270 260 270 200 C 270 140 240 100 200 100 Z", tags: ["number", "glyph"] },
      { name: "number_1", category: "number", svgData: "M 200 80 L 200 320 M 200 80 L 175 115", tags: ["number", "glyph"] },
      { name: "number_8", category: "number", svgData: "M 200 120 C 200 80 160 60 140 80 C 120 100 120 140 140 155 C 160 170 200 170 200 170", tags: ["number", "glyph"] },
      { name: "circle", category: "primitive", svgData: "M 200 140 C 200 100 260 100 260 140 C 260 180 200 180 200 140 Z", tags: ["geometry", "primitive"] },
      { name: "triangle", category: "primitive", svgData: "M 200 80 L 290 270 L 110 270 Z", tags: ["geometry", "primitive"] },
      { name: "bear_ear", category: "animal", svgData: "M 145 72 C 130 50 110 45 108 60 C 106 75 125 85 145 80", tags: ["animal", "bear"] },
      { name: "cat_ear", category: "animal", svgData: "M 148 115 L 130 75 L 168 100 Z", tags: ["animal", "cat"] },
      { name: "bird_beak", category: "animal", svgData: "M 235 135 L 265 130 L 235 148 Z", tags: ["animal", "bird"] },
    ];

    for (const item of registryItems) {
      try {
        await db.insert(registryComponents).values(item).onConflictDoNothing();
      } catch {
        // skip duplicates
      }
    }

    // Seed transformations from library
    for (const def of TRANSFORMATIONS) {
      try {
        const scores = scoreTransformation({
          hook: def.hook,
          subject: def.subject,
          stepsCount: def.steps.length,
          hasVoice: def.steps.some((s) => s.voiceLine),
          hasReveal: def.steps.some((s) => s.isRevealStep),
        });

        const stepsForValidation = def.steps.map((s) => ({
          stepOrder: s.stepOrder,
          label: s.label,
          svgPath: s.svgPaths.map((p) => p.d).join(" "),
          svgViewBox: "0 0 400 400",
          duration: s.duration,
          voiceLine: s.voiceLine ?? "",
          isRevealStep: s.isRevealStep ?? false,
        }));

        const validation = validateDrawingPlan(stepsForValidation);

        const [transformation] = await db
          .insert(transformations)
          .values({
            hook: def.hook,
            subject: def.subject,
            hookType: def.hookType,
            description: def.description,
            style: def.style,
            language: def.language,
            tags: def.tags,
            curiosityScore: scores.curiosity,
            simplicityScore: scores.simplicity,
            feasibilityScore: scores.feasibility,
            visualScore: scores.visual,
            retentionScore: scores.retention,
            totalScore: scores.total,
            status: validation.passed ? "validated" : "invalid",
          })
          .returning();

        if (transformation) {
          for (const step of def.steps) {
            await db.insert(drawingSteps).values({
              transformationId: transformation.id,
              stepOrder: step.stepOrder,
              label: step.label,
              description: step.description ?? "",
              svgPath: step.svgPaths.map((p) => p.d).join(" "),
              svgViewBox: "0 0 400 400",
              duration: step.duration,
              voiceLine: step.voiceLine ?? null,
              isRevealStep: step.isRevealStep ?? false,
            });
          }
          seeded++;
        }
      } catch {
        skipped++;
      }
    }

    return NextResponse.json({
      success: true,
      seeded,
      skipped,
      message: `Seeded ${seeded} transformations, skipped ${skipped}.`,
    });
  } catch (error) {
    console.error("POST /api/seed error:", error);
    return NextResponse.json({ error: "Seed failed" }, { status: 500 });
  }
}
