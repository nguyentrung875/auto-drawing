import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { projects, transformations, drawingSteps, variants } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const status = searchParams.get("status");
    const transformationId = searchParams.get("transformationId");

    let results = await db
      .select()
      .from(projects)
      .orderBy(desc(projects.createdAt));

    if (status) results = results.filter((p) => p.status === status);
    if (transformationId) {
      results = results.filter((p) => p.transformationId === parseInt(transformationId));
    }

    // Enrich with transformation data
    const enriched = await Promise.all(
      results.map(async (project) => {
        const [transformation] = await db
          .select()
          .from(transformations)
          .where(eq(transformations.id, project.transformationId));
        return { ...project, transformation };
      })
    );

    return NextResponse.json({ projects: enriched });
  } catch (error) {
    console.error("GET /api/projects error:", error);
    return NextResponse.json({ error: "Failed to fetch projects" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      transformationId,
      title,
      seed,
      cta,
      fps,
      width,
      height,
      targetDuration,
    } = body;

    if (!transformationId || !title) {
      return NextResponse.json(
        { error: "transformationId and title are required" },
        { status: 400 }
      );
    }

    // Verify transformation exists
    const [transformation] = await db
      .select()
      .from(transformations)
      .where(eq(transformations.id, parseInt(transformationId)));

    if (!transformation) {
      return NextResponse.json(
        { error: "Transformation not found" },
        { status: 404 }
      );
    }

    // Get drawing steps for metadata
    const steps = await db
      .select()
      .from(drawingSteps)
      .where(eq(drawingSteps.transformationId, parseInt(transformationId)))
      .orderBy(drawingSteps.stepOrder);

    const startTime = Date.now();

    const [newProject] = await db
      .insert(projects)
      .values({
        transformationId: parseInt(transformationId),
        title,
        seed: seed ?? 42,
        cta: cta ?? "Xem thêm ở bio.",
        fps: fps ?? 30,
        width: width ?? 1080,
        height: height ?? 1920,
        targetDuration: targetDuration ?? 25,
        status: transformation.status === "validated" ? "drawing_planned" : "draft",
        validationPassed: transformation.status === "validated",
        metadata: {
          transformationHook: transformation.hook,
          transformationSubject: transformation.subject,
          stepsCount: steps.length,
          generatedAt: new Date().toISOString(),
          version: "1.0",
        },
        generationDuration: Date.now() - startTime,
      })
      .returning();

    // Create default variant
    if (newProject) {
      await db.insert(variants).values({
        projectId: newProject.id,
        variantKey: "default",
        hookText: `Số ${transformation.hook} này sẽ biến thành gì?`,
        ctaText: cta ?? "Xem thêm ở bio.",
        drawingSpeed: "normal",
        revealTimingSeconds: targetDuration ? Math.floor(targetDuration * 0.7) : 18,
      });
    }

    return NextResponse.json({ project: newProject });
  } catch (error) {
    console.error("POST /api/projects error:", error);
    return NextResponse.json({ error: "Failed to create project" }, { status: 500 });
  }
}
