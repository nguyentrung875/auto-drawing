import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { projects, transformations, drawingSteps } from "@/db/schema";
import { eq } from "drizzle-orm";
import { validateDrawingPlan } from "@/lib/validation";

export async function POST(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const projectId = parseInt(id);

    const [project] = await db
      .select()
      .from(projects)
      .where(eq(projects.id, projectId));

    if (!project) {
      return NextResponse.json({ error: "Project not found" }, { status: 404 });
    }

    const [transformation] = await db
      .select()
      .from(transformations)
      .where(eq(transformations.id, project.transformationId));

    const steps = await db
      .select()
      .from(drawingSteps)
      .where(eq(drawingSteps.transformationId, project.transformationId))
      .orderBy(drawingSteps.stepOrder);

    if (!transformation || steps.length === 0) {
      return NextResponse.json({ error: "No drawing steps found" }, { status: 400 });
    }

    // Run validation gate (FR-017, NFR-001)
    const validationInput = steps.map((s) => ({
      stepOrder: s.stepOrder,
      label: s.label,
      svgPath: s.svgPath,
      svgViewBox: s.svgViewBox,
      duration: s.duration,
      voiceLine: s.voiceLine,
      isRevealStep: s.isRevealStep,
    }));

    const validation = validateDrawingPlan(validationInput);

    if (!validation.passed) {
      await db
        .update(projects)
        .set({
          status: "failed",
          validationPassed: false,
          validationErrors: validation.errors,
          updatedAt: new Date(),
        })
        .where(eq(projects.id, projectId));

      return NextResponse.json({
        success: false,
        validation,
        message: "Validation failed. Project not rendered.",
      });
    }

    const startTime = Date.now();

    // Simulate rendering (in real implementation, this would call Remotion or similar)
    // For MVP, we mark the project as rendered and produce a preview URL
    const totalDurationMs = steps.reduce((acc, s) => acc + s.duration, 0);
    const estimatedDurationSec = Math.ceil(totalDurationMs / 1000) + 3; // +3 for reveal/CTA

    const generationCost = steps.length * 0.002; // $0.002 per step (simulated)
    const generationDuration = Date.now() - startTime + 1200; // Simulate 1.2s render

    const exportPath = `/renders/project_${projectId}_v${project.version}.mp4`;

    const [updated] = await db
      .update(projects)
      .set({
        status: "rendered",
        validationPassed: true,
        validationErrors: [],
        generationCost,
        generationDuration,
        exportPath,
        metadata: {
          ...(project.metadata as Record<string, unknown>),
          renderedAt: new Date().toISOString(),
          estimatedDurationSec,
          stepCount: steps.length,
          validationWarnings: validation.warnings,
        },
        updatedAt: new Date(),
      })
      .where(eq(projects.id, projectId))
      .returning();

    return NextResponse.json({
      success: true,
      project: updated,
      validation,
      renderInfo: {
        exportPath,
        estimatedDurationSec,
        generationCost,
        generationDurationMs: generationDuration,
        stepCount: steps.length,
      },
    });
  } catch (error) {
    console.error("POST /api/projects/[id]/render error:", error);
    return NextResponse.json({ error: "Render failed" }, { status: 500 });
  }
}
