import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { projects, transformations, drawingSteps, variants, affiliateLinks } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const projectId = parseInt(id);

    const [project] = await db
      .select()
      .from(projects)
      .where(eq(projects.id, projectId));

    if (!project) {
      return NextResponse.json({ error: "Project not found" }, { status: 404 });
    }

    const [transformation] = await db
      .select()
      .from(transformations)
      .where(eq(transformations.id, project.transformationId));

    const steps = await db
      .select()
      .from(drawingSteps)
      .where(eq(drawingSteps.transformationId, project.transformationId))
      .orderBy(drawingSteps.stepOrder);

    const projectVariants = await db
      .select()
      .from(variants)
      .where(eq(variants.projectId, projectId));

    const affiliates = await db
      .select()
      .from(affiliateLinks)
      .where(eq(affiliateLinks.projectId, projectId));

    return NextResponse.json({
      project,
      transformation,
      steps,
      variants: projectVariants,
      affiliates,
    });
  } catch (error) {
    console.error("GET /api/projects/[id] error:", error);
    return NextResponse.json({ error: "Failed to fetch project" }, { status: 500 });
  }
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const projectId = parseInt(id);
    const body = await req.json();

    const [updated] = await db
      .update(projects)
      .set({
        ...body,
        updatedAt: new Date(),
      })
      .where(eq(projects.id, projectId))
      .returning();

    return NextResponse.json({ project: updated });
  } catch (error) {
    console.error("PATCH /api/projects/[id] error:", error);
    return NextResponse.json({ error: "Failed to update project" }, { status: 500 });
  }
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const projectId = parseInt(id);

    await db.delete(projects).where(eq(projects.id, projectId));

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("DELETE /api/projects/[id] error:", error);
    return NextResponse.json({ error: "Failed to delete project" }, { status: 500 });
  }
}
