import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import {
  batches,
  batchItems,
  transformations,
  drawingSteps,
  projects,
} from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { TRANSFORMATIONS } from "@/lib/drawing-library";
import { validateDrawingPlan, scoreTransformation } from "@/lib/validation";

export async function GET() {
  try {
    const allBatches = await db
      .select()
      .from(batches)
      .orderBy(desc(batches.createdAt));

    const enriched = await Promise.all(
      allBatches.map(async (batch) => {
        const items = await db
          .select()
          .from(batchItems)
          .where(eq(batchItems.batchId, batch.id));
        return { ...batch, items };
      })
    );

    return NextResponse.json({ batches: enriched });
  } catch (error) {
    console.error("GET /api/batches error:", error);
    return NextResponse.json({ error: "Failed to fetch batches" }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { name, description, prompt, size, cta } = body;

    if (!name) {
      return NextResponse.json({ error: "name is required" }, { status: 400 });
    }

    // Determine which transformations to use
    const batchSize = Math.min(size ?? 10, TRANSFORMATIONS.length);

    // Create the batch record
    const [newBatch] = await db
      .insert(batches)
      .values({
        name,
        description: description ?? "",
        prompt: prompt ?? "",
        size: batchSize,
        status: "running",
        startedAt: new Date(),
      })
      .returning();

    if (!newBatch) {
      return NextResponse.json({ error: "Failed to create batch" }, { status: 500 });
    }

    // Process each transformation from library
    let successCount = 0;
    let failureCount = 0;
    let totalCost = 0;

    for (let i = 0; i < batchSize; i++) {
      const libDef = TRANSFORMATIONS[i % TRANSFORMATIONS.length];
      const itemStart = Date.now();

      try {
        const scores = scoreTransformation({
          hook: libDef.hook,
          subject: libDef.subject,
          stepsCount: libDef.steps.length,
          hasVoice: libDef.steps.some((s) => s.voiceLine),
          hasReveal: libDef.steps.some((s) => s.isRevealStep),
        });

        const stepsForValidation = libDef.steps.map((s) => ({
          stepOrder: s.stepOrder,
          label: s.label,
          svgPath: s.svgPaths.map((p) => p.d).join(" "),
          svgViewBox: "0 0 400 400",
          duration: s.duration,
          voiceLine: s.voiceLine ?? "",
          isRevealStep: s.isRevealStep ?? false,
        }));

        const validation = validateDrawingPlan(stepsForValidation);

        // Insert transformation
        const [transformation] = await db
          .insert(transformations)
          .values({
            hook: libDef.hook,
            subject: libDef.subject,
            hookType: libDef.hookType,
            description: libDef.description,
            style: libDef.style,
            language: libDef.language,
            tags: libDef.tags,
            curiosityScore: scores.curiosity,
            simplicityScore: scores.simplicity,
            feasibilityScore: scores.feasibility,
            visualScore: scores.visual,
            retentionScore: scores.retention,
            totalScore: scores.total,
            status: validation.passed ? "validated" : "invalid",
          })
          .returning();

        if (!transformation) throw new Error("Transformation insert failed");

        // Insert steps
        for (const step of libDef.steps) {
          await db.insert(drawingSteps).values({
            transformationId: transformation.id,
            stepOrder: step.stepOrder,
            label: step.label,
            description: step.description ?? "",
            svgPath: step.svgPaths.map((p) => p.d).join(" "),
            svgViewBox: "0 0 400 400",
            duration: step.duration,
            voiceLine: step.voiceLine ?? null,
            isRevealStep: step.isRevealStep ?? false,
          });
        }

        // Create project
        const stepCost = libDef.steps.length * 0.002;
        const [project] = await db
          .insert(projects)
          .values({
            transformationId: transformation.id,
            title: `${libDef.hook} → ${libDef.subject}`,
            seed: 42 + i,
            cta: cta ?? "Xem thêm ở bio.",
            status: validation.passed ? "rendered" : "failed",
            validationPassed: validation.passed,
            validationErrors: validation.errors,
            generationCost: stepCost,
            generationDuration: Date.now() - itemStart,
            exportPath: validation.passed
              ? `/renders/batch_${newBatch.id}_item_${i}.mp4`
              : null,
            metadata: {
              batchId: newBatch.id,
              batchIndex: i,
              generatedAt: new Date().toISOString(),
            },
          })
          .returning();

        totalCost += stepCost;

        await db.insert(batchItems).values({
          batchId: newBatch.id,
          projectId: project?.id ?? null,
          transformationId: transformation.id,
          status: validation.passed ? "success" : "failed",
          errorMessage: validation.passed ? null : validation.errors.join("; "),
          processingDuration: Date.now() - itemStart,
        });

        if (validation.passed) successCount++;
        else failureCount++;
      } catch (itemError) {
        failureCount++;
        await db.insert(batchItems).values({
          batchId: newBatch.id,
          status: "failed",
          errorMessage: String(itemError),
          processingDuration: Date.now() - itemStart,
        });
      }
    }

    // Update batch status
    const [updatedBatch] = await db
      .update(batches)
      .set({
        status: failureCount === batchSize ? "failed" : successCount === batchSize ? "completed" : "partial",
        successCount,
        failureCount,
        totalCost,
        completedAt: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(batches.id, newBatch.id))
      .returning();

    const items = await db
      .select()
      .from(batchItems)
      .where(eq(batchItems.batchId, newBatch.id));

    return NextResponse.json({
      batch: updatedBatch,
      items,
      summary: { successCount, failureCount, totalCost },
    });
  } catch (error) {
    console.error("POST /api/batches error:", error);
    return NextResponse.json({ error: "Failed to create batch" }, { status: 500 });
  }
}
