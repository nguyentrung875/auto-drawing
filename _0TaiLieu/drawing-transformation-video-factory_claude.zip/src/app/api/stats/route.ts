import { NextResponse } from "next/server";
import { db } from "@/db";
import { transformations, projects, batches, batchItems } from "@/db/schema";
import { sql, eq, sum, avg } from "drizzle-orm";

export async function GET() {
  try {
    const [transformationStats] = await db
      .select({
        total: sql<number>`count(*)`,
        validated: sql<number>`count(*) filter (where status = 'validated')`,
        invalid: sql<number>`count(*) filter (where status = 'invalid')`,
        avgScore: avg(transformations.totalScore),
      })
      .from(transformations);

    const [projectStats] = await db
      .select({
        total: sql<number>`count(*)`,
        rendered: sql<number>`count(*) filter (where status = 'rendered')`,
        approved: sql<number>`count(*) filter (where status = 'approved')`,
        published: sql<number>`count(*) filter (where status = 'published')`,
        failed: sql<number>`count(*) filter (where status = 'failed')`,
        totalCost: sum(projects.generationCost),
        avgDuration: avg(projects.targetDuration),
      })
      .from(projects);

    const [batchStats] = await db
      .select({
        total: sql<number>`count(*)`,
        completed: sql<number>`count(*) filter (where status = 'completed')`,
        running: sql<number>`count(*) filter (where status = 'running')`,
        failed: sql<number>`count(*) filter (where status = 'failed')`,
        totalCost: sum(batches.totalCost),
      })
      .from(batches);

    const topTransformations = await db
      .select()
      .from(transformations)
      .orderBy(sql`total_score desc`)
      .limit(5);

    return NextResponse.json({
      transformations: transformationStats,
      projects: projectStats,
      batches: batchStats,
      topTransformations,
    });
  } catch (error) {
    console.error("GET /api/stats error:", error);
    return NextResponse.json({ error: "Failed to fetch stats" }, { status: 500 });
  }
}
