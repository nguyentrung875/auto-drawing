import Link from "next/link";

export default function HomePage() {
  return (
    <main className="min-h-screen bg-gradient-to-br from-orange-50 via-amber-50 to-yellow-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur border-b border-orange-100 sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-orange-400 to-amber-500 flex items-center justify-center text-white font-black text-lg shadow">
              ✏️
            </div>
            <div>
              <div className="font-black text-gray-900 text-lg leading-tight">Drawing Factory</div>
              <div className="text-xs text-orange-600 font-medium">Transformation Video Engine</div>
            </div>
          </div>
          <nav className="flex gap-2">
            <Link href="/studio" className="bg-orange-500 hover:bg-orange-600 text-white text-sm font-bold px-4 py-2 rounded-xl transition-all shadow">
              Vào Studio →
            </Link>
          </nav>
        </div>
      </header>

      {/* Hero */}
      <section className="max-w-4xl mx-auto px-4 pt-20 pb-12 text-center">
        <div className="inline-flex items-center gap-2 bg-orange-100 text-orange-700 text-sm font-bold px-4 py-2 rounded-full mb-6">
          🎬 Content Factory · Short-form Video · Tiếng Việt
        </div>
        <h1 className="text-5xl font-black text-gray-900 leading-tight mb-4">
          Biến hình đơn giản
          <br />
          <span className="text-orange-500">thành video hấp dẫn</span>
        </h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto mb-8">
          Drawing Transformation Video Factory tự động hóa toàn bộ quy trình:
          từ concept → vẽ → voice → video — ở quy mô hàng loạt.
        </p>

        {/* Demo flow */}
        <div className="flex items-center justify-center gap-3 flex-wrap mb-10">
          {["8", "→ tai", "→ mắt", "→ mũi", "→ miệng", "→ 🐻"].map((step, i) => (
            <div key={i} className="flex items-center gap-2">
              <div className={`px-4 py-2 rounded-xl font-bold text-lg shadow ${
                i === 0 ? "bg-orange-500 text-white" :
                i === 5 ? "bg-green-500 text-white" :
                "bg-white border-2 border-orange-200 text-orange-700"
              }`}>
                {step}
              </div>
              {i < 5 && <div className="text-orange-300 font-bold hidden sm:block">·</div>}
            </div>
          ))}
        </div>

        <div className="flex gap-4 justify-center flex-wrap">
          <Link href="/studio" className="bg-orange-500 hover:bg-orange-600 text-white font-black text-lg px-8 py-4 rounded-2xl shadow-lg transition-all hover:shadow-xl hover:-translate-y-0.5">
            🎬 Vào Studio
          </Link>
          <Link href="/studio?tab=library" className="bg-white hover:bg-orange-50 text-orange-600 font-black text-lg px-8 py-4 rounded-2xl border-2 border-orange-200 shadow transition-all">
            📚 Xem Library
          </Link>
        </div>
      </section>

      {/* Features */}
      <section className="max-w-6xl mx-auto px-4 py-12">
        <div className="grid md:grid-cols-3 gap-6">
          {[
            {
              icon: "✏️",
              title: "Deterministic Drawing",
              desc: "Mỗi nét vẽ được xác định bởi geometry thực tế — không phải AI tự do. Drawing animation và final drawing dùng chung source.",
              color: "from-orange-100 to-amber-100 border-orange-200",
            },
            {
              icon: "🎤",
              title: "Vietnamese Voice",
              desc: "Mỗi bước vẽ có voiceline tiếng Việt tương ứng. Từng câu được liên kết với đúng drawing step để sync chính xác.",
              color: "from-blue-100 to-indigo-100 border-blue-200",
            },
            {
              icon: "⚡",
              title: "Batch Production",
              desc: "Tạo hàng chục video từ một batch request. Validation gate ngăn video lỗi trước khi render.",
              color: "from-green-100 to-emerald-100 border-green-200",
            },
            {
              icon: "📊",
              title: "Transformation Scoring",
              desc: "Mỗi concept được tính điểm theo: Curiosity, Simplicity, Feasibility, Visual, Retention — để ưu tiên concept tốt nhất.",
              color: "from-purple-100 to-violet-100 border-purple-200",
            },
            {
              icon: "🔬",
              title: "Content Experiments",
              desc: "Tạo nhiều variant từ một concept: hook khác nhau, voice style khác nhau, CTA khác nhau — để tìm format thắng.",
              color: "from-pink-100 to-rose-100 border-pink-200",
            },
            {
              icon: "🎯",
              title: "Affiliate Ready",
              desc: "Mỗi video có metadata đầy đủ để liên kết với affiliate link. CTA configurable, không hard-code vào renderer.",
              color: "from-yellow-100 to-amber-100 border-yellow-200",
            },
          ].map((f) => (
            <div key={f.title} className={`bg-gradient-to-br ${f.color} border rounded-2xl p-6`}>
              <div className="text-3xl mb-3">{f.icon}</div>
              <h3 className="font-black text-gray-800 text-lg mb-2">{f.title}</h3>
              <p className="text-gray-600 text-sm leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Flow diagram */}
      <section className="max-w-4xl mx-auto px-4 py-12">
        <div className="bg-white rounded-3xl border-2 border-orange-100 p-8 shadow-lg">
          <h2 className="text-2xl font-black text-gray-900 mb-6 text-center">Core Production Flow</h2>
          <div className="flex flex-wrap justify-center gap-0">
            {[
              { label: "Concept", icon: "💡", desc: "hook + subject" },
              { label: "Drawing Plan", icon: "✏️", desc: "steps + geometry" },
              { label: "Validation", icon: "✅", desc: "FR-005 gate" },
              { label: "Video", icon: "🎬", desc: "animation + voice" },
              { label: "Export", icon: "📤", desc: "1080×1920 MP4" },
            ].map((step, i) => (
              <div key={i} className="flex items-center">
                <div className="flex flex-col items-center text-center p-3 min-w-[100px]">
                  <div className="w-12 h-12 rounded-xl bg-orange-100 flex items-center justify-center text-2xl mb-1">
                    {step.icon}
                  </div>
                  <div className="font-bold text-gray-800 text-sm">{step.label}</div>
                  <div className="text-xs text-gray-500">{step.desc}</div>
                </div>
                {i < 4 && <div className="text-orange-300 font-black text-xl mx-1 mb-4">→</div>}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="text-center py-8 text-sm text-gray-400 border-t border-orange-100 mt-8">
        Drawing Transformation Video Factory · MVP v1.0 · Vietnamese-first
      </footer>
    </main>
  );
}
