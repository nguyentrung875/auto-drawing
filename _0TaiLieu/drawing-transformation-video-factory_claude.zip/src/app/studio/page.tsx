"use client";

import { useState, useEffect, useCallback } from "react";
import Link from "next/link";
import DrawingAnimator from "@/components/DrawingAnimator";
import TransformationCard from "@/components/TransformationCard";
import StatsCard from "@/components/StatsCard";
import { TRANSFORMATIONS } from "@/lib/drawing-library";

type Tab = "dashboard" | "library" | "create" | "projects" | "batch";

interface Transformation {
  id: number;
  hook: string;
  subject: string;
  hookType: string;
  description?: string | null;
  status: string;
  totalScore?: number | null;
  curiosityScore?: number | null;
  simplicityScore?: number | null;
  feasibilityScore?: number | null;
  visualScore?: number | null;
  retentionScore?: number | null;
  tags?: string[] | null;
  createdAt: string;
  updatedAt: string;
}

interface DrawingStep {
  id: number;
  stepOrder: number;
  label: string;
  description?: string | null;
  svgPath: string;
  svgViewBox: string;
  duration: number;
  voiceLine?: string | null;
  isRevealStep: boolean;
}

interface Project {
  id: number;
  transformationId: number;
  title: string;
  status: string;
  validationPassed?: boolean | null;
  validationErrors?: string[] | null;
  generationCost?: number | null;
  exportPath?: string | null;
  cta: string;
  targetDuration: number;
  transformation?: Transformation;
  createdAt: string;
}

interface Batch {
  id: number;
  name: string;
  status: string;
  size: number;
  successCount: number;
  failureCount: number;
  totalCost?: number | null;
  createdAt: string;
  items?: Array<{ id: number; status: string }>;
}

interface Stats {
  transformations?: {
    total: number;
    validated: number;
    invalid: number;
    avgScore: number | null;
  };
  projects?: {
    total: number;
    rendered: number;
    approved: number;
    published: number;
    failed: number;
    totalCost: number | null;
  };
  batches?: {
    total: number;
    completed: number;
    totalCost: number | null;
  };
  topTransformations?: Transformation[];
}

export default function StudioPage() {
  const [activeTab, setActiveTab] = useState<Tab>("dashboard");
  const [transformations, setTransformations] = useState<Transformation[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [batches, setBatches] = useState<Batch[]>([]);
  const [stats, setStats] = useState<Stats>({});
  const [selectedTransformation, setSelectedTransformation] = useState<Transformation | null>(null);
  const [selectedSteps, setSelectedSteps] = useState<DrawingStep[]>([]);
  const [previewSpeed, setPreviewSpeed] = useState(1);
  const [loading, setLoading] = useState(false);
  const [seeding, setSeeding] = useState(false);
  const [seedDone, setSeedDone] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [batchName, setBatchName] = useState("Batch mới");
  const [batchSize, setBatchSize] = useState(5);
  const [batchLoading, setBatchLoading] = useState(false);
  const [createHook, setCreateHook] = useState("");
  const [createSubject, setCreateSubject] = useState("");
  const [createCta, setCreateCta] = useState("Xem thêm ở bio.");
  const [createLoading, setCreateLoading] = useState(false);
  const [notification, setNotification] = useState<{ msg: string; type: "success" | "error" } | null>(null);

  const showNotif = (msg: string, type: "success" | "error" = "success") => {
    setNotification({ msg, type });
    setTimeout(() => setNotification(null), 3500);
  };

  const fetchAll = useCallback(async () => {
    try {
      const [tRes, pRes, bRes, sRes] = await Promise.all([
        fetch("/api/transformations"),
        fetch("/api/projects"),
        fetch("/api/batches"),
        fetch("/api/stats"),
      ]);
      if (tRes.ok) {
        const d = await tRes.json();
        setTransformations(d.transformations ?? []);
      }
      if (pRes.ok) {
        const d = await pRes.json();
        setProjects(d.projects ?? []);
      }
      if (bRes.ok) {
        const d = await bRes.json();
        setBatches(d.batches ?? []);
      }
      if (sRes.ok) {
        const d = await sRes.json();
        setStats(d);
      }
    } catch (e) {
      console.error(e);
    }
  }, []);

  useEffect(() => {
    fetchAll();
  }, [fetchAll]);

  async function handleSeedLibrary() {
    setSeeding(true);
    try {
      const res = await fetch("/api/seed", { method: "POST" });
      const d = await res.json();
      if (res.ok) {
        showNotif(`✅ ${d.message}`);
        setSeedDone(true);
        fetchAll();
      } else {
        showNotif(d.error ?? "Seed thất bại", "error");
      }
    } finally {
      setSeeding(false);
    }
  }

  async function handleSelectTransformation(t: Transformation) {
    setSelectedTransformation(t);
    setLoading(true);
    try {
      const res = await fetch(`/api/transformations/${t.id}`);
      if (res.ok) {
        const d = await res.json();
        setSelectedSteps(d.steps ?? []);
      }
    } finally {
      setLoading(false);
    }
  }

  async function handleCreateProject() {
    if (!selectedTransformation) {
      showNotif("Chọn transformation trước", "error");
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("/api/projects", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          transformationId: selectedTransformation.id,
          title: `${selectedTransformation.hook} → ${selectedTransformation.subject}`,
          cta: createCta,
          seed: Math.floor(Math.random() * 9999),
        }),
      });
      if (res.ok) {
        showNotif("✅ Project đã được tạo!");
        fetchAll();
        setActiveTab("projects");
      } else {
        const d = await res.json();
        showNotif(d.error ?? "Tạo project thất bại", "error");
      }
    } finally {
      setLoading(false);
    }
  }

  async function handleRenderProject(projectId: number) {
    setLoading(true);
    try {
      const res = await fetch(`/api/projects/${projectId}/render`, { method: "POST" });
      const d = await res.json();
      if (res.ok && d.success) {
        showNotif("✅ Render thành công!");
        fetchAll();
      } else {
        showNotif(
          d.validation?.errors?.[0] ?? d.error ?? "Render thất bại",
          "error"
        );
      }
    } finally {
      setLoading(false);
    }
  }

  async function handleApproveProject(projectId: number) {
    const res = await fetch(`/api/projects/${projectId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: "approved" }),
    });
    if (res.ok) {
      showNotif("✅ Approved!");
      fetchAll();
    }
  }

  async function handleDeleteProject(projectId: number) {
    if (!confirm("Xóa project này?")) return;
    const res = await fetch(`/api/projects/${projectId}`, { method: "DELETE" });
    if (res.ok) {
      showNotif("🗑️ Đã xóa project");
      fetchAll();
    }
  }

  async function handleCreateFromLibrary() {
    if (!createHook || !createSubject) {
      showNotif("Nhập hook và subject", "error");
      return;
    }
    setCreateLoading(true);
    try {
      const res = await fetch("/api/transformations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ hook: createHook, subject: createSubject }),
      });
      if (res.ok) {
        showNotif("✅ Transformation đã được tạo!");
        fetchAll();
        setCreateHook("");
        setCreateSubject("");
      } else {
        const d = await res.json();
        showNotif(d.error ?? "Tạo thất bại", "error");
      }
    } finally {
      setCreateLoading(false);
    }
  }

  async function handleBatchCreate() {
    setBatchLoading(true);
    try {
      const res = await fetch("/api/batches", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: batchName,
          size: batchSize,
          cta: createCta,
        }),
      });
      if (res.ok) {
        const d = await res.json();
        showNotif(
          `✅ Batch hoàn thành! ${d.summary.successCount}/${batchSize} thành công`
        );
        fetchAll();
      } else {
        const d = await res.json();
        showNotif(d.error ?? "Batch thất bại", "error");
      }
    } finally {
      setBatchLoading(false);
    }
  }

  const filteredTransformations = transformations.filter((t) => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return (
      t.hook.toLowerCase().includes(q) ||
      t.subject.toLowerCase().includes(q) ||
      (t.tags ?? []).some((tag) => tag.toLowerCase().includes(q))
    );
  });

  const tabs: Array<{ id: Tab; label: string; icon: string }> = [
    { id: "dashboard", label: "Dashboard", icon: "📊" },
    { id: "library", label: "Library", icon: "📚" },
    { id: "create", label: "Create", icon: "✏️" },
    { id: "projects", label: "Projects", icon: "🎬" },
    { id: "batch", label: "Batch", icon: "⚡" },
  ];

  const statusColors: Record<string, string> = {
    draft: "bg-gray-100 text-gray-600",
    drawing_planned: "bg-blue-100 text-blue-700",
    validated: "bg-green-100 text-green-700",
    rendering: "bg-yellow-100 text-yellow-700",
    rendered: "bg-emerald-100 text-emerald-700",
    failed: "bg-red-100 text-red-700",
    approved: "bg-purple-100 text-purple-700",
    published: "bg-orange-100 text-orange-700",
    pending: "bg-gray-100 text-gray-600",
    running: "bg-blue-100 text-blue-700",
    completed: "bg-green-100 text-green-700",
    partial: "bg-yellow-100 text-yellow-700",
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-amber-50 to-yellow-50">
      {/* Notification */}
      {notification && (
        <div
          className={`fixed top-4 right-4 z-50 px-5 py-3 rounded-xl shadow-xl font-semibold text-white transition-all ${
            notification.type === "success" ? "bg-green-500" : "bg-red-500"
          }`}
        >
          {notification.msg}
        </div>
      )}

      {/* Header */}
      <header className="bg-white/90 backdrop-blur border-b border-orange-100 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link href="/" className="flex items-center gap-2 hover:opacity-80 transition-opacity">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-orange-400 to-amber-500 flex items-center justify-center text-white font-black shadow">
                ✏️
              </div>
              <span className="font-black text-gray-900">Drawing Factory</span>
            </Link>
            <span className="text-gray-300">·</span>
            <span className="text-orange-600 font-semibold text-sm">Studio</span>
          </div>

          <div className="flex gap-2">
            {!seedDone && transformations.length === 0 && (
              <button
                onClick={handleSeedLibrary}
                disabled={seeding}
                className="bg-orange-100 hover:bg-orange-200 text-orange-700 text-sm font-bold px-4 py-2 rounded-lg transition-all flex items-center gap-2 disabled:opacity-50"
              >
                {seeding ? "⏳ Seeding..." : "🌱 Seed Library"}
              </button>
            )}
            {transformations.length > 0 && (
              <span className="text-sm text-gray-500 bg-gray-100 px-3 py-1.5 rounded-lg">
                {transformations.length} transformations
              </span>
            )}
          </div>
        </div>

        {/* Tabs */}
        <div className="max-w-7xl mx-auto px-4 pb-0 flex gap-1 overflow-x-auto">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2.5 text-sm font-bold rounded-t-xl transition-all whitespace-nowrap border-b-2 ${
                activeTab === tab.id
                  ? "bg-white border-orange-500 text-orange-600"
                  : "border-transparent text-gray-600 hover:text-orange-500 hover:bg-orange-50"
              }`}
            >
              {tab.icon} {tab.label}
            </button>
          ))}
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-6">

        {/* ── DASHBOARD ─────────────────────────────────────────────────── */}
        {activeTab === "dashboard" && (
          <div className="space-y-6">
            <h2 className="text-2xl font-black text-gray-900">Dashboard</h2>

            {transformations.length === 0 ? (
              <div className="bg-white rounded-2xl border-2 border-dashed border-orange-200 p-12 text-center">
                <div className="text-6xl mb-4">🌱</div>
                <h3 className="text-xl font-black text-gray-800 mb-2">Chưa có dữ liệu</h3>
                <p className="text-gray-500 mb-6">Seed library để bắt đầu với {TRANSFORMATIONS.length} transformations có sẵn</p>
                <button
                  onClick={handleSeedLibrary}
                  disabled={seeding}
                  className="bg-orange-500 hover:bg-orange-600 text-white font-bold px-6 py-3 rounded-xl shadow transition-all disabled:opacity-50"
                >
                  {seeding ? "⏳ Đang seed..." : "🌱 Seed Library ngay"}
                </button>
              </div>
            ) : (
              <>
                {/* Stats grid */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <StatsCard
                    label="Transformations"
                    value={stats.transformations?.total ?? 0}
                    sub={`${stats.transformations?.validated ?? 0} validated`}
                    icon="✏️"
                    color="orange"
                  />
                  <StatsCard
                    label="Projects"
                    value={stats.projects?.total ?? 0}
                    sub={`${stats.projects?.rendered ?? 0} rendered`}
                    icon="🎬"
                    color="blue"
                  />
                  <StatsCard
                    label="Batches"
                    value={stats.batches?.total ?? 0}
                    sub={`${stats.batches?.completed ?? 0} completed`}
                    icon="⚡"
                    color="green"
                  />
                  <StatsCard
                    label="Avg Score"
                    value={stats.transformations?.avgScore != null
                      ? Number(stats.transformations.avgScore).toFixed(1)
                      : "–"}
                    sub="transformation quality"
                    icon="⭐"
                    color="purple"
                  />
                </div>

                {/* Top transformations */}
                {(stats.topTransformations ?? []).length > 0 && (
                  <div className="bg-white rounded-2xl border border-orange-100 p-6">
                    <h3 className="font-black text-gray-800 mb-4">🏆 Top Transformations</h3>
                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3">
                      {(stats.topTransformations ?? []).map((t) => (
                        <TransformationCard
                          key={t.id}
                          transformation={t}
                          onClick={() => {
                            setSelectedTransformation(t);
                            setActiveTab("library");
                            handleSelectTransformation(t);
                          }}
                        />
                      ))}
                    </div>
                  </div>
                )}

                {/* Recent projects */}
                {projects.length > 0 && (
                  <div className="bg-white rounded-2xl border border-orange-100 p-6">
                    <h3 className="font-black text-gray-800 mb-4">🎬 Projects gần đây</h3>
                    <div className="space-y-2">
                      {projects.slice(0, 5).map((p) => (
                        <div key={p.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
                          <div>
                            <div className="font-bold text-gray-800 text-sm">{p.title}</div>
                            <div className="text-xs text-gray-500">
                              {new Date(p.createdAt).toLocaleDateString("vi-VN")}
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${statusColors[p.status] ?? "bg-gray-100"}`}>
                              {p.status}
                            </span>
                            {p.status !== "rendered" && p.status !== "approved" && (
                              <button
                                onClick={() => handleRenderProject(p.id)}
                                className="text-xs bg-orange-500 text-white px-2 py-1 rounded-lg font-bold hover:bg-orange-600 transition-all"
                              >
                                Render
                              </button>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </>
            )}
          </div>
        )}

        {/* ── LIBRARY ───────────────────────────────────────────────────── */}
        {activeTab === "library" && (
          <div className="grid lg:grid-cols-2 gap-6">
            {/* Left: transformation list */}
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <h2 className="text-xl font-black text-gray-900">📚 Transformation Library</h2>
                <span className="text-sm bg-orange-100 text-orange-700 px-2 py-0.5 rounded-full font-bold">
                  {filteredTransformations.length}
                </span>
              </div>

              {/* Search */}
              <input
                type="text"
                placeholder="Tìm hook, subject, tags..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-white border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-orange-400 shadow-sm"
              />

              {transformations.length === 0 ? (
                <div className="text-center py-10 text-gray-400">
                  <div className="text-4xl mb-2">📭</div>
                  <p className="text-sm">Chưa có transformation. Seed library trước.</p>
                  <button onClick={handleSeedLibrary} disabled={seeding}
                    className="mt-3 bg-orange-500 text-white text-sm font-bold px-4 py-2 rounded-xl hover:bg-orange-600 transition-all disabled:opacity-50">
                    {seeding ? "⏳ Seeding..." : "🌱 Seed Now"}
                  </button>
                </div>
              ) : (
                <div className="space-y-3 max-h-[calc(100vh-280px)] overflow-y-auto pr-1">
                  {filteredTransformations.map((t) => (
                    <TransformationCard
                      key={t.id}
                      transformation={t}
                      selected={selectedTransformation?.id === t.id}
                      onClick={() => handleSelectTransformation(t)}
                    />
                  ))}
                </div>
              )}
            </div>

            {/* Right: preview */}
            <div className="space-y-4 sticky top-24 self-start">
              {selectedTransformation ? (
                <>
                  <div className="flex items-center justify-between">
                    <h3 className="font-black text-gray-900">
                      Preview: {selectedTransformation.hook} → {selectedTransformation.subject}
                    </h3>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-gray-500">Tốc độ:</span>
                      {[0.5, 1, 1.5, 2].map((s) => (
                        <button
                          key={s}
                          onClick={() => setPreviewSpeed(s)}
                          className={`text-xs px-2 py-1 rounded-lg font-bold transition-all ${
                            previewSpeed === s
                              ? "bg-orange-500 text-white"
                              : "bg-gray-100 text-gray-600 hover:bg-orange-100"
                          }`}
                        >
                          {s}×
                        </button>
                      ))}
                    </div>
                  </div>

                  {loading ? (
                    <div className="flex items-center justify-center h-80 bg-white rounded-2xl border border-gray-200">
                      <div className="text-center text-gray-400">
                        <div className="text-3xl animate-spin">⏳</div>
                        <p className="text-sm mt-2">Tải drawing steps...</p>
                      </div>
                    </div>
                  ) : selectedSteps.length > 0 ? (
                    <div className="bg-white rounded-2xl border border-orange-100 p-6 shadow">
                      <DrawingAnimator
                        key={`${selectedTransformation.id}-${previewSpeed}`}
                        steps={selectedSteps}
                        speed={previewSpeed}
                        hook={selectedTransformation.hook}
                        subject={selectedTransformation.subject}
                        showControls
                        autoPlay={false}
                      />
                    </div>
                  ) : null}

                  {/* Steps list */}
                  {selectedSteps.length > 0 && (
                    <div className="bg-white rounded-2xl border border-gray-100 p-4">
                      <h4 className="font-bold text-gray-700 text-sm mb-3">
                        📋 Drawing Steps ({selectedSteps.length})
                      </h4>
                      <div className="space-y-2">
                        {selectedSteps.map((step) => (
                          <div key={step.id} className="flex items-start gap-3 text-sm">
                            <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-black flex-shrink-0 ${
                              step.isRevealStep ? "bg-green-100 text-green-700" : "bg-orange-100 text-orange-700"
                            }`}>
                              {step.stepOrder}
                            </div>
                            <div className="flex-1">
                              <div className="font-semibold text-gray-800">{step.label}</div>
                              {step.voiceLine && (
                                <div className="text-xs text-blue-600 mt-0.5">
                                  🎤 &ldquo;{step.voiceLine}&rdquo;
                                </div>
                              )}
                            </div>
                            <div className="text-xs text-gray-400 flex-shrink-0">{step.duration}ms</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Create project button */}
                  <button
                    onClick={handleCreateProject}
                    disabled={loading || selectedTransformation.status === "invalid"}
                    className="w-full bg-orange-500 hover:bg-orange-600 text-white font-black py-3 rounded-xl shadow transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    🎬 Tạo Project từ Transformation này
                  </button>
                  {selectedTransformation.status === "invalid" && (
                    <p className="text-xs text-red-500 text-center">Transformation invalid — không thể tạo project.</p>
                  )}
                </>
              ) : (
                <div className="flex flex-col items-center justify-center h-80 bg-white rounded-2xl border-2 border-dashed border-orange-200 text-center p-6">
                  <div className="text-5xl mb-3">👈</div>
                  <p className="font-bold text-gray-700">Chọn một transformation</p>
                  <p className="text-sm text-gray-400 mt-1">để xem drawing animation preview</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* ── CREATE ────────────────────────────────────────────────────── */}
        {activeTab === "create" && (
          <div className="max-w-2xl mx-auto space-y-6">
            <h2 className="text-2xl font-black text-gray-900">✏️ Tạo Transformation</h2>

            {/* Quick create from library */}
            <div className="bg-white rounded-2xl border border-orange-100 p-6 shadow-sm">
              <h3 className="font-black text-gray-800 mb-4">🔍 Tìm trong Library</h3>
              <div className="grid grid-cols-2 gap-3 mb-4">
                <div>
                  <label className="text-xs font-bold text-gray-600 uppercase tracking-wide mb-1 block">Hook</label>
                  <input
                    type="text"
                    placeholder="e.g. 8, A, @"
                    value={createHook}
                    onChange={(e) => setCreateHook(e.target.value)}
                    className="w-full border border-gray-200 rounded-xl px-4 py-2.5 text-2xl font-black text-center focus:outline-none focus:border-orange-400"
                    maxLength={3}
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-gray-600 uppercase tracking-wide mb-1 block">Subject</label>
                  <input
                    type="text"
                    placeholder="e.g. bear, cat, owl"
                    value={createSubject}
                    onChange={(e) => setCreateSubject(e.target.value)}
                    className="w-full border border-gray-200 rounded-xl px-4 py-2.5 text-lg font-semibold focus:outline-none focus:border-orange-400"
                  />
                </div>
              </div>

              {/* Available in library */}
              <div className="mb-4">
                <p className="text-xs font-bold text-gray-500 uppercase tracking-wide mb-2">Có sẵn trong Library:</p>
                <div className="flex flex-wrap gap-2">
                  {TRANSFORMATIONS.map((t) => (
                    <button
                      key={`${t.hook}-${t.subject}`}
                      onClick={() => { setCreateHook(t.hook); setCreateSubject(t.subject); }}
                      className={`px-3 py-1.5 rounded-xl text-sm font-bold border-2 transition-all ${
                        createHook === t.hook && createSubject === t.subject
                          ? "border-orange-500 bg-orange-100 text-orange-700"
                          : "border-gray-200 bg-white text-gray-600 hover:border-orange-300"
                      }`}
                    >
                      {t.hook} → {t.subject}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-gray-600 uppercase tracking-wide mb-1 block">CTA</label>
                <input
                  type="text"
                  value={createCta}
                  onChange={(e) => setCreateCta(e.target.value)}
                  className="w-full border border-gray-200 rounded-xl px-4 py-2.5 focus:outline-none focus:border-orange-400"
                />
              </div>

              <button
                onClick={handleCreateFromLibrary}
                disabled={createLoading || !createHook || !createSubject}
                className="mt-4 w-full bg-orange-500 hover:bg-orange-600 text-white font-black py-3 rounded-xl shadow transition-all disabled:opacity-50"
              >
                {createLoading ? "⏳ Đang tạo..." : "✅ Tạo Transformation"}
              </button>
            </div>

            {/* Live preview */}
            {createHook && createSubject && (() => {
              const libDef = TRANSFORMATIONS.find(
                (t) => t.hook.toLowerCase() === createHook.toLowerCase() && t.subject.toLowerCase() === createSubject.toLowerCase()
              );
              if (!libDef) return (
                <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4 text-sm text-yellow-700">
                  ⚠️ &ldquo;{createHook} → {createSubject}&rdquo; chưa có trong library. Chọn từ danh sách trên.
                </div>
              );
              return (
                <div className="bg-white rounded-2xl border border-orange-100 p-6 shadow-sm">
                  <h3 className="font-black text-gray-800 mb-4">🎬 Preview</h3>
                  <DrawingAnimator
                    key={`create-${createHook}-${createSubject}`}
                    steps={libDef.steps.map((s, i) => ({
                      id: i,
                      stepOrder: s.stepOrder,
                      label: s.label,
                      description: s.description,
                      svgPaths: s.svgPaths,
                      svgPath: s.svgPaths.map(p => p.d).join(" "),
                      duration: s.duration,
                      voiceLine: s.voiceLine,
                      isRevealStep: s.isRevealStep,
                      svgViewBox: "0 0 400 400",
                    }))}
                    hook={createHook}
                    subject={createSubject}
                    cta={createCta}
                    showControls
                  />
                </div>
              );
            })()}
          </div>
        )}

        {/* ── PROJECTS ──────────────────────────────────────────────────── */}
        {activeTab === "projects" && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-black text-gray-900">🎬 Projects</h2>
              <button
                onClick={() => setActiveTab("library")}
                className="bg-orange-500 hover:bg-orange-600 text-white text-sm font-bold px-4 py-2 rounded-xl transition-all"
              >
                + Tạo Project mới
              </button>
            </div>

            {projects.length === 0 ? (
              <div className="text-center py-16 bg-white rounded-2xl border-2 border-dashed border-gray-200">
                <div className="text-5xl mb-3">🎬</div>
                <p className="font-bold text-gray-700">Chưa có project nào</p>
                <p className="text-sm text-gray-400 mt-1">Vào Library để chọn transformation và tạo project</p>
              </div>
            ) : (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                {projects.map((p) => (
                  <div key={p.id} className="bg-white rounded-2xl border border-gray-200 p-5 shadow-sm hover:shadow-md transition-all">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <div className="font-black text-gray-800">{p.title}</div>
                        <div className="text-xs text-gray-500 mt-0.5">
                          {new Date(p.createdAt).toLocaleDateString("vi-VN", { day: "2-digit", month: "2-digit", year: "numeric" })}
                        </div>
                      </div>
                      <span className={`text-xs px-2 py-1 rounded-full font-bold ${statusColors[p.status] ?? "bg-gray-100 text-gray-600"}`}>
                        {p.status}
                      </span>
                    </div>

                    {p.validationErrors && p.validationErrors.length > 0 && (
                      <div className="bg-red-50 rounded-lg p-2 mb-3">
                        {p.validationErrors.slice(0, 2).map((e, i) => (
                          <div key={i} className="text-xs text-red-600">• {e}</div>
                        ))}
                      </div>
                    )}

                    <div className="flex items-center gap-2 text-xs text-gray-500 mb-3">
                      <span>⏱ {p.targetDuration}s</span>
                      <span>·</span>
                      <span>💬 {p.cta.substring(0, 20)}...</span>
                      {p.generationCost != null && (
                        <>
                          <span>·</span>
                          <span>💰 ${Number(p.generationCost).toFixed(3)}</span>
                        </>
                      )}
                    </div>

                    {p.exportPath && (
                      <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-2 mb-3 text-xs text-emerald-700 font-mono">
                        📁 {p.exportPath}
                      </div>
                    )}

                    <div className="flex gap-2 flex-wrap">
                      {p.status === "drawing_planned" || p.status === "draft" ? (
                        <button
                          onClick={() => handleRenderProject(p.id)}
                          disabled={loading}
                          className="flex-1 bg-orange-500 hover:bg-orange-600 text-white text-sm font-bold py-2 rounded-xl transition-all disabled:opacity-50"
                        >
                          🎬 Render
                        </button>
                      ) : p.status === "rendered" ? (
                        <button
                          onClick={() => handleApproveProject(p.id)}
                          className="flex-1 bg-green-500 hover:bg-green-600 text-white text-sm font-bold py-2 rounded-xl transition-all"
                        >
                          ✅ Approve
                        </button>
                      ) : null}
                      <button
                        onClick={() => handleDeleteProject(p.id)}
                        className="bg-red-50 hover:bg-red-100 text-red-600 text-sm font-bold px-3 py-2 rounded-xl transition-all"
                      >
                        🗑
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ── BATCH ─────────────────────────────────────────────────────── */}
        {activeTab === "batch" && (
          <div className="max-w-3xl mx-auto space-y-6">
            <h2 className="text-2xl font-black text-gray-900">⚡ Batch Production</h2>

            {/* Create batch */}
            <div className="bg-white rounded-2xl border border-orange-100 p-6 shadow-sm">
              <h3 className="font-black text-gray-800 mb-4">Tạo Batch mới</h3>
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="text-xs font-bold text-gray-600 uppercase tracking-wide mb-1 block">Tên batch</label>
                  <input
                    type="text"
                    value={batchName}
                    onChange={(e) => setBatchName(e.target.value)}
                    className="w-full border border-gray-200 rounded-xl px-4 py-2.5 focus:outline-none focus:border-orange-400"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-gray-600 uppercase tracking-wide mb-1 block">
                    Số lượng (max {TRANSFORMATIONS.length})
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={TRANSFORMATIONS.length}
                    value={batchSize}
                    onChange={(e) => setBatchSize(Math.min(TRANSFORMATIONS.length, Math.max(1, parseInt(e.target.value) || 1)))}
                    className="w-full border border-gray-200 rounded-xl px-4 py-2.5 focus:outline-none focus:border-orange-400"
                  />
                </div>
              </div>

              <div className="bg-orange-50 border border-orange-200 rounded-xl p-4 mb-4">
                <div className="text-sm text-orange-700">
                  <strong>⚡ Batch sẽ xử lý:</strong>
                  <ul className="mt-1 space-y-0.5 text-xs">
                    <li>• Tạo {batchSize} transformation từ library</li>
                    <li>• Chạy validation cho từng drawing plan</li>
                    <li>• Tạo project cho từng transformation valid</li>
                    <li>• Simulate render và tạo export path</li>
                    <li>• Ước tính chi phí: ~${(batchSize * 0.01).toFixed(2)}</li>
                  </ul>
                </div>
              </div>

              <button
                onClick={handleBatchCreate}
                disabled={batchLoading || !batchName}
                className="w-full bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white font-black py-3 rounded-xl shadow transition-all disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {batchLoading ? (
                  <>
                    <span className="animate-spin">⏳</span>
                    Đang xử lý {batchSize} items...
                  </>
                ) : (
                  <>⚡ Chạy Batch ({batchSize} videos)</>
                )}
              </button>
            </div>

            {/* Batch history */}
            {batches.length > 0 && (
              <div className="bg-white rounded-2xl border border-gray-100 p-6">
                <h3 className="font-black text-gray-800 mb-4">📜 Lịch sử Batch</h3>
                <div className="space-y-3">
                  {batches.map((b) => (
                    <div key={b.id} className="border border-gray-200 rounded-xl p-4">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <div className="font-bold text-gray-800">{b.name}</div>
                          <div className="text-xs text-gray-500">
                            {new Date(b.createdAt).toLocaleDateString("vi-VN", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" })}
                          </div>
                        </div>
                        <span className={`text-xs px-2 py-1 rounded-full font-bold ${statusColors[b.status] ?? "bg-gray-100 text-gray-600"}`}>
                          {b.status}
                        </span>
                      </div>
                      <div className="flex gap-4 text-sm">
                        <div className="text-green-600 font-bold">✅ {b.successCount} thành công</div>
                        <div className="text-red-500 font-bold">❌ {b.failureCount} thất bại</div>
                        <div className="text-gray-500">📦 {b.size} items</div>
                        {b.totalCost != null && (
                          <div className="text-gray-500">💰 ${Number(b.totalCost).toFixed(3)}</div>
                        )}
                      </div>

                      {/* Progress bar */}
                      <div className="mt-2 h-2 bg-gray-100 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-green-400 rounded-full transition-all"
                          style={{ width: `${(b.successCount / b.size) * 100}%` }}
                        />
                      </div>
                      <div className="text-xs text-gray-400 mt-1">
                        {Math.round((b.successCount / b.size) * 100)}% success rate
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
