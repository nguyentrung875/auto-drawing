"use client";

interface StatsCardProps {
  label: string;
  value: string | number;
  sub?: string;
  icon?: string;
  color?: "orange" | "green" | "blue" | "purple" | "red";
}

const colorMap = {
  orange: "from-orange-400 to-orange-600",
  green: "from-green-400 to-green-600",
  blue: "from-blue-400 to-blue-600",
  purple: "from-purple-400 to-purple-600",
  red: "from-red-400 to-red-600",
};

export default function StatsCard({
  label,
  value,
  sub,
  icon = "📊",
  color = "orange",
}: StatsCardProps) {
  return (
    <div className={`bg-gradient-to-br ${colorMap[color]} rounded-2xl p-4 text-white shadow-lg`}>
      <div className="text-2xl mb-1">{icon}</div>
      <div className="text-3xl font-black">{value}</div>
      <div className="text-sm font-semibold opacity-90">{label}</div>
      {sub && <div className="text-xs opacity-70 mt-1">{sub}</div>}
    </div>
  );
}
