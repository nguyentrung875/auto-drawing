"use client";

import { useState, useEffect, useRef, useCallback } from "react";

interface SVGPathDef {
  d: string;
  stroke?: string;
  strokeWidth?: number;
  fill?: string;
  id?: string;
}

interface DrawingStep {
  id?: number;
  stepOrder: number;
  label: string;
  description?: string | null;
  svgPaths?: SVGPathDef[];
  svgPath?: string;
  duration: number;
  voiceLine?: string | null;
  isRevealStep?: boolean;
}

interface DrawingAnimatorProps {
  steps: DrawingStep[];
  autoPlay?: boolean;
  showControls?: boolean;
  onComplete?: () => void;
  speed?: number; // multiplier: 0.5 = half speed, 2 = double speed
  hook?: string;
  subject?: string;
  cta?: string;
}

type AnimPhase = "idle" | "hook" | "drawing" | "reveal" | "cta" | "done";

export default function DrawingAnimator({
  steps,
  autoPlay = false,
  showControls = true,
  onComplete,
  speed = 1,
  hook = "",
  subject = "",
  cta = "Xem thêm ở bio.",
}: DrawingAnimatorProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [phase, setPhase] = useState<AnimPhase>("idle");
  const [completedPaths, setCompletedPaths] = useState<SVGPathDef[][]>([]);
  const [animating, setAnimating] = useState(false);
  const [strokeDashoffset, setStrokeDashoffset] = useState(1000);
  const [currentPathLength, setCurrentPathLength] = useState(1000);
  const animRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const pathRefs = useRef<Map<string, SVGPathElement>>(new Map());
  const [isPlaying, setIsPlaying] = useState(false);

  const parsedSteps: DrawingStep[] = steps.map((s) => ({
    ...s,
    svgPaths: s.svgPaths ?? parseSvgPath(s.svgPath ?? ""),
  }));

  function parseSvgPath(raw: string): SVGPathDef[] {
    if (!raw) return [];
    // raw may be multiple paths concatenated — split on M (new subpath starts)
    const segments = raw
      .split(/(?=M\s)/)
      .filter((s) => s.trim())
      .map((d, i) => ({
        d: d.trim(),
        stroke: "#333",
        strokeWidth: 8,
        fill: "none",
        id: `auto_${i}`,
      }));
    return segments;
  }

  const getStepPaths = useCallback(
    (stepIndex: number): SVGPathDef[] => {
      const step = parsedSteps[stepIndex];
      if (!step) return [];
      return step.svgPaths ?? parseSvgPath(step.svgPath ?? "");
    },
    [parsedSteps]
  );

  const runAnimation = useCallback(async () => {
    if (parsedSteps.length === 0) return;

    setIsPlaying(true);
    setPhase("hook");
    setCompletedPaths([]);
    setCurrentStep(0);

    // Hook phase
    await delay(1500 / speed);

    setPhase("drawing");

    for (let i = 0; i < parsedSteps.length; i++) {
      setCurrentStep(i);
      setAnimating(true);

      const step = parsedSteps[i];
      const stepDuration = step.duration / speed;

      // Animate stroke-dashoffset from full to 0 for drawing effect
      const steps_count = 40;
      const stepTime = stepDuration / steps_count;

      for (let f = steps_count; f >= 0; f--) {
        setStrokeDashoffset((f / steps_count) * currentPathLength);
        await delay(stepTime);
      }

      setAnimating(false);

      // Add to completed paths
      setCompletedPaths((prev) => {
        const newPaths = [...prev];
        newPaths[i] = getStepPaths(i);
        return newPaths;
      });

      // Pause between steps
      if (i < parsedSteps.length - 1) {
        await delay(300 / speed);
      }
    }

    // Reveal phase
    setPhase("reveal");
    await delay(1200 / speed);

    // CTA phase
    setPhase("cta");
    await delay(2000 / speed);

    setPhase("done");
    setIsPlaying(false);
    onComplete?.();
  }, [parsedSteps, speed, currentPathLength, getStepPaths, onComplete]);

  function delay(ms: number) {
    return new Promise<void>((resolve) => {
      animRef.current = setTimeout(resolve, ms);
    });
  }

  function resetAnimation() {
    if (animRef.current) clearTimeout(animRef.current);
    setPhase("idle");
    setCurrentStep(0);
    setCompletedPaths([]);
    setAnimating(false);
    setStrokeDashoffset(1000);
    setIsPlaying(false);
  }

  useEffect(() => {
    if (autoPlay) {
      const t = setTimeout(() => runAnimation(), 500);
      return () => clearTimeout(t);
    }
  }, [autoPlay, runAnimation]);

  useEffect(() => {
    return () => {
      if (animRef.current) clearTimeout(animRef.current);
    };
  }, []);

  const currentStepData = parsedSteps[currentStep];
  const currentPaths = getStepPaths(currentStep);
  const revealStep = parsedSteps.find((s) => s.isRevealStep) ?? parsedSteps[parsedSteps.length - 1];

  return (
    <div className="flex flex-col items-center gap-4">
      {/* Canvas */}
      <div className="relative bg-amber-50 border-2 border-amber-200 rounded-2xl overflow-hidden shadow-xl"
           style={{ width: 340, height: 340 }}>

        {/* Paper texture lines */}
        <div className="absolute inset-0 opacity-20"
          style={{
            backgroundImage: "repeating-linear-gradient(0deg, transparent, transparent 27px, #c4a35a 27px, #c4a35a 28px)",
          }}
        />

        <svg
          viewBox="0 0 400 400"
          width="340"
          height="340"
          className="relative z-10"
        >
          {/* Completed paths from all previous steps */}
          {completedPaths.map((paths, stepIdx) =>
            paths?.map((p, pathIdx) => (
              <path
                key={`completed-${stepIdx}-${pathIdx}`}
                d={p.d}
                stroke={p.stroke ?? "#333"}
                strokeWidth={p.strokeWidth ?? 8}
                fill={p.fill ?? "none"}
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            ))
          )}

          {/* Currently animating path */}
          {(phase === "drawing" || phase === "reveal") &&
            animating &&
            currentPaths.map((p, idx) => (
              <path
                key={`current-${idx}`}
                ref={(el) => {
                  if (el) pathRefs.current.set(`current-${idx}`, el);
                }}
                d={p.d}
                stroke={p.stroke ?? "#333"}
                strokeWidth={p.strokeWidth ?? 8}
                fill="none"
                strokeLinecap="round"
                strokeLinejoin="round"
                style={{
                  strokeDasharray: 1000,
                  strokeDashoffset: strokeDashoffset,
                  transition: "none",
                }}
              />
            ))}

          {/* Pen tip indicator */}
          {phase === "drawing" && animating && (
            <circle cx="200" cy="200" r="6" fill="#e07000" opacity="0.8">
              <animateMotion
                dur={`${(currentStepData?.duration ?? 1000) / speed / 1000}s`}
                repeatCount="1"
                path={currentPaths[0]?.d ?? "M 200 200"}
              />
            </circle>
          )}

          {/* Hook phase overlay */}
          {phase === "hook" && (
            <text
              x="200"
              y="230"
              textAnchor="middle"
              fontSize="160"
              fontWeight="bold"
              fill="#333"
              opacity="0.15"
            >
              {hook}
            </text>
          )}
        </svg>

        {/* Phase overlays */}
        {phase === "hook" && (
          <div className="absolute inset-0 flex flex-col items-center justify-center z-20 bg-amber-50/80">
            <div className="text-8xl font-black text-gray-800 animate-bounce">{hook}</div>
            <div className="text-lg font-semibold text-amber-700 mt-2">
              Số <strong>{hook}</strong> này sẽ biến thành gì?
            </div>
          </div>
        )}

        {phase === "reveal" && (
          <div className="absolute inset-0 flex items-center justify-center z-20 pointer-events-none">
            <div className="text-4xl animate-ping-once">✨</div>
          </div>
        )}

        {phase === "cta" && (
          <div className="absolute bottom-4 left-0 right-0 flex justify-center z-20">
            <div className="bg-orange-500 text-white text-sm font-bold px-4 py-2 rounded-full shadow-lg animate-bounce">
              {cta}
            </div>
          </div>
        )}

        {phase === "done" && (
          <div className="absolute top-3 right-3 z-20">
            <span className="bg-green-500 text-white text-xs font-bold px-2 py-1 rounded-full">
              ✓ Hoàn thành
            </span>
          </div>
        )}
      </div>

      {/* Step progress */}
      {phase === "drawing" && (
        <div className="flex gap-1.5 flex-wrap justify-center max-w-xs">
          {parsedSteps.map((step, i) => (
            <div
              key={i}
              className={`flex items-center gap-1 text-xs px-2 py-1 rounded-full border transition-all ${
                i < currentStep
                  ? "bg-green-100 border-green-300 text-green-700"
                  : i === currentStep
                  ? "bg-orange-100 border-orange-400 text-orange-700 font-bold animate-pulse"
                  : "bg-gray-100 border-gray-200 text-gray-400"
              }`}
            >
              {i < currentStep ? "✓" : i === currentStep ? "✏️" : "○"}{" "}
              {step.label}
            </div>
          ))}
        </div>
      )}

      {/* Voice line */}
      {phase === "drawing" && currentStepData?.voiceLine && (
        <div className="bg-blue-50 border border-blue-200 rounded-xl px-4 py-2 text-center text-sm text-blue-700 font-medium max-w-xs">
          🎤 &ldquo;{currentStepData.voiceLine}&rdquo;
        </div>
      )}

      {/* Controls */}
      {showControls && (
        <div className="flex gap-3">
          {phase === "idle" || phase === "done" ? (
            <button
              onClick={runAnimation}
              disabled={isPlaying}
              className="bg-orange-500 hover:bg-orange-600 text-white font-bold px-6 py-2.5 rounded-xl shadow transition-all flex items-center gap-2 disabled:opacity-50"
            >
              ▶ {phase === "done" ? "Chạy lại" : "Bắt đầu"}
            </button>
          ) : (
            <button
              onClick={resetAnimation}
              className="bg-gray-200 hover:bg-gray-300 text-gray-700 font-bold px-6 py-2.5 rounded-xl transition-all"
            >
              ↺ Reset
            </button>
          )}

          {/* Speed control */}
          <div className="flex items-center gap-2 bg-gray-100 rounded-xl px-3">
            <span className="text-xs text-gray-500">Tốc độ</span>
            <span className="text-sm font-bold text-gray-700">{speed}×</span>
          </div>
        </div>
      )}

      {/* Subject reveal */}
      {(phase === "reveal" || phase === "cta" || phase === "done") && (
        <div className="text-center animate-fade-in">
          <div className="text-2xl font-black text-gray-800 capitalize">
            {hook} → {subject}
          </div>
          <div className="text-sm text-gray-500 mt-1">
            {revealStep?.voiceLine ?? "Tuyệt vời! 🎉"}
          </div>
        </div>
      )}
    </div>
  );
}
