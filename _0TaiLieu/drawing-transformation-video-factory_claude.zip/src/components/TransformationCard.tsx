"use client";

interface Transformation {
  id: number;
  hook: string;
  subject: string;
  hookType: string;
  description?: string | null;
  status: string;
  totalScore?: number | null;
  curiosityScore?: number | null;
  simplicityScore?: number | null;
  tags?: string[] | null;
  createdAt: string | Date;
}

interface TransformationCardProps {
  transformation: Transformation;
  onClick?: () => void;
  selected?: boolean;
}

const hookTypeColors: Record<string, string> = {
  number: "bg-blue-100 text-blue-700",
  letter: "bg-purple-100 text-purple-700",
  symbol: "bg-orange-100 text-orange-700",
  geometry: "bg-green-100 text-green-700",
  combination: "bg-pink-100 text-pink-700",
};

const statusColors: Record<string, string> = {
  draft: "bg-gray-100 text-gray-600",
  validated: "bg-green-100 text-green-700",
  invalid: "bg-red-100 text-red-700",
  archived: "bg-gray-100 text-gray-500",
};

export default function TransformationCard({
  transformation,
  onClick,
  selected,
}: TransformationCardProps) {
  const score = transformation.totalScore ?? 0;
  const scoreColor =
    score >= 8 ? "text-green-600" : score >= 6 ? "text-orange-500" : "text-red-500";

  return (
    <div
      onClick={onClick}
      className={`rounded-2xl border-2 p-4 cursor-pointer transition-all hover:shadow-lg ${
        selected
          ? "border-orange-400 bg-orange-50 shadow-md"
          : "border-gray-200 bg-white hover:border-orange-200"
      }`}
    >
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-center gap-3">
          {/* Hook display */}
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-orange-100 to-amber-200 flex items-center justify-center text-2xl font-black text-orange-700 border border-orange-200 flex-shrink-0">
            {transformation.hook}
          </div>
          <div>
            <div className="font-bold text-gray-800 capitalize">
              {transformation.hook} → {transformation.subject}
            </div>
            <div className="text-xs text-gray-500 mt-0.5 line-clamp-1">
              {transformation.description ?? `${transformation.hook} biến thành ${transformation.subject}`}
            </div>
          </div>
        </div>

        {/* Score */}
        <div className={`text-xl font-black ${scoreColor} flex-shrink-0`}>
          {score}/10
        </div>
      </div>

      <div className="flex flex-wrap gap-1.5 mt-3">
        <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${hookTypeColors[transformation.hookType] ?? "bg-gray-100 text-gray-600"}`}>
          {transformation.hookType}
        </span>
        <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${statusColors[transformation.status] ?? "bg-gray-100 text-gray-600"}`}>
          {transformation.status}
        </span>
        {(transformation.tags ?? []).slice(0, 2).map((tag) => (
          <span key={tag} className="text-xs px-2 py-0.5 rounded-full bg-gray-100 text-gray-600">
            {tag}
          </span>
        ))}
      </div>

      {/* Score bars */}
      <div className="mt-3 grid grid-cols-2 gap-1">
        {[
          { label: "Tò mò", value: transformation.curiosityScore ?? 0 },
          { label: "Đơn giản", value: transformation.simplicityScore ?? 0 },
        ].map((item) => (
          <div key={item.label} className="flex items-center gap-1.5">
            <span className="text-xs text-gray-500 w-14">{item.label}</span>
            <div className="flex-1 h-1.5 bg-gray-200 rounded-full overflow-hidden">
              <div
                className="h-full bg-orange-400 rounded-full"
                style={{ width: `${(item.value / 10) * 100}%` }}
              />
            </div>
            <span className="text-xs font-bold text-gray-600 w-4">{item.value}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
