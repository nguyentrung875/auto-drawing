// ─── Drawing Validation Engine ────────────────────────────────────────────────
// Validates drawing plans before rendering to catch errors early.

export interface ValidationResult {
  passed: boolean;
  errors: string[];
  warnings: string[];
}

export interface DrawingStepInput {
  stepOrder: number;
  label: string;
  svgPath: string;
  svgViewBox: string;
  duration: number;
  voiceLine?: string | null;
  isRevealStep?: boolean;
}

const CANVAS_W = 400;
const CANVAS_H = 400;

/** Parse a simple SVG viewBox like "0 0 400 400" */
function parseViewBox(vb: string): { x: number; y: number; w: number; h: number } | null {
  const parts = vb.trim().split(/\s+|,/).map(Number);
  if (parts.length !== 4 || parts.some(isNaN)) return null;
  return { x: parts[0], y: parts[1], w: parts[2], h: parts[3] };
}

/** Extract all numeric coordinates from an SVG path string */
function extractCoordinates(d: string): number[][] {
  const coords: number[][] = [];
  // Match pairs of numbers (x,y) after SVG command letters
  const re = /([ML])\s*([\d.+-]+)[,\s]+([\d.+-]+)/gi;
  let m: RegExpExecArray | null;
  while ((m = re.exec(d)) !== null) {
    coords.push([parseFloat(m[2]), parseFloat(m[3])]);
  }
  return coords;
}

/** Very basic SVG path syntax check */
function isValidSvgPath(d: string): boolean {
  if (!d || d.trim() === "") return false;
  // Must start with a valid command
  if (!/^[MmLlHhVvCcSsQqTtAaZz]/.test(d.trim())) return false;
  // Must contain at least one pair of coordinates
  if (!/\d/.test(d)) return false;
  return true;
}

export function validateDrawingPlan(steps: DrawingStepInput[]): ValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  if (!steps || steps.length === 0) {
    return {
      passed: false,
      errors: ["Drawing plan must have at least one step."],
      warnings: [],
    };
  }

  if (steps.length < 3) {
    warnings.push("Drawing plan has fewer than 3 steps. Consider adding more detail.");
  }

  const orders = steps.map((s) => s.stepOrder);
  const uniqueOrders = new Set(orders);
  if (uniqueOrders.size !== orders.length) {
    errors.push("Duplicate step orders found. Each step must have a unique order.");
  }

  const sortedOrders = [...orders].sort((a, b) => a - b);
  for (let i = 0; i < sortedOrders.length; i++) {
    if (sortedOrders[i] !== i + 1) {
      errors.push(`Step orders must be sequential starting at 1. Found gap at position ${i + 1}.`);
      break;
    }
  }

  const revealSteps = steps.filter((s) => s.isRevealStep);
  if (revealSteps.length === 0) {
    warnings.push("No reveal step defined. The last step will be treated as the reveal.");
  }
  if (revealSteps.length > 1) {
    warnings.push("Multiple reveal steps defined. Only the last one will be used.");
  }

  for (const step of steps) {
    const prefix = `Step ${step.stepOrder} (${step.label})`;

    if (!step.label || step.label.trim() === "") {
      errors.push(`${prefix}: Label is required.`);
    }

    if (!step.svgPath || step.svgPath.trim() === "") {
      errors.push(`${prefix}: SVG path is required.`);
      continue;
    }

    // Validate each path segment (separated by M commands)
    const pathSegments = step.svgPath.split(/(?=[Mm])/).filter((s) => s.trim());
    for (const seg of pathSegments) {
      if (!isValidSvgPath(seg.trim())) {
        errors.push(`${prefix}: Invalid SVG path syntax: "${seg.substring(0, 50)}..."`);
      }
    }

    if (step.duration <= 0) {
      errors.push(`${prefix}: Duration must be a positive number (ms).`);
    }

    if (step.duration > 10000) {
      warnings.push(`${prefix}: Duration is very long (${step.duration}ms). Consider splitting.`);
    }

    // Validate viewBox
    const vb = parseViewBox(step.svgViewBox);
    if (!vb) {
      errors.push(`${prefix}: Invalid viewBox format. Expected "x y w h".`);
    }

    // Check coordinates are within canvas bounds (with tolerance)
    const coords = extractCoordinates(step.svgPath);
    const margin = 50; // allow slight overflow
    for (const [x, y] of coords) {
      if (vb) {
        if (x < vb.x - margin || x > vb.x + vb.w + margin) {
          warnings.push(`${prefix}: Coordinate x=${x} may be outside canvas bounds.`);
          break;
        }
        if (y < vb.y - margin || y > vb.y + vb.h + margin) {
          warnings.push(`${prefix}: Coordinate y=${y} may be outside canvas bounds.`);
          break;
        }
      }
    }

    if (!step.voiceLine || step.voiceLine.trim() === "") {
      warnings.push(`${prefix}: No voice line defined.`);
    }
  }

  return {
    passed: errors.length === 0,
    errors,
    warnings,
  };
}

export function scoreTransformation(params: {
  hook: string;
  subject: string;
  stepsCount: number;
  hasVoice: boolean;
  hasReveal: boolean;
}): {
  curiosity: number;
  simplicity: number;
  feasibility: number;
  visual: number;
  retention: number;
  total: number;
} {
  const { hook, subject, stepsCount, hasVoice, hasReveal } = params;

  // Simplicity: shorter hooks are more curious
  const simplicity = hook.length === 1 ? 10 : hook.length === 2 ? 7 : 5;

  // Feasibility based on step count
  const feasibility = stepsCount >= 4 && stepsCount <= 8 ? 10 : stepsCount < 4 ? 6 : 7;

  // Curiosity: numbers and symbols tend to score higher
  const isNumber = /^\d$/.test(hook);
  const isSymbol = /^[@$&%#+×÷]$/.test(hook);
  const curiosity = isNumber ? 9 : isSymbol ? 8 : 7;

  // Visual: animals tend to score higher
  const animalSubjects = ["bear", "cat", "dog", "bird", "owl", "fox", "rabbit", "fish", "snake"];
  const visual = animalSubjects.includes(subject.toLowerCase()) ? 8 : 7;

  // Retention: voice + reveal boost retention
  const retention = (hasVoice ? 1 : 0) * 2 + (hasReveal ? 1 : 0) * 2 + 6;

  const total = Math.round((curiosity + simplicity + feasibility + visual + retention) / 5);

  return { curiosity, simplicity, feasibility, visual, retention, total };
}
