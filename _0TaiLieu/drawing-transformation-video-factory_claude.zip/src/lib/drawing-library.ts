// ─── Drawing Library ──────────────────────────────────────────────────────────
// Each transformation defines the hook, subject, and ordered drawing steps.
// Each step has deterministic SVG path geometry.
// The final drawing IS the accumulation of all previous steps' geometry.

export interface DrawingStepDef {
  stepOrder: number;
  label: string;
  description: string;
  /** Cumulative SVG <path> d attributes — each step ADDS to the previous */
  svgPaths: SVGPathDef[];
  duration: number; // ms to animate this step
  voiceLine: string;
  isRevealStep?: boolean;
}

export interface SVGPathDef {
  d: string;
  stroke?: string;
  strokeWidth?: number;
  fill?: string;
  id?: string;
}

export interface TransformationDef {
  hook: string;
  subject: string;
  hookType: "number" | "letter" | "symbol" | "geometry" | "combination";
  description: string;
  style: string;
  language: string;
  tags: string[];
  curiosityScore: number;
  simplicityScore: number;
  feasibilityScore: number;
  visualScore: number;
  retentionScore: number;
  steps: DrawingStepDef[];
}

export const TRANSFORMATIONS: TransformationDef[] = [
  // ── 8 → Bear ──────────────────────────────────────────────────────────────
  {
    hook: "8",
    subject: "bear",
    hookType: "number",
    description: "Số 8 biến thành gấu dễ thương",
    style: "cute_simple",
    language: "vi",
    tags: ["animal", "cute", "bear", "number"],
    curiosityScore: 9,
    simplicityScore: 9,
    feasibilityScore: 10,
    visualScore: 8,
    retentionScore: 9,
    steps: [
      {
        stepOrder: 1,
        label: "Số 8",
        description: "Vẽ số 8 làm thân",
        svgPaths: [
          {
            d: "M 200 120 C 200 80 160 60 140 80 C 120 100 120 140 140 155 C 160 170 200 170 200 170 C 200 170 240 170 260 155 C 280 140 280 100 260 80 C 240 60 200 80 200 120 C 200 120 200 170 200 170 C 200 210 160 250 140 265 C 120 280 120 300 140 310 C 160 320 240 320 260 310 C 280 300 280 280 260 265 C 240 250 200 210 200 170",
            stroke: "#333",
            strokeWidth: 8,
            fill: "none",
            id: "body",
          },
        ],
        duration: 1200,
        voiceLine: "Bắt đầu với số tám.",
      },
      {
        stepOrder: 2,
        label: "Tai trái",
        description: "Thêm tai trái",
        svgPaths: [
          {
            d: "M 145 72 C 130 50 110 45 108 60 C 106 75 125 85 145 80",
            stroke: "#333",
            strokeWidth: 8,
            fill: "none",
            id: "left-ear",
          },
        ],
        duration: 600,
        voiceLine: "Thêm tai trái.",
      },
      {
        stepOrder: 3,
        label: "Tai phải",
        description: "Thêm tai phải",
        svgPaths: [
          {
            d: "M 255 72 C 270 50 290 45 292 60 C 294 75 275 85 255 80",
            stroke: "#333",
            strokeWidth: 8,
            fill: "none",
            id: "right-ear",
          },
        ],
        duration: 600,
        voiceLine: "Thêm tai phải.",
      },
      {
        stepOrder: 4,
        label: "Mắt",
        description: "Vẽ đôi mắt",
        svgPaths: [
          {
            d: "M 170 115 C 168 110 172 108 175 110 C 178 112 177 118 174 119 C 171 120 169 118 170 115 Z",
            stroke: "#333",
            strokeWidth: 3,
            fill: "#333",
            id: "left-eye",
          },
          {
            d: "M 230 115 C 228 110 232 108 235 110 C 238 112 237 118 234 119 C 231 120 229 118 230 115 Z",
            stroke: "#333",
            strokeWidth: 3,
            fill: "#333",
            id: "right-eye",
          },
        ],
        duration: 500,
        voiceLine: "Vẽ đôi mắt.",
      },
      {
        stepOrder: 5,
        label: "Mũi",
        description: "Vẽ cái mũi",
        svgPaths: [
          {
            d: "M 192 140 C 192 135 208 135 208 140 C 208 145 200 148 200 148 C 200 148 192 145 192 140 Z",
            stroke: "#333",
            strokeWidth: 3,
            fill: "#555",
            id: "nose",
          },
        ],
        duration: 400,
        voiceLine: "Vẽ cái mũi.",
      },
      {
        stepOrder: 6,
        label: "Miệng",
        description: "Vẽ miệng cười",
        svgPaths: [
          {
            d: "M 182 158 C 188 168 212 168 218 158",
            stroke: "#333",
            strokeWidth: 5,
            fill: "none",
            id: "mouth",
          },
        ],
        duration: 500,
        voiceLine: "Vẽ nụ cười.",
        isRevealStep: true,
      },
    ],
  },

  // ── 0 → Cat ───────────────────────────────────────────────────────────────
  {
    hook: "0",
    subject: "cat",
    hookType: "number",
    description: "Số 0 biến thành mèo dễ thương",
    style: "cute_simple",
    language: "vi",
    tags: ["animal", "cute", "cat", "number"],
    curiosityScore: 8,
    simplicityScore: 9,
    feasibilityScore: 10,
    visualScore: 8,
    retentionScore: 8,
    steps: [
      {
        stepOrder: 1,
        label: "Số 0",
        description: "Vẽ số 0 làm đầu",
        svgPaths: [
          {
            d: "M 200 100 C 160 100 130 140 130 200 C 130 260 160 300 200 300 C 240 300 270 260 270 200 C 270 140 240 100 200 100 Z",
            stroke: "#333",
            strokeWidth: 8,
            fill: "none",
            id: "head",
          },
        ],
        duration: 1000,
        voiceLine: "Bắt đầu với số không.",
      },
      {
        stepOrder: 2,
        label: "Tai trái",
        description: "Thêm tai nhọn trái",
        svgPaths: [
          {
            d: "M 148 115 L 130 75 L 168 100 Z",
            stroke: "#333",
            strokeWidth: 6,
            fill: "none",
            id: "left-ear",
          },
        ],
        duration: 500,
        voiceLine: "Tai trái nhọn.",
      },
      {
        stepOrder: 3,
        label: "Tai phải",
        description: "Thêm tai nhọn phải",
        svgPaths: [
          {
            d: "M 252 115 L 270 75 L 232 100 Z",
            stroke: "#333",
            strokeWidth: 6,
            fill: "none",
            id: "right-ear",
          },
        ],
        duration: 500,
        voiceLine: "Tai phải nhọn.",
      },
      {
        stepOrder: 4,
        label: "Mắt",
        description: "Vẽ mắt mèo",
        svgPaths: [
          {
            d: "M 168 190 C 168 180 178 175 178 190 C 178 205 168 200 168 190 Z",
            stroke: "#333",
            strokeWidth: 3,
            fill: "#1a1a1a",
            id: "left-eye",
          },
          {
            d: "M 222 190 C 222 180 232 175 232 190 C 232 205 222 200 222 190 Z",
            stroke: "#333",
            strokeWidth: 3,
            fill: "#1a1a1a",
            id: "right-eye",
          },
        ],
        duration: 500,
        voiceLine: "Đôi mắt mèo.",
      },
      {
        stepOrder: 5,
        label: "Ria mèo",
        description: "Vẽ ria mèo",
        svgPaths: [
          {
            d: "M 135 225 L 185 220 M 135 232 L 185 230 M 135 239 L 185 240",
            stroke: "#333",
            strokeWidth: 3,
            fill: "none",
            id: "left-whiskers",
          },
          {
            d: "M 265 225 L 215 220 M 265 232 L 215 230 M 265 239 L 215 240",
            stroke: "#333",
            strokeWidth: 3,
            fill: "none",
            id: "right-whiskers",
          },
        ],
        duration: 600,
        voiceLine: "Ria mèo dài.",
      },
      {
        stepOrder: 6,
        label: "Miệng",
        description: "Vẽ miệng mèo",
        svgPaths: [
          {
            d: "M 185 250 C 192 260 200 262 200 262 C 200 262 208 260 215 250",
            stroke: "#333",
            strokeWidth: 5,
            fill: "none",
            id: "mouth",
          },
        ],
        duration: 400,
        voiceLine: "Miệng mèo meo!",
        isRevealStep: true,
      },
    ],
  },

  // ── 3 → Bird ──────────────────────────────────────────────────────────────
  {
    hook: "3",
    subject: "bird",
    hookType: "number",
    description: "Số 3 biến thành chú chim",
    style: "cute_simple",
    language: "vi",
    tags: ["animal", "bird", "number"],
    curiosityScore: 8,
    simplicityScore: 8,
    feasibilityScore: 9,
    visualScore: 7,
    retentionScore: 8,
    steps: [
      {
        stepOrder: 1,
        label: "Số 3",
        description: "Vẽ số 3 làm thân chim",
        svgPaths: [
          {
            d: "M 145 110 C 145 85 175 75 200 85 C 225 95 235 120 215 140 C 235 160 230 195 205 205 C 180 215 148 205 148 185",
            stroke: "#333",
            strokeWidth: 8,
            fill: "none",
            id: "body",
          },
        ],
        duration: 1000,
        voiceLine: "Bắt đầu với số ba.",
      },
      {
        stepOrder: 2,
        label: "Mỏ",
        description: "Thêm mỏ chim",
        svgPaths: [
          {
            d: "M 235 135 L 265 130 L 235 148 Z",
            stroke: "#e07000",
            strokeWidth: 4,
            fill: "#e07000",
            id: "beak",
          },
        ],
        duration: 400,
        voiceLine: "Thêm mỏ chim.",
      },
      {
        stepOrder: 3,
        label: "Mắt",
        description: "Vẽ mắt chim",
        svgPaths: [
          {
            d: "M 210 115 C 210 108 218 106 220 112 C 222 118 216 122 212 119 C 210 117 210 115 210 115 Z",
            stroke: "#333",
            strokeWidth: 3,
            fill: "#222",
            id: "eye",
          },
        ],
        duration: 400,
        voiceLine: "Mắt chim sáng.",
      },
      {
        stepOrder: 4,
        label: "Cánh",
        description: "Vẽ cánh chim",
        svgPaths: [
          {
            d: "M 148 155 C 120 140 100 165 115 180 C 130 195 148 175 148 165",
            stroke: "#333",
            strokeWidth: 6,
            fill: "none",
            id: "wing",
          },
        ],
        duration: 600,
        voiceLine: "Cánh chim xòe ra.",
      },
      {
        stepOrder: 5,
        label: "Chân",
        description: "Vẽ chân chim",
        svgPaths: [
          {
            d: "M 172 205 L 160 240 L 148 255 M 160 240 L 172 255 M 185 208 L 178 243",
            stroke: "#e07000",
            strokeWidth: 5,
            fill: "none",
            id: "feet",
          },
        ],
        duration: 500,
        voiceLine: "Chân chim nhỏ xinh.",
        isRevealStep: true,
      },
    ],
  },

  // ── A → Ant ────────────────────────────────────────────────────────────────
  {
    hook: "A",
    subject: "ant",
    hookType: "letter",
    description: "Chữ A biến thành con kiến",
    style: "cute_simple",
    language: "vi",
    tags: ["animal", "insect", "ant", "letter"],
    curiosityScore: 7,
    simplicityScore: 8,
    feasibilityScore: 9,
    visualScore: 7,
    retentionScore: 7,
    steps: [
      {
        stepOrder: 1,
        label: "Chữ A",
        description: "Vẽ chữ A làm thân",
        svgPaths: [
          {
            d: "M 200 80 L 140 300 M 200 80 L 260 300 M 160 210 L 240 210",
            stroke: "#333",
            strokeWidth: 10,
            fill: "none",
            id: "letter-a",
          },
        ],
        duration: 900,
        voiceLine: "Bắt đầu với chữ A.",
      },
      {
        stepOrder: 2,
        label: "Đầu kiến",
        description: "Thêm đầu kiến",
        svgPaths: [
          {
            d: "M 200 55 C 188 55 178 65 178 77 C 178 89 188 99 200 99 C 212 99 222 89 222 77 C 222 65 212 55 200 55 Z",
            stroke: "#333",
            strokeWidth: 6,
            fill: "none",
            id: "head",
          },
        ],
        duration: 600,
        voiceLine: "Đầu kiến tròn.",
      },
      {
        stepOrder: 3,
        label: "Râu kiến",
        description: "Thêm râu",
        svgPaths: [
          {
            d: "M 190 60 C 178 45 165 38 160 30 M 210 60 C 222 45 235 38 240 30",
            stroke: "#333",
            strokeWidth: 4,
            fill: "none",
            id: "antennae",
          },
        ],
        duration: 500,
        voiceLine: "Râu kiến dài ngoằn.",
      },
      {
        stepOrder: 4,
        label: "Chân",
        description: "Thêm chân kiến",
        svgPaths: [
          {
            d: "M 158 180 L 130 165 M 158 195 L 128 195 M 158 210 L 130 225 M 242 180 L 270 165 M 242 195 L 272 195 M 242 210 L 270 225",
            stroke: "#333",
            strokeWidth: 5,
            fill: "none",
            id: "legs",
          },
        ],
        duration: 700,
        voiceLine: "Sáu chân kiến.",
        isRevealStep: true,
      },
    ],
  },

  // ── O → Owl ────────────────────────────────────────────────────────────────
  {
    hook: "O",
    subject: "owl",
    hookType: "letter",
    description: "Chữ O biến thành cú mèo",
    style: "cute_simple",
    language: "vi",
    tags: ["animal", "owl", "letter", "night"],
    curiosityScore: 8,
    simplicityScore: 9,
    feasibilityScore: 9,
    visualScore: 8,
    retentionScore: 8,
    steps: [
      {
        stepOrder: 1,
        label: "Chữ O",
        description: "Vẽ chữ O làm đầu cú",
        svgPaths: [
          {
            d: "M 200 80 C 155 80 120 120 120 200 C 120 280 155 320 200 320 C 245 320 280 280 280 200 C 280 120 245 80 200 80 Z",
            stroke: "#333",
            strokeWidth: 8,
            fill: "none",
            id: "body",
          },
        ],
        duration: 1000,
        voiceLine: "Bắt đầu với chữ O.",
      },
      {
        stepOrder: 2,
        label: "Đôi mắt",
        description: "Vẽ mắt cú to",
        svgPaths: [
          {
            d: "M 168 175 C 168 155 188 145 188 175 C 188 205 168 195 168 175 Z",
            stroke: "#333",
            strokeWidth: 5,
            fill: "none",
            id: "left-eye-outer",
          },
          {
            d: "M 212 175 C 212 155 232 145 232 175 C 232 205 212 195 212 175 Z",
            stroke: "#333",
            strokeWidth: 5,
            fill: "none",
            id: "right-eye-outer",
          },
          {
            d: "M 175 175 C 175 168 183 165 183 175 C 183 185 175 182 175 175 Z",
            stroke: "#333",
            strokeWidth: 2,
            fill: "#222",
            id: "left-pupil",
          },
          {
            d: "M 217 175 C 217 168 225 165 225 175 C 225 185 217 182 217 175 Z",
            stroke: "#333",
            strokeWidth: 2,
            fill: "#222",
            id: "right-pupil",
          },
        ],
        duration: 700,
        voiceLine: "Mắt cú to tròn.",
      },
      {
        stepOrder: 3,
        label: "Mỏ",
        description: "Vẽ mỏ cú",
        svgPaths: [
          {
            d: "M 192 205 L 200 225 L 208 205 Z",
            stroke: "#e07000",
            strokeWidth: 3,
            fill: "#e07000",
            id: "beak",
          },
        ],
        duration: 400,
        voiceLine: "Mỏ cú nhọn.",
      },
      {
        stepOrder: 4,
        label: "Tai",
        description: "Thêm tai nhọn",
        svgPaths: [
          {
            d: "M 145 105 L 130 72 L 168 95",
            stroke: "#333",
            strokeWidth: 6,
            fill: "none",
            id: "left-ear",
          },
          {
            d: "M 255 105 L 270 72 L 232 95",
            stroke: "#333",
            strokeWidth: 6,
            fill: "none",
            id: "right-ear",
          },
        ],
        duration: 500,
        voiceLine: "Tai cú dựng đứng.",
      },
      {
        stepOrder: 5,
        label: "Cánh",
        description: "Vẽ cánh cú",
        svgPaths: [
          {
            d: "M 120 230 C 95 220 80 250 95 270 C 110 290 120 265 120 255",
            stroke: "#333",
            strokeWidth: 6,
            fill: "none",
            id: "left-wing",
          },
          {
            d: "M 280 230 C 305 220 320 250 305 270 C 290 290 280 265 280 255",
            stroke: "#333",
            strokeWidth: 6,
            fill: "none",
            id: "right-wing",
          },
        ],
        duration: 600,
        voiceLine: "Cú xòe cánh.",
        isRevealStep: true,
      },
    ],
  },

  // ── @ → Spider ─────────────────────────────────────────────────────────────
  {
    hook: "@",
    subject: "spider",
    hookType: "symbol",
    description: "Ký hiệu @ biến thành nhện",
    style: "cute_simple",
    language: "vi",
    tags: ["animal", "spider", "symbol", "halloween"],
    curiosityScore: 9,
    simplicityScore: 7,
    feasibilityScore: 8,
    visualScore: 9,
    retentionScore: 9,
    steps: [
      {
        stepOrder: 1,
        label: "Ký hiệu @",
        description: "Vẽ @ làm thân nhện",
        svgPaths: [
          {
            d: "M 200 130 C 185 130 175 145 175 160 C 175 175 185 185 200 185 C 215 185 225 175 225 160 C 225 145 215 130 200 130 Z M 225 160 C 225 180 220 200 210 210 C 200 218 185 212 180 200 C 170 185 172 155 185 145",
            stroke: "#333",
            strokeWidth: 7,
            fill: "none",
            id: "at-sign",
          },
          {
            d: "M 250 120 C 250 85 150 85 150 120 C 150 155 165 175 200 180 C 235 185 250 155 250 120 Z",
            stroke: "#333",
            strokeWidth: 7,
            fill: "none",
            id: "outer-ring",
          },
        ],
        duration: 1400,
        voiceLine: "Bắt đầu với ký hiệu A còng.",
      },
      {
        stepOrder: 2,
        label: "Mắt nhện",
        description: "Thêm mắt nhện",
        svgPaths: [
          {
            d: "M 188 155 C 188 150 194 149 194 155 C 194 161 188 159 188 155 Z",
            stroke: "#333",
            strokeWidth: 2,
            fill: "#222",
            id: "eye1",
          },
          {
            d: "M 206 155 C 206 150 212 149 212 155 C 212 161 206 159 206 155 Z",
            stroke: "#333",
            strokeWidth: 2,
            fill: "#222",
            id: "eye2",
          },
        ],
        duration: 400,
        voiceLine: "Mắt nhện đỏ.",
      },
      {
        stepOrder: 3,
        label: "Chân nhện trên",
        description: "Thêm chân phía trên",
        svgPaths: [
          {
            d: "M 155 115 L 110 85 M 155 130 L 105 115 M 155 145 L 108 145",
            stroke: "#333",
            strokeWidth: 5,
            fill: "none",
            id: "left-legs-top",
          },
          {
            d: "M 245 115 L 290 85 M 245 130 L 295 115 M 245 145 L 292 145",
            stroke: "#333",
            strokeWidth: 5,
            fill: "none",
            id: "right-legs-top",
          },
        ],
        duration: 700,
        voiceLine: "Sáu chân nhện dài.",
      },
      {
        stepOrder: 4,
        label: "Chân nhện dưới",
        description: "Thêm chân phía dưới",
        svgPaths: [
          {
            d: "M 155 165 L 108 180 M 155 180 L 112 205",
            stroke: "#333",
            strokeWidth: 5,
            fill: "none",
            id: "left-legs-bottom",
          },
          {
            d: "M 245 165 L 292 180 M 245 180 L 288 205",
            stroke: "#333",
            strokeWidth: 5,
            fill: "none",
            id: "right-legs-bottom",
          },
        ],
        duration: 500,
        voiceLine: "Tám chân tất cả!",
      },
      {
        stepOrder: 5,
        label: "Tơ nhện",
        description: "Thêm tơ nhện",
        svgPaths: [
          {
            d: "M 200 95 L 200 35",
            stroke: "#999",
            strokeWidth: 3,
            fill: "none",
            id: "web-thread",
          },
        ],
        duration: 400,
        voiceLine: "Nhện nhả tơ!",
        isRevealStep: true,
      },
    ],
  },

  // ── △ → Fox ────────────────────────────────────────────────────────────────
  {
    hook: "△",
    subject: "fox",
    hookType: "geometry",
    description: "Tam giác biến thành cáo",
    style: "cute_simple",
    language: "vi",
    tags: ["animal", "fox", "geometry", "triangle"],
    curiosityScore: 8,
    simplicityScore: 8,
    feasibilityScore: 9,
    visualScore: 8,
    retentionScore: 8,
    steps: [
      {
        stepOrder: 1,
        label: "Tam giác",
        description: "Vẽ tam giác làm đầu cáo",
        svgPaths: [
          {
            d: "M 200 80 L 290 270 L 110 270 Z",
            stroke: "#e07000",
            strokeWidth: 8,
            fill: "none",
            id: "triangle",
          },
        ],
        duration: 900,
        voiceLine: "Bắt đầu với tam giác.",
      },
      {
        stepOrder: 2,
        label: "Tai cáo",
        description: "Thêm tai cáo nhọn",
        svgPaths: [
          {
            d: "M 155 118 L 130 60 L 180 100",
            stroke: "#e07000",
            strokeWidth: 7,
            fill: "none",
            id: "left-ear",
          },
          {
            d: "M 245 118 L 270 60 L 220 100",
            stroke: "#e07000",
            strokeWidth: 7,
            fill: "none",
            id: "right-ear",
          },
        ],
        duration: 600,
        voiceLine: "Tai cáo nhọn lên.",
      },
      {
        stepOrder: 3,
        label: "Mặt cáo",
        description: "Vẽ mắt và mũi cáo",
        svgPaths: [
          {
            d: "M 175 190 C 174 184 182 182 184 188 C 186 194 179 197 176 193 C 175 191 175 190 175 190 Z",
            stroke: "#333",
            strokeWidth: 2,
            fill: "#222",
            id: "left-eye",
          },
          {
            d: "M 225 190 C 224 184 232 182 234 188 C 236 194 229 197 226 193 C 225 191 225 190 225 190 Z",
            stroke: "#333",
            strokeWidth: 2,
            fill: "#222",
            id: "right-eye",
          },
          {
            d: "M 196 220 C 196 215 204 215 204 220 C 204 225 200 227 200 227 C 200 227 196 225 196 220 Z",
            stroke: "#333",
            strokeWidth: 3,
            fill: "#cc3300",
            id: "nose",
          },
        ],
        duration: 600,
        voiceLine: "Mắt và mũi cáo.",
      },
      {
        stepOrder: 4,
        label: "Đuôi cáo",
        description: "Vẽ đuôi cáo bông",
        svgPaths: [
          {
            d: "M 110 270 C 60 290 40 340 80 355 C 120 370 160 330 155 290 C 152 275 130 270 110 270",
            stroke: "#e07000",
            strokeWidth: 6,
            fill: "none",
            id: "tail",
          },
        ],
        duration: 700,
        voiceLine: "Đuôi cáo bồng bềnh.",
        isRevealStep: true,
      },
    ],
  },

  // ── 1 → Rocket ────────────────────────────────────────────────────────────
  {
    hook: "1",
    subject: "rocket",
    hookType: "number",
    description: "Số 1 biến thành tên lửa",
    style: "cute_simple",
    language: "vi",
    tags: ["vehicle", "rocket", "space", "number"],
    curiosityScore: 8,
    simplicityScore: 9,
    feasibilityScore: 9,
    visualScore: 8,
    retentionScore: 8,
    steps: [
      {
        stepOrder: 1,
        label: "Số 1",
        description: "Vẽ số 1 làm thân tên lửa",
        svgPaths: [
          {
            d: "M 200 80 L 200 320 M 200 80 L 175 115",
            stroke: "#333",
            strokeWidth: 10,
            fill: "none",
            id: "number-1",
          },
        ],
        duration: 700,
        voiceLine: "Bắt đầu với số một.",
      },
      {
        stepOrder: 2,
        label: "Mũi tên lửa",
        description: "Thêm mũi nhọn",
        svgPaths: [
          {
            d: "M 175 115 C 175 100 188 80 200 70 C 212 80 225 100 225 115",
            stroke: "#cc3300",
            strokeWidth: 7,
            fill: "none",
            id: "nose-cone",
          },
        ],
        duration: 500,
        voiceLine: "Mũi tên lửa nhọn.",
      },
      {
        stepOrder: 3,
        label: "Cửa sổ",
        description: "Vẽ cửa sổ",
        svgPaths: [
          {
            d: "M 188 175 C 188 162 212 162 212 175 C 212 188 188 188 188 175 Z",
            stroke: "#3399cc",
            strokeWidth: 5,
            fill: "none",
            id: "window",
          },
        ],
        duration: 400,
        voiceLine: "Cửa sổ phi thuyền.",
      },
      {
        stepOrder: 4,
        label: "Cánh tên lửa",
        description: "Thêm cánh ổn định",
        svgPaths: [
          {
            d: "M 180 290 L 145 330 L 180 320 Z",
            stroke: "#333",
            strokeWidth: 6,
            fill: "none",
            id: "left-fin",
          },
          {
            d: "M 220 290 L 255 330 L 220 320 Z",
            stroke: "#333",
            strokeWidth: 6,
            fill: "none",
            id: "right-fin",
          },
        ],
        duration: 500,
        voiceLine: "Cánh tên lửa.",
      },
      {
        stepOrder: 5,
        label: "Lửa phun",
        description: "Thêm lửa phun",
        svgPaths: [
          {
            d: "M 190 320 C 185 340 178 360 185 375 C 188 382 195 380 200 370 C 205 380 212 382 215 375 C 222 360 215 340 210 320",
            stroke: "#e07000",
            strokeWidth: 5,
            fill: "none",
            id: "flame",
          },
        ],
        duration: 500,
        voiceLine: "Phóooong! Tên lửa bay!",
        isRevealStep: true,
      },
    ],
  },

  // ── $ → Money bag ─────────────────────────────────────────────────────────
  {
    hook: "$",
    subject: "money bag",
    hookType: "symbol",
    description: "Ký hiệu $ biến thành túi tiền",
    style: "cute_simple",
    language: "vi",
    tags: ["money", "symbol", "finance"],
    curiosityScore: 8,
    simplicityScore: 8,
    feasibilityScore: 9,
    visualScore: 8,
    retentionScore: 8,
    steps: [
      {
        stepOrder: 1,
        label: "Ký hiệu $",
        description: "Vẽ ký hiệu đô la",
        svgPaths: [
          {
            d: "M 200 80 L 200 320 M 175 105 C 155 105 140 125 155 145 C 168 160 232 168 245 185 C 258 202 245 228 220 232 C 210 234 200 232 200 232 M 225 108 C 245 110 260 128 248 148 C 238 165 176 172 163 190 C 150 208 162 232 185 238",
            stroke: "#2a7a2a",
            strokeWidth: 9,
            fill: "none",
            id: "dollar-sign",
          },
        ],
        duration: 1200,
        voiceLine: "Bắt đầu với ký hiệu đô la.",
      },
      {
        stepOrder: 2,
        label: "Miệng túi",
        description: "Thêm nút buộc túi",
        svgPaths: [
          {
            d: "M 175 95 C 178 75 222 75 225 95",
            stroke: "#8B4513",
            strokeWidth: 7,
            fill: "none",
            id: "bag-top",
          },
        ],
        duration: 400,
        voiceLine: "Nút buộc chặt.",
      },
      {
        stepOrder: 3,
        label: "Thân túi",
        description: "Vẽ thân túi tiền phình to",
        svgPaths: [
          {
            d: "M 150 120 C 110 130 95 200 110 255 C 125 305 165 330 200 330 C 235 330 275 305 290 255 C 305 200 290 130 250 120 Z",
            stroke: "#8B4513",
            strokeWidth: 7,
            fill: "none",
            id: "bag-body",
          },
        ],
        duration: 800,
        voiceLine: "Túi tiền phình to.",
        isRevealStep: true,
      },
    ],
  },

  // ── S → Snake ─────────────────────────────────────────────────────────────
  {
    hook: "S",
    subject: "snake",
    hookType: "letter",
    description: "Chữ S biến thành con rắn",
    style: "cute_simple",
    language: "vi",
    tags: ["animal", "snake", "letter"],
    curiosityScore: 8,
    simplicityScore: 8,
    feasibilityScore: 9,
    visualScore: 8,
    retentionScore: 8,
    steps: [
      {
        stepOrder: 1,
        label: "Chữ S",
        description: "Vẽ chữ S làm thân rắn",
        svgPaths: [
          {
            d: "M 240 100 C 220 75 165 75 150 100 C 130 130 145 165 175 175 C 205 185 230 210 220 245 C 210 278 165 290 145 270",
            stroke: "#2a8a2a",
            strokeWidth: 14,
            fill: "none",
            id: "snake-body",
          },
        ],
        duration: 1200,
        voiceLine: "Bắt đầu với chữ S.",
      },
      {
        stepOrder: 2,
        label: "Đầu rắn",
        description: "Thêm đầu rắn",
        svgPaths: [
          {
            d: "M 228 88 C 238 78 258 82 262 95 C 266 108 255 120 242 118 C 240 118 240 100 228 88 Z",
            stroke: "#2a8a2a",
            strokeWidth: 5,
            fill: "none",
            id: "head",
          },
        ],
        duration: 500,
        voiceLine: "Đầu rắn hình thành.",
      },
      {
        stepOrder: 3,
        label: "Lưỡi rắn",
        description: "Thêm lưỡi chẻ đôi",
        svgPaths: [
          {
            d: "M 262 95 L 290 90 M 290 90 L 308 80 M 290 90 L 308 100",
            stroke: "#cc0000",
            strokeWidth: 4,
            fill: "none",
            id: "tongue",
          },
        ],
        duration: 400,
        voiceLine: "Lưỡi rắn lè ra.",
      },
      {
        stepOrder: 4,
        label: "Mắt rắn",
        description: "Thêm mắt rắn",
        svgPaths: [
          {
            d: "M 245 96 C 245 91 251 90 252 95 C 253 100 248 102 246 99 C 245 97 245 96 245 96 Z",
            stroke: "#333",
            strokeWidth: 2,
            fill: "#cc3300",
            id: "eye",
          },
        ],
        duration: 300,
        voiceLine: "Mắt rắn đỏ au.",
        isRevealStep: true,
      },
    ],
  },

  // ── ○ → Fish ──────────────────────────────────────────────────────────────
  {
    hook: "○",
    subject: "fish",
    hookType: "geometry",
    description: "Hình tròn biến thành cá",
    style: "cute_simple",
    language: "vi",
    tags: ["animal", "fish", "geometry", "circle"],
    curiosityScore: 7,
    simplicityScore: 9,
    feasibilityScore: 10,
    visualScore: 7,
    retentionScore: 7,
    steps: [
      {
        stepOrder: 1,
        label: "Hình tròn",
        description: "Vẽ hình tròn làm thân cá",
        svgPaths: [
          {
            d: "M 200 200 C 200 130 280 130 280 200 C 280 270 200 270 200 200 Z",
            stroke: "#3399cc",
            strokeWidth: 8,
            fill: "none",
            id: "fish-body",
          },
        ],
        duration: 800,
        voiceLine: "Bắt đầu với hình tròn.",
      },
      {
        stepOrder: 2,
        label: "Đuôi cá",
        description: "Thêm đuôi cá",
        svgPaths: [
          {
            d: "M 200 200 C 175 180 145 160 125 185 C 145 200 145 200 125 215 C 145 240 175 220 200 200",
            stroke: "#3399cc",
            strokeWidth: 7,
            fill: "none",
            id: "tail",
          },
        ],
        duration: 600,
        voiceLine: "Đuôi cá vẫy.",
      },
      {
        stepOrder: 3,
        label: "Vây cá",
        description: "Thêm vây lưng",
        svgPaths: [
          {
            d: "M 235 130 C 240 105 255 95 258 105 C 261 115 255 130 252 130",
            stroke: "#3399cc",
            strokeWidth: 6,
            fill: "none",
            id: "dorsal-fin",
          },
        ],
        duration: 400,
        voiceLine: "Vây lưng.",
      },
      {
        stepOrder: 4,
        label: "Mắt cá",
        description: "Thêm mắt cá",
        svgPaths: [
          {
            d: "M 264 188 C 264 181 272 179 274 185 C 276 191 271 196 267 193 C 265 191 264 188 264 188 Z",
            stroke: "#333",
            strokeWidth: 3,
            fill: "#222",
            id: "eye",
          },
        ],
        duration: 300,
        voiceLine: "Mắt cá tròn.",
      },
      {
        stepOrder: 5,
        label: "Vảy cá",
        description: "Thêm vảy cá",
        svgPaths: [
          {
            d: "M 240 175 C 240 160 255 158 255 172 M 225 190 C 225 175 240 173 240 187 M 240 205 C 240 190 255 188 255 202",
            stroke: "#3399cc",
            strokeWidth: 4,
            fill: "none",
            id: "scales",
          },
        ],
        duration: 500,
        voiceLine: "Vảy cá lấp lánh.",
        isRevealStep: true,
      },
    ],
  },
];

export function getTransformationByHookSubject(
  hook: string,
  subject: string
): TransformationDef | undefined {
  return TRANSFORMATIONS.find(
    (t) =>
      t.hook.toLowerCase() === hook.toLowerCase() &&
      t.subject.toLowerCase() === subject.toLowerCase()
  );
}

export function searchTransformations(query: string): TransformationDef[] {
  const q = query.toLowerCase();
  return TRANSFORMATIONS.filter(
    (t) =>
      t.hook.toLowerCase().includes(q) ||
      t.subject.toLowerCase().includes(q) ||
      t.tags.some((tag) => tag.toLowerCase().includes(q)) ||
      t.description.toLowerCase().includes(q)
  );
}
