// ─── Seed Utility ─────────────────────────────────────────────────────────────
// Deterministic pseudo-random number generation based on a seed.
// Same seed + same input = same output (FR-014).

export class SeededRandom {
  private seed: number;

  constructor(seed: number) {
    this.seed = seed;
  }

  /** Returns a float in [0, 1) */
  next(): number {
    // Mulberry32 PRNG
    this.seed += 0x6d2b79f5;
    let z = this.seed;
    z = Math.imul(z ^ (z >>> 15), z | 1);
    z ^= z + Math.imul(z ^ (z >>> 7), z | 61);
    return ((z ^ (z >>> 14)) >>> 0) / 4294967296;
  }

  /** Returns an int in [min, max] inclusive */
  nextInt(min: number, max: number): number {
    return min + Math.floor(this.next() * (max - min + 1));
  }

  /** Returns a float in [min, max) */
  nextFloat(min: number, max: number): number {
    return min + this.next() * (max - min);
  }

  /** Shuffles array in place */
  shuffle<T>(arr: T[]): T[] {
    const a = [...arr];
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(this.next() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  }
}

/** Variation modifiers applied to timing — controlled but not geometry-altering */
export interface TimingVariation {
  speedMultiplier: number; // 0.7–1.5
  pauseBetweenSteps: number; // ms
  revealPauseMs: number; // ms before reveal
}

export function generateTimingVariation(seed: number, speedPreset: "slow" | "normal" | "fast"): TimingVariation {
  const rng = new SeededRandom(seed);

  const baseMultipliers = {
    slow: [1.3, 1.5],
    normal: [0.9, 1.1],
    fast: [0.65, 0.8],
  };

  const [minM, maxM] = baseMultipliers[speedPreset];

  return {
    speedMultiplier: rng.nextFloat(minM, maxM),
    pauseBetweenSteps: rng.nextInt(100, 400),
    revealPauseMs: rng.nextInt(300, 800),
  };
}
